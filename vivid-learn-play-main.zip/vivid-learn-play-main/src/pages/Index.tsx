import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Home, ArrowLeft } from "lucide-react";
import { Navigation } from "@/components/Navigation";
import { Alphabet } from "@/components/Alphabet";
import { Verbs } from "@/components/Verbs";
import { Fruits } from "@/components/Fruits";
import { Foods } from "@/components/Foods";
import { Professions } from "@/components/Professions";
import { Objects } from "@/components/Objects";
import { HouseParts } from "@/components/HouseParts";
import { BodyParts } from "@/components/BodyParts";
import { Numbers } from "@/components/Numbers";
import { Sports } from "@/components/Sports";
import { Animals } from "@/components/Animals";
import { Colors } from "@/components/Colors";
import { Weather } from "@/components/Weather";
import { DaysMonths } from "@/components/DaysMonths";
import { Family } from "@/components/Family";
import { Clothing } from "@/components/Clothing";
import { Transportation } from "@/components/Transportation";
import { Adjectives } from "@/components/Adjectives";
import { Places } from "@/components/Places";
import { Emotions } from "@/components/Emotions";
import { CommonPhrases } from "@/components/CommonPhrases";
import { Stories } from "@/components/Stories";
import { Game } from "@/components/Game";
import { Translator } from "@/components/Translator";
import { Prayer } from "@/components/Prayer";

const Index = () => {
  const [currentSection, setCurrentSection] = useState<string | null>(null);

  const renderSection = () => {
    switch (currentSection) {
      case "alphabet":
        return <Alphabet />;
      case "verbs":
        return <Verbs />;
      case "fruits":
        return <Fruits />;
      case "foods":
        return <Foods />;
      case "professions":
        return <Professions />;
      case "objects":
        return <Objects />;
      case "houseParts":
        return <HouseParts />;
      case "bodyParts":
        return <BodyParts />;
      case "numbers":
        return <Numbers />;
      case "sports":
        return <Sports />;
      case "animals":
        return <Animals />;
      case "colors":
        return <Colors />;
      case "weather":
        return <Weather />;
      case "daysMonths":
        return <DaysMonths />;
      case "family":
        return <Family />;
      case "clothing":
        return <Clothing />;
      case "transportation":
        return <Transportation />;
      case "adjectives":
        return <Adjectives />;
      case "places":
        return <Places />;
      case "emotions":
        return <Emotions />;
      case "phrases":
        return <CommonPhrases />;
      case "stories":
        return <Stories />;
      case "game":
        return <Game />;
      case "translator":
        return <Translator />;
      case "prayer":
        return <Prayer />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-to-r from-primary via-secondary to-accent py-6 px-4 shadow-lg sticky top-0 z-10">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-4xl">📚</span>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-white">Aprende y Juega en Inglés</h1>
              <p className="text-sm text-white/90 hidden sm:block">Plataforma Interactiva de Aprendizaje de Inglés</p>
            </div>
          </div>
          {currentSection && (
            <Button
              onClick={() => setCurrentSection(null)}
              variant="default"
              size="lg"
              className="gap-2 bg-white text-primary hover:bg-white/90 shadow-lg font-bold text-base"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Volver al Menú</span>
            </Button>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto py-8 px-4">
        {!currentSection ? (
          <div className="space-y-8">
            <div className="text-center space-y-4 animate-fade-in">
              <h2 className="text-4xl md:text-5xl font-bold text-foreground">
                ¡Bienvenido a tu Aventura en Inglés! 🚀
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Aprende inglés desde básico hasta intermedio con tablas interactivas, juegos y pronunciación real. ¡Elige una sección para comenzar a aprender!
              </p>
            </div>
            <Navigation onNavigate={setCurrentSection} />
          </div>
        ) : (
          <div className="animate-slide-up">{renderSection()}</div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-card mt-16 py-6 border-t">
        <div className="container mx-auto text-center">
          <p className="text-muted-foreground">
            Hecho con ❤️ para estudiantes de inglés en todo el mundo
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            ¡Practica diariamente y mejora tu inglés! 🌟
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
