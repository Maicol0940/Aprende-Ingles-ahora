import { Volume2, Search } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";
import { Input } from "./ui/input";
import { useState } from "react";

export const BodyParts = () => {
  const { speak } = useSpeech();
  const [search, setSearch] = useState("");

  const bodyParts = [
    // Cabeza
    { emoji: "👤", english: "Head", spanish: "Cabeza", category: "Cabeza" },
    { emoji: "🧠", english: "Brain", spanish: "Cerebro", category: "Cabeza" },
    { emoji: "👁️", english: "Eye", spanish: "Ojo", category: "Cabeza" },
    { emoji: "👃", english: "Nose", spanish: "Nariz", category: "Cabeza" },
    { emoji: "👄", english: "Mouth", spanish: "Boca", category: "Cabeza" },
    { emoji: "👅", english: "Tongue", spanish: "Lengua", category: "Cabeza" },
    { emoji: "🦷", english: "Tooth", spanish: "Diente", category: "Cabeza" },
    { emoji: "👂", english: "Ear", spanish: "Oreja", category: "Cabeza" },
    { emoji: "🫦", english: "Lips", spanish: "Labios", category: "Cabeza" },
    { emoji: "👁️", english: "Eyelash", spanish: "Pestaña", category: "Cabeza" },
    { emoji: "👁️", english: "Eyebrow", spanish: "Ceja", category: "Cabeza" },
    { emoji: "🫀", english: "Cheek", spanish: "Mejilla", category: "Cabeza" },
    { emoji: "🧔", english: "Chin", spanish: "Barbilla", category: "Cabeza" },
    { emoji: "💇", english: "Hair", spanish: "Cabello", category: "Cabeza" },
    { emoji: "🧔", english: "Beard", spanish: "Barba", category: "Cabeza" },
    { emoji: "😬", english: "Jaw", spanish: "Mandíbula", category: "Cabeza" },
    { emoji: "👤", english: "Forehead", spanish: "Frente", category: "Cabeza" },
    { emoji: "👤", english: "Temple", spanish: "Sien", category: "Cabeza" },
    { emoji: "👃", english: "Nostril", spanish: "Fosa Nasal", category: "Cabeza" },
    
    // Tronco
    { emoji: "🫁", english: "Neck", spanish: "Cuello", category: "Tronco" },
    { emoji: "💪", english: "Shoulder", spanish: "Hombro", category: "Tronco" },
    { emoji: "🫀", english: "Chest", spanish: "Pecho", category: "Tronco" },
    { emoji: "🫁", english: "Lungs", spanish: "Pulmones", category: "Tronco" },
    { emoji: "❤️", english: "Heart", spanish: "Corazón", category: "Tronco" },
    { emoji: "🫃", english: "Stomach", spanish: "Estómago", category: "Tronco" },
    { emoji: "🫃", english: "Belly", spanish: "Vientre", category: "Tronco" },
    { emoji: "🫃", english: "Abdomen", spanish: "Abdomen", category: "Tronco" },
    { emoji: "🫁", english: "Ribs", spanish: "Costillas", category: "Tronco" },
    { emoji: "🦴", english: "Spine", spanish: "Columna", category: "Tronco" },
    { emoji: "🫁", english: "Back", spanish: "Espalda", category: "Tronco" },
    { emoji: "💪", english: "Waist", spanish: "Cintura", category: "Tronco" },
    { emoji: "🍑", english: "Hip", spanish: "Cadera", category: "Tronco" },
    { emoji: "🍑", english: "Buttocks", spanish: "Glúteos", category: "Tronco" },
    
    // Extremidades Superiores
    { emoji: "💪", english: "Arm", spanish: "Brazo", category: "Extremidades Superiores" },
    { emoji: "💪", english: "Elbow", spanish: "Codo", category: "Extremidades Superiores" },
    { emoji: "💪", english: "Forearm", spanish: "Antebrazo", category: "Extremidades Superiores" },
    { emoji: "🤚", english: "Wrist", spanish: "Muñeca", category: "Extremidades Superiores" },
    { emoji: "✋", english: "Hand", spanish: "Mano", category: "Extremidades Superiores" },
    { emoji: "🫳", english: "Palm", spanish: "Palma", category: "Extremidades Superiores" },
    { emoji: "👆", english: "Finger", spanish: "Dedo", category: "Extremidades Superiores" },
    { emoji: "👍", english: "Thumb", spanish: "Pulgar", category: "Extremidades Superiores" },
    { emoji: "☝️", english: "Index Finger", spanish: "Dedo Índice", category: "Extremidades Superiores" },
    { emoji: "🖕", english: "Middle Finger", spanish: "Dedo Medio", category: "Extremidades Superiores" },
    { emoji: "💍", english: "Ring Finger", spanish: "Dedo Anular", category: "Extremidades Superiores" },
    { emoji: "🤙", english: "Pinky", spanish: "Meñique", category: "Extremidades Superiores" },
    { emoji: "💅", english: "Nail", spanish: "Uña", category: "Extremidades Superiores" },
    { emoji: "🤜", english: "Fist", spanish: "Puño", category: "Extremidades Superiores" },
    { emoji: "👋", english: "Knuckle", spanish: "Nudillo", category: "Extremidades Superiores" },
    
    // Extremidades Inferiores
    { emoji: "🦵", english: "Leg", spanish: "Pierna", category: "Extremidades Inferiores" },
    { emoji: "🦵", english: "Thigh", spanish: "Muslo", category: "Extremidades Inferiores" },
    { emoji: "🦵", english: "Knee", spanish: "Rodilla", category: "Extremidades Inferiores" },
    { emoji: "🦵", english: "Shin", spanish: "Espinilla", category: "Extremidades Inferiores" },
    { emoji: "🦵", english: "Calf", spanish: "Pantorrilla", category: "Extremidades Inferiores" },
    { emoji: "🦶", english: "Ankle", spanish: "Tobillo", category: "Extremidades Inferiores" },
    { emoji: "🦶", english: "Foot", spanish: "Pie", category: "Extremidades Inferiores" },
    { emoji: "🦶", english: "Heel", spanish: "Talón", category: "Extremidades Inferiores" },
    { emoji: "🦶", english: "Sole", spanish: "Planta del Pie", category: "Extremidades Inferiores" },
    { emoji: "🦶", english: "Toe", spanish: "Dedo del Pie", category: "Extremidades Inferiores" },
    { emoji: "🦶", english: "Big Toe", spanish: "Dedo Gordo del Pie", category: "Extremidades Inferiores" },
    
    // Órganos Internos
    { emoji: "🫀", english: "Heart", spanish: "Corazón", category: "Órganos Internos" },
    { emoji: "🫁", english: "Lung", spanish: "Pulmón", category: "Órganos Internos" },
    { emoji: "🍔", english: "Liver", spanish: "Hígado", category: "Órganos Internos" },
    { emoji: "🫘", english: "Kidney", spanish: "Riñón", category: "Órganos Internos" },
    { emoji: "🧠", english: "Brain", spanish: "Cerebro", category: "Órganos Internos" },
    { emoji: "🫃", english: "Intestines", spanish: "Intestinos", category: "Órganos Internos" },
    { emoji: "💉", english: "Bladder", spanish: "Vejiga", category: "Órganos Internos" },
    { emoji: "🫁", english: "Pancreas", spanish: "Páncreas", category: "Órganos Internos" },
    { emoji: "🦴", english: "Bone", spanish: "Hueso", category: "Órganos Internos" },
    { emoji: "💪", english: "Muscle", spanish: "Músculo", category: "Órganos Internos" },
    { emoji: "🩸", english: "Blood", spanish: "Sangre", category: "Órganos Internos" },
    { emoji: "🫀", english: "Vein", spanish: "Vena", category: "Órganos Internos" },
    { emoji: "🫀", english: "Artery", spanish: "Arteria", category: "Órganos Internos" },
    
    // Otros
    { emoji: "🫂", english: "Body", spanish: "Cuerpo", category: "General" },
    { emoji: "👤", english: "Face", spanish: "Cara", category: "General" },
    { emoji: "🧑", english: "Skin", spanish: "Piel", category: "General" },
    { emoji: "🦴", english: "Skeleton", spanish: "Esqueleto", category: "General" },
    { emoji: "💪", english: "Biceps", spanish: "Bíceps", category: "General" },
    { emoji: "💪", english: "Triceps", spanish: "Tríceps", category: "General" },
    { emoji: "🦵", english: "Hamstring", spanish: "Isquiotibiales", category: "General" },
    { emoji: "💪", english: "Abs", spanish: "Abdominales", category: "General" },
    { emoji: "🫀", english: "Vein", spanish: "Vena", category: "General" },
    { emoji: "🫀", english: "Artery", spanish: "Arteria", category: "General" },
    { emoji: "🦷", english: "Gum", spanish: "Encía", category: "Cabeza" },
    { emoji: "🧔", english: "Moustache", spanish: "Bigote", category: "Cabeza" },
    { emoji: "👁️", english: "Pupil", spanish: "Pupila", category: "Cabeza" },
    { emoji: "👁️", english: "Iris", spanish: "Iris", category: "Cabeza" },
    { emoji: "👃", english: "Bridge of nose", spanish: "Puente de la Nariz", category: "Cabeza" },
    { emoji: "🦴", english: "Skull", spanish: "Cráneo", category: "Cabeza" },
    { emoji: "🫁", english: "Throat", spanish: "Garganta", category: "Tronco" },
    { emoji: "🫀", english: "Aorta", spanish: "Aorta", category: "Órganos Internos" },
    { emoji: "🧠", english: "Cerebellum", spanish: "Cerebelo", category: "Órganos Internos" },
    { emoji: "🫁", english: "Trachea", spanish: "Tráquea", category: "Órganos Internos" },
    { emoji: "🫁", english: "Esophagus", spanish: "Esófago", category: "Órganos Internos" },
    { emoji: "🫃", english: "Small Intestine", spanish: "Intestino Delgado", category: "Órganos Internos" },
    { emoji: "🫃", english: "Large Intestine", spanish: "Intestino Grueso", category: "Órganos Internos" },
    { emoji: "🫁", english: "Spleen", spanish: "Bazo", category: "Órganos Internos" },
    { emoji: "🦴", english: "Cartilage", spanish: "Cartílago", category: "General" },
    { emoji: "🩸", english: "Plasma", spanish: "Plasma", category: "General" },
    { emoji: "💪", english: "Tendon", spanish: "Tendón", category: "General" },
    { emoji: "💪", english: "Ligament", spanish: "Ligamento", category: "General" },
    { emoji: "🫁", english: "Diaphragm", spanish: "Diafragma", category: "Tronco" },
    { emoji: "💪", english: "Pectoral", spanish: "Pectoral", category: "Tronco" },
    { emoji: "💪", english: "Deltoid", spanish: "Deltoides", category: "Tronco" },
    { emoji: "🦵", english: "Quadriceps", spanish: "Cuádriceps", category: "Extremidades Inferiores" },
    { emoji: "🦵", english: "Achilles", spanish: "Tendón de Aquiles", category: "Extremidades Inferiores" },
    { emoji: "🦶", english: "Arch", spanish: "Arco del Pie", category: "Extremidades Inferiores" },
    { emoji: "🦶", english: "Ball of foot", spanish: "Metatarso", category: "Extremidades Inferiores" },
    { emoji: "💅", english: "Cuticle", spanish: "Cutícula", category: "Extremidades Superiores" },
    { emoji: "🤚", english: "Knuckle", spanish: "Articulación", category: "Extremidades Superiores" },
  ];

  const filteredParts = bodyParts.filter(
    (part) =>
      part.english.toLowerCase().includes(search.toLowerCase()) ||
      part.spanish.toLowerCase().includes(search.toLowerCase()) ||
      part.category.toLowerCase().includes(search.toLowerCase())
  );

  const categories = [...new Set(filteredParts.map((p) => p.category))];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🧍 Partes del Cuerpo</h2>
        <p className="text-muted-foreground">Aprende vocabulario sobre las partes del cuerpo humano</p>
      </div>

      <div className="max-w-md mx-auto relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Buscar partes del cuerpo..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      {categories.map((category) => {
        const categoryParts = filteredParts.filter((p) => p.category === category);
        return (
          <div key={category}>
            <h3 className="text-2xl font-bold text-foreground mb-4">{category}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {categoryParts.map((part) => (
                <div key={part.english + part.category} className="learn-card flex items-center justify-between bg-secondary/10">
                  <div className="flex items-center gap-3">
                    <span className="text-4xl">{part.emoji}</span>
                    <div>
                      <p className="font-bold text-foreground">{part.english}</p>
                      <p className="text-sm text-muted-foreground">{part.spanish}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => speak(part.english)}
                    className="pronunciation-btn"
                    aria-label={`Pronounce ${part.english}`}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      {filteredParts.length === 0 && (
        <p className="text-center text-muted-foreground">No se encontraron resultados. Intenta con otra búsqueda.</p>
      )}
    </div>
  );
};
