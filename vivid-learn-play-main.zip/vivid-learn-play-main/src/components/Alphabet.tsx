import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const Alphabet = () => {
  const { speak } = useSpeech();

  const alphabet = [
    { letter: "A", pronunciation: "ei", example: "Apple" },
    { letter: "B", pronunciation: "bi", example: "Ball" },
    { letter: "C", pronunciation: "si", example: "Cat" },
    { letter: "D", pronunciation: "di", example: "Dog" },
    { letter: "E", pronunciation: "i", example: "Elephant" },
    { letter: "F", pronunciation: "ef", example: "Fish" },
    { letter: "G", pronunciation: "yi", example: "Gorilla" },
    { letter: "H", pronunciation: "eich", example: "House" },
    { letter: "I", pronunciation: "ai", example: "Ice" },
    { letter: "J", pronunciation: "yei", example: "Juice" },
    { letter: "K", pronunciation: "kei", example: "Kite" },
    { letter: "L", pronunciation: "el", example: "Lion" },
    { letter: "M", pronunciation: "em", example: "Moon" },
    { letter: "N", pronunciation: "en", example: "Nest" },
    { letter: "O", pronunciation: "ou", example: "Orange" },
    { letter: "P", pronunciation: "pi", example: "Panda" },
    { letter: "Q", pronunciation: "kiu", example: "Queen" },
    { letter: "R", pronunciation: "ar", example: "Rabbit" },
    { letter: "S", pronunciation: "es", example: "Sun" },
    { letter: "T", pronunciation: "ti", example: "Tiger" },
    { letter: "U", pronunciation: "iu", example: "Umbrella" },
    { letter: "V", pronunciation: "vi", example: "Violin" },
    { letter: "W", pronunciation: "dabel iu", example: "Water" },
    { letter: "X", pronunciation: "eks", example: "Xylophone" },
    { letter: "Y", pronunciation: "uai", example: "Yellow" },
    { letter: "Z", pronunciation: "zi", example: "Zebra" },
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🔤 Abecedario en Inglés</h2>
        <p className="text-muted-foreground">Haz clic en el altavoz para escuchar cada letra</p>
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {alphabet.map((item) => (
          <div
            key={item.letter}
            className="learn-card flex flex-col items-center justify-center gap-2 py-6 bg-gradient-to-br from-primary to-primary/70"
          >
            <span className="text-5xl font-bold text-white">{item.letter}</span>
            <span className="text-sm text-white/90">({item.pronunciation})</span>
            <span className="text-xs text-white/80 italic">{item.example}</span>
            <button
              onClick={() => speak(item.letter)}
              className="pronunciation-btn bg-white text-primary"
              aria-label={`Pronounce ${item.letter}`}
            >
              <Volume2 className="w-5 h-5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
