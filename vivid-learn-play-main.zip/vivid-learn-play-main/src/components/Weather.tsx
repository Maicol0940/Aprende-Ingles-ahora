import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const Weather = () => {
  const { speak } = useSpeech();

  const weatherTerms = [
    { emoji: "☀️", english: "Sunny", spanish: "Soleado", phrase: "It's sunny today" },
    { emoji: "☁️", english: "Cloudy", spanish: "Nublado", phrase: "It's cloudy" },
    { emoji: "🌧️", english: "Rainy", spanish: "Lluvioso", phrase: "It's raining" },
    { emoji: "⛈️", english: "Stormy", spanish: "Tormentoso", phrase: "It's stormy" },
    { emoji: "❄️", english: "Snowy", spanish: "Nevado", phrase: "It's snowing" },
    { emoji: "🌫️", english: "Foggy", spanish: "Neblinoso", phrase: "It's foggy" },
    { emoji: "💨", english: "Windy", spanish: "Ventoso", phrase: "It's windy" },
    { emoji: "🌡️", english: "Hot", spanish: "Caluroso", phrase: "It's hot" },
    { emoji: "🧊", english: "Cold", spanish: "Frío", phrase: "It's cold" },
    { emoji: "🌡️", english: "Warm", spanish: "Cálido", phrase: "It's warm" },
    { emoji: "🥶", english: "Freezing", spanish: "Helado", phrase: "It's freezing" },
    { emoji: "🌪️", english: "Tornado", spanish: "Tornado", phrase: "There's a tornado" },
    { emoji: "🌈", english: "Rainbow", spanish: "Arco iris", phrase: "There's a rainbow" },
    { emoji: "⚡", english: "Lightning", spanish: "Relámpago", phrase: "There's lightning" },
    { emoji: "🌩️", english: "Thunder", spanish: "Trueno", phrase: "There's thunder" },
    { emoji: "🌨️", english: "Blizzard", spanish: "Ventisca", phrase: "It's a blizzard" },
    { emoji: "🌦️", english: "Partly Cloudy", spanish: "Parcialmente nublado", phrase: "It's partly cloudy" },
    { emoji: "🌤️", english: "Mostly Sunny", spanish: "Mayormente soleado", phrase: "It's mostly sunny" },
    { emoji: "🌥️", english: "Overcast", spanish: "Cubierto", phrase: "It's overcast" },
    { emoji: "💧", english: "Humid", spanish: "Húmedo", phrase: "It's humid" },
    { emoji: "🏜️", english: "Dry", spanish: "Seco", phrase: "It's dry" },
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🌤️ Weather</h2>
        <p className="text-muted-foreground">Aprende sobre el clima en inglés</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {weatherTerms.map((item) => (
          <div
            key={item.english}
            className="learn-card bg-gradient-to-br from-primary to-primary/70 p-6 space-y-3"
          >
            <div className="text-6xl text-center">{item.emoji}</div>
            <div className="text-center">
              <h3 className="text-2xl font-bold text-white mb-1">{item.english}</h3>
              <p className="text-white/90 italic mb-3">{item.spanish}</p>
              <p className="text-sm text-white/80 bg-white/10 rounded-lg p-2">"{item.phrase}"</p>
            </div>
            <button
              onClick={() => speak(item.phrase)}
              className="pronunciation-btn mx-auto bg-white text-primary"
              aria-label={`Pronounce ${item.english}`}
            >
              <Volume2 className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
