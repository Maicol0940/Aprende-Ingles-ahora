import { useState } from "react";
import { Volume2, Search } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";
import { Input } from "./ui/input";

export const Objects = () => {
  const { speak } = useSpeech();
  const [searchTerm, setSearchTerm] = useState("");

  const objects = [
    // Casa 🏠
    { english: "🪑 Chair", spanish: "Silla", category: "Casa" },
    { english: "🛋️ Sofa", spanish: "Sofá", category: "Casa" },
    { english: "🪵 Table", spanish: "Mesa", category: "Casa" },
    { english: "🛏️ Bed", spanish: "Cama", category: "Casa" },
    { english: "🪟 Window", spanish: "Ventana", category: "Casa" },
    { english: "🚪 Door", spanish: "Puerta", category: "Casa" },
    { english: "💡 Lamp", spanish: "Lámpara", category: "Casa" },
    { english: "🪞 Mirror", spanish: "Espejo", category: "Casa" },
    { english: "🖼️ Picture", spanish: "Cuadro", category: "Casa" },
    { english: "🕰️ Clock", spanish: "Reloj", category: "Casa" },
    { english: "🧹 Broom", spanish: "Escoba", category: "Casa" },
    { english: "🪣 Bucket", spanish: "Balde", category: "Casa" },
    { english: "🔑 Key", spanish: "Llave", category: "Casa" },
    { english: "🛁 Bathtub", spanish: "Bañera", category: "Casa" },
    { english: "🚿 Shower", spanish: "Ducha", category: "Casa" },
    { english: "🪴 Plant", spanish: "Planta", category: "Casa" },
    { english: "🕯️ Candle", spanish: "Vela", category: "Casa" },
    { english: "🧺 Basket", spanish: "Canasta", category: "Casa" },
    { english: "🧽 Sponge", spanish: "Esponja", category: "Casa" },
    { english: "🧴 Soap", spanish: "Jabón", category: "Casa" },
    { english: "🧻 Toilet Paper", spanish: "Papel Higiénico", category: "Casa" },
    { english: "🛎️ Bell", spanish: "Campanilla", category: "Casa" },
    { english: "🧯 Fire Extinguisher", spanish: "Extintor", category: "Casa" },
    { english: "🪜 Ladder", spanish: "Escalera", category: "Casa" },
    { english: "🪟 Curtain", spanish: "Cortina", category: "Casa" },
    { english: "🛋️ Cushion", spanish: "Cojín", category: "Casa" },
    { english: "🧸 Toy", spanish: "Juguete", category: "Casa" },
    { english: "🎈 Balloon", spanish: "Globo", category: "Casa" },
    { english: "🪀 Yo-yo", spanish: "Yoyo", category: "Casa" },
    { english: "🧩 Puzzle", spanish: "Rompecabezas", category: "Casa" },
    
    // Escuela 🏫
    { english: "📖 Book", spanish: "Libro", category: "Escuela" },
    { english: "📝 Notebook", spanish: "Cuaderno", category: "Escuela" },
    { english: "✏️ Pencil", spanish: "Lápiz", category: "Escuela" },
    { english: "🖊️ Pen", spanish: "Bolígrafo", category: "Escuela" },
    { english: "📏 Ruler", spanish: "Regla", category: "Escuela" },
    { english: "✂️ Scissors", spanish: "Tijeras", category: "Escuela" },
    { english: "🖍️ Crayon", spanish: "Crayón", category: "Escuela" },
    { english: "🎒 Backpack", spanish: "Mochila", category: "Escuela" },
    { english: "📐 Triangle", spanish: "Triángulo", category: "Escuela" },
    { english: "🧮 Abacus", spanish: "Ábaco", category: "Escuela" },
    { english: "🗺️ Map", spanish: "Mapa", category: "Escuela" },
    { english: "🧪 Test tube", spanish: "Tubo de ensayo", category: "Escuela" },
    { english: "🔬 Microscope", spanish: "Microscopio", category: "Escuela" },
    { english: "🎨 Palette", spanish: "Paleta", category: "Escuela" },
    { english: "📚 Books", spanish: "Libros", category: "Escuela" },
    { english: "🖇️ Paper Clip", spanish: "Clip", category: "Escuela" },
    { english: "📌 Pin", spanish: "Alfiler", category: "Escuela" },
    { english: "🖍️ Marker", spanish: "Marcador", category: "Escuela" },
    { english: "📋 Clipboard", spanish: "Portapapeles", category: "Escuela" },
    { english: "🎓 Cap", spanish: "Birrete", category: "Escuela" },
    { english: "📊 Graph", spanish: "Gráfica", category: "Escuela" },
    { english: "🧲 Magnet", spanish: "Imán", category: "Escuela" },
    { english: "🔭 Telescope", spanish: "Telescopio", category: "Escuela" },
    { english: "🌍 Globe", spanish: "Globo Terráqueo", category: "Escuela" },
    { english: "📐 Compass", spanish: "Compás", category: "Escuela" },
    { english: "📏 Protractor", spanish: "Transportador", category: "Escuela" },
    { english: "🖼️ Frame", spanish: "Marco", category: "Escuela" },
    { english: "📄 Paper", spanish: "Papel", category: "Escuela" },
    { english: "🗂️ Folder", spanish: "Carpeta", category: "Escuela" },
    { english: "📕 Dictionary", spanish: "Diccionario", category: "Escuela" },
    
    // Oficina 🖥️
    { english: "💻 Computer", spanish: "Computadora", category: "Oficina" },
    { english: "🖥️ Monitor", spanish: "Monitor", category: "Oficina" },
    { english: "⌨️ Keyboard", spanish: "Teclado", category: "Oficina" },
    { english: "🖱️ Mouse", spanish: "Ratón", category: "Oficina" },
    { english: "🖨️ Printer", spanish: "Impresora", category: "Oficina" },
    { english: "📞 Telephone", spanish: "Teléfono", category: "Oficina" },
    { english: "📠 Fax", spanish: "Fax", category: "Oficina" },
    { english: "📋 Clipboard", spanish: "Portapapeles", category: "Oficina" },
    { english: "📎 Paperclip", spanish: "Clip", category: "Oficina" },
    { english: "📌 Pushpin", spanish: "Chincheta", category: "Oficina" },
    { english: "🗂️ File folder", spanish: "Carpeta", category: "Oficina" },
    { english: "📊 Chart", spanish: "Gráfico", category: "Oficina" },
    { english: "📅 Calendar", spanish: "Calendario", category: "Oficina" },
    { english: "🖇️ Stapler", spanish: "Engrapadora", category: "Oficina" },
    { english: "🗃️ File cabinet", spanish: "Archivador", category: "Oficina" },
    { english: "🖊️ Fountain Pen", spanish: "Pluma Estilográfica", category: "Oficina" },
    { english: "🖍️ Highlighter", spanish: "Resaltador", category: "Oficina" },
    { english: "📝 Notepad", spanish: "Bloc de Notas", category: "Oficina" },
    { english: "🗑️ Trash Can", spanish: "Papelera", category: "Oficina" },
    { english: "🔒 Lock", spanish: "Candado", category: "Oficina" },
    { english: "🔑 Key Card", spanish: "Tarjeta de Acceso", category: "Oficina" },
    { english: "💼 Briefcase", spanish: "Maletín", category: "Oficina" },
    { english: "📂 Folder", spanish: "Carpeta", category: "Oficina" },
    { english: "🗄️ Cabinet", spanish: "Archivador", category: "Oficina" },
    { english: "📇 Card Index", spanish: "Fichero", category: "Oficina" },
    { english: "📈 Chart Up", spanish: "Gráfico Ascendente", category: "Oficina" },
    { english: "📉 Chart Down", spanish: "Gráfico Descendente", category: "Oficina" },
    { english: "🖼️ Whiteboard", spanish: "Pizarra Blanca", category: "Oficina" },
    { english: "🗓️ Desk Calendar", spanish: "Calendario de Escritorio", category: "Oficina" },
    { english: "🪑 Office Chair", spanish: "Silla de Oficina", category: "Oficina" },
    
    // Naturaleza 🌳
    { english: "🌳 Tree", spanish: "Árbol", category: "Naturaleza" },
    { english: "🌺 Flower", spanish: "Flor", category: "Naturaleza" },
    { english: "🌿 Herb", spanish: "Hierba", category: "Naturaleza" },
    { english: "🍃 Leaf", spanish: "Hoja", category: "Naturaleza" },
    { english: "🌵 Cactus", spanish: "Cactus", category: "Naturaleza" },
    { english: "🪨 Rock", spanish: "Roca", category: "Naturaleza" },
    { english: "🏔️ Mountain", spanish: "Montaña", category: "Naturaleza" },
    { english: "🏖️ Beach", spanish: "Playa", category: "Naturaleza" },
    { english: "🌊 Wave", spanish: "Ola", category: "Naturaleza" },
    { english: "☀️ Sun", spanish: "Sol", category: "Naturaleza" },
    { english: "🌙 Moon", spanish: "Luna", category: "Naturaleza" },
    { english: "⭐ Star", spanish: "Estrella", category: "Naturaleza" },
    { english: "☁️ Cloud", spanish: "Nube", category: "Naturaleza" },
    { english: "🌈 Rainbow", spanish: "Arco iris", category: "Naturaleza" },
    { english: "⚡ Lightning", spanish: "Relámpago", category: "Naturaleza" },
    { english: "🌪️ Tornado", spanish: "Tornado", category: "Naturaleza" },
    { english: "❄️ Snowflake", spanish: "Copo de Nieve", category: "Naturaleza" },
    { english: "🌨️ Snow", spanish: "Nieve", category: "Naturaleza" },
    { english: "☔ Rain", spanish: "Lluvia", category: "Naturaleza" },
    { english: "🌊 Ocean", spanish: "Océano", category: "Naturaleza" },
    { english: "🏞️ Valley", spanish: "Valle", category: "Naturaleza" },
    { english: "🌋 Volcano", spanish: "Volcán", category: "Naturaleza" },
    { english: "🏜️ Desert", spanish: "Desierto", category: "Naturaleza" },
    { english: "🌲 Pine Tree", spanish: "Pino", category: "Naturaleza" },
    { english: "🌴 Palm Tree", spanish: "Palmera", category: "Naturaleza" },
    { english: "🍄 Mushroom", spanish: "Hongo", category: "Naturaleza" },
    { english: "🪵 Log", spanish: "Tronco", category: "Naturaleza" },
    { english: "🌾 Wheat", spanish: "Trigo", category: "Naturaleza" },
    { english: "🌱 Seedling", spanish: "Plántula", category: "Naturaleza" },
    { english: "🪴 Potted Plant", spanish: "Planta en Maceta", category: "Naturaleza" },
    
    // Tecnología 💻
    { english: "📱 Phone", spanish: "Teléfono móvil", category: "Tecnología" },
    { english: "📲 Smartphone", spanish: "Teléfono inteligente", category: "Tecnología" },
    { english: "💾 Disk", spanish: "Disco", category: "Tecnología" },
    { english: "💿 CD", spanish: "CD", category: "Tecnología" },
    { english: "📀 DVD", spanish: "DVD", category: "Tecnología" },
    { english: "🎥 Camera", spanish: "Cámara", category: "Tecnología" },
    { english: "📷 Photo camera", spanish: "Cámara de fotos", category: "Tecnología" },
    { english: "📹 Video camera", spanish: "Videocámara", category: "Tecnología" },
    { english: "🎮 Game console", spanish: "Consola de juegos", category: "Tecnología" },
    { english: "🕹️ Joystick", spanish: "Joystick", category: "Tecnología" },
    { english: "🎧 Headphones", spanish: "Auriculares", category: "Tecnología" },
    { english: "🎤 Microphone", spanish: "Micrófono", category: "Tecnología" },
    { english: "🔌 Plug", spanish: "Enchufe", category: "Tecnología" },
    { english: "🔋 Battery", spanish: "Batería", category: "Tecnología" },
    { english: "💡 Light bulb", spanish: "Bombilla", category: "Tecnología" },
    { english: "🔦 Flashlight", spanish: "Linterna", category: "Tecnología" },
    { english: "📻 Radio", spanish: "Radio", category: "Tecnología" },
    { english: "📺 Television", spanish: "Televisión", category: "Tecnología" },
    { english: "📼 VHS", spanish: "VHS", category: "Tecnología" },
    { english: "⏰ Alarm Clock", spanish: "Despertador", category: "Tecnología" },
    { english: "⏱️ Stopwatch", spanish: "Cronómetro", category: "Tecnología" },
    { english: "⌚ Watch", spanish: "Reloj de pulsera", category: "Tecnología" },
    { english: "📡 Satellite", spanish: "Satélite", category: "Tecnología" },
    { english: "🖱️ Trackpad", spanish: "Panel Táctil", category: "Tecnología" },
    { english: "🖲️ Trackball", spanish: "Trackball", category: "Tecnología" },
    { english: "💽 Minidisc", spanish: "Minidisc", category: "Tecnología" },
    { english: "💻 Laptop", spanish: "Portátil", category: "Tecnología" },
    { english: "🖥️ Desktop", spanish: "Computadora de Escritorio", category: "Tecnología" },
    { english: "🖨️ Scanner", spanish: "Escáner", category: "Tecnología" },
    { english: "🔌 Cable", spanish: "Cable", category: "Tecnología" },
    { english: "🖥️ Tablet", spanish: "Tableta", category: "Tecnología" },
    { english: "🔊 Speaker", spanish: "Altavoz", category: "Tecnología" },
    { english: "🎙️ Podcast Mic", spanish: "Micrófono de Podcast", category: "Tecnología" },
    { english: "💻 Server", spanish: "Servidor", category: "Tecnología" },
    { english: "🖥️ Monitor 4K", spanish: "Monitor 4K", category: "Tecnología" },
    { english: "⌨️ Mechanical Keyboard", spanish: "Teclado Mecánico", category: "Tecnología" },
    { english: "🖱️ Gaming Mouse", spanish: "Ratón para Juegos", category: "Tecnología" },
    { english: "🎮 VR Headset", spanish: "Casco de Realidad Virtual", category: "Tecnología" },
    { english: "📱 Smartwatch", spanish: "Reloj Inteligente", category: "Tecnología" },
    { english: "🔌 Power Bank", spanish: "Batería Portátil", category: "Tecnología" },
    { english: "💾 USB Drive", spanish: "Memoria USB", category: "Tecnología" },
    { english: "💿 Blu-ray", spanish: "Blu-ray", category: "Tecnología" },
    { english: "🎧 Earbuds", spanish: "Auriculares Inalámbricos", category: "Tecnología" },
    { english: "📡 Router", spanish: "Enrutador", category: "Tecnología" },
    { english: "🔌 Adapter", spanish: "Adaptador", category: "Tecnología" },
    { english: "🖥️ Webcam", spanish: "Cámara Web", category: "Tecnología" },
    { english: "💻 Chromebook", spanish: "Chromebook", category: "Tecnología" },
    { english: "🎮 Nintendo Switch", spanish: "Nintendo Switch", category: "Tecnología" },
    { english: "🎮 PlayStation", spanish: "PlayStation", category: "Tecnología" },
    { english: "🎮 Xbox", spanish: "Xbox", category: "Tecnología" },
  ];

  const filteredObjects = objects.filter(
    (obj) =>
      obj.english.toLowerCase().includes(searchTerm.toLowerCase()) ||
      obj.spanish.toLowerCase().includes(searchTerm.toLowerCase()) ||
      obj.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const groupedObjects = filteredObjects.reduce((acc, obj) => {
    if (!acc[obj.category]) {
      acc[obj.category] = [];
    }
    acc[obj.category].push(obj);
    return acc;
  }, {} as Record<string, typeof objects>);

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">📦 Objetos</h2>
        <p className="text-muted-foreground">Aprende los nombres de objetos comunes en inglés</p>
      </div>

      <div className="max-w-md mx-auto relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
        <Input
          type="text"
          placeholder="Buscar objeto..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="space-y-8">
        {Object.entries(groupedObjects).map(([category, items]) => (
          <div key={category}>
            <h3 className="text-2xl font-bold text-primary mb-4">{category}</h3>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-primary text-primary-foreground">
                    <th className="p-4 text-left rounded-tl-xl">Inglés</th>
                    <th className="p-4 text-left">Español</th>
                    <th className="p-4 text-center rounded-tr-xl">Pronunciar</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((obj, index) => (
                    <tr
                      key={obj.english}
                      className={`${
                        index % 2 === 0 ? "bg-card" : "bg-muted/30"
                      } hover:bg-primary/10 transition-colors`}
                    >
                      <td className="p-4 font-semibold">{obj.english}</td>
                      <td className="p-4 text-muted-foreground">{obj.spanish}</td>
                      <td className="p-4 text-center">
                        <button
                          onClick={() => speak(obj.english.replace(/^[^\s]+ /, ""))}
                          className="pronunciation-btn mx-auto"
                          aria-label={`Pronunciar ${obj.english}`}
                        >
                          <Volume2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
