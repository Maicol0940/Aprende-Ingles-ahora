import { Volume2, Search } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";
import { Input } from "./ui/input";
import { useState } from "react";

export const HouseParts = () => {
  const { speak } = useSpeech();
  const [search, setSearch] = useState("");

  const houseParts = [
    // Exterior
    { emoji: "🏠", english: "House", spanish: "Casa", category: "Exterior" },
    { emoji: "🚪", english: "Door", spanish: "Puerta", category: "Exterior" },
    { emoji: "🪟", english: "Window", spanish: "Ventana", category: "Exterior" },
    { emoji: "🏡", english: "Roof", spanish: "Techo", category: "Exterior" },
    { emoji: "🧱", english: "Wall", spanish: "Pared", category: "Exterior" },
    { emoji: "🪜", english: "Stairs", spanish: "Escaleras", category: "Exterior" },
    { emoji: "🏰", english: "Chimney", spanish: "Chimenea", category: "Exterior" },
    { emoji: "🌳", english: "Garden", spanish: "Jardín", category: "Exterior" },
    { emoji: "🚗", english: "Garage", spanish: "Garaje", category: "Exterior" },
    { emoji: "🔔", english: "Doorbell", spanish: "Timbre", category: "Exterior" },
    { emoji: "📬", english: "Mailbox", spanish: "Buzón", category: "Exterior" },
    { emoji: "🪴", english: "Porch", spanish: "Porche", category: "Exterior" },
    { emoji: "🏞️", english: "Backyard", spanish: "Patio Trasero", category: "Exterior" },
    { emoji: "🪟", english: "Balcony", spanish: "Balcón", category: "Exterior" },
    { emoji: "⛲", english: "Fence", spanish: "Cerca", category: "Exterior" },
    
    // Habitaciones
    { emoji: "🛋️", english: "Living Room", spanish: "Sala de Estar", category: "Habitaciones" },
    { emoji: "🛏️", english: "Bedroom", spanish: "Dormitorio", category: "Habitaciones" },
    { emoji: "🍳", english: "Kitchen", spanish: "Cocina", category: "Habitaciones" },
    { emoji: "🚿", english: "Bathroom", spanish: "Baño", category: "Habitaciones" },
    { emoji: "🍽️", english: "Dining Room", spanish: "Comedor", category: "Habitaciones" },
    { emoji: "📚", english: "Study", spanish: "Estudio", category: "Habitaciones" },
    { emoji: "🧺", english: "Laundry Room", spanish: "Lavandería", category: "Habitaciones" },
    { emoji: "🏠", english: "Attic", spanish: "Ático", category: "Habitaciones" },
    { emoji: "🔻", english: "Basement", spanish: "Sótano", category: "Habitaciones" },
    { emoji: "🚪", english: "Hallway", spanish: "Pasillo", category: "Habitaciones" },
    { emoji: "🪜", english: "Closet", spanish: "Armario", category: "Habitaciones" },
    { emoji: "👶", english: "Nursery", spanish: "Cuarto de Bebé", category: "Habitaciones" },
    
    // Sala de Estar
    { emoji: "🛋️", english: "Sofa", spanish: "Sofá", category: "Sala de Estar" },
    { emoji: "📺", english: "Television", spanish: "Televisión", category: "Sala de Estar" },
    { emoji: "🪑", english: "Armchair", spanish: "Sillón", category: "Sala de Estar" },
    { emoji: "🪵", english: "Coffee Table", spanish: "Mesa de Centro", category: "Sala de Estar" },
    { emoji: "🖼️", english: "Painting", spanish: "Cuadro", category: "Sala de Estar" },
    { emoji: "💡", english: "Lamp", spanish: "Lámpara", category: "Sala de Estar" },
    { emoji: "🪟", english: "Curtains", spanish: "Cortinas", category: "Sala de Estar" },
    { emoji: "🧸", english: "Cushion", spanish: "Cojín", category: "Sala de Estar" },
    { emoji: "📚", english: "Bookshelf", spanish: "Estantería", category: "Sala de Estar" },
    { emoji: "🎮", english: "Entertainment Center", spanish: "Centro de Entretenimiento", category: "Sala de Estar" },
    
    // Cocina
    { emoji: "❄️", english: "Refrigerator", spanish: "Refrigerador", category: "Cocina" },
    { emoji: "🔥", english: "Stove", spanish: "Estufa", category: "Cocina" },
    { emoji: "🍞", english: "Oven", spanish: "Horno", category: "Cocina" },
    { emoji: "🍽️", english: "Dishwasher", spanish: "Lavavajillas", category: "Cocina" },
    { emoji: "☕", english: "Microwave", spanish: "Microondas", category: "Cocina" },
    { emoji: "🚰", english: "Sink", spanish: "Fregadero", category: "Cocina" },
    { emoji: "🗄️", english: "Cabinets", spanish: "Gabinetes", category: "Cocina" },
    { emoji: "🪑", english: "Counter", spanish: "Encimera", category: "Cocina" },
    { emoji: "🍴", english: "Drawer", spanish: "Cajón", category: "Cocina" },
    { emoji: "🪵", english: "Kitchen Table", spanish: "Mesa de Cocina", category: "Cocina" },
    { emoji: "🧊", english: "Freezer", spanish: "Congelador", category: "Cocina" },
    { emoji: "🔪", english: "Cutting Board", spanish: "Tabla de Cortar", category: "Cocina" },
    
    // Dormitorio
    { emoji: "🛏️", english: "Bed", spanish: "Cama", category: "Dormitorio" },
    { emoji: "🛌", english: "Mattress", spanish: "Colchón", category: "Dormitorio" },
    { emoji: "🪑", english: "Nightstand", spanish: "Mesa de Noche", category: "Dormitorio" },
    { emoji: "🪞", english: "Dresser", spanish: "Cómoda", category: "Dormitorio" },
    { emoji: "🚪", english: "Wardrobe", spanish: "Guardarropa", category: "Dormitorio" },
    { emoji: "⏰", english: "Alarm Clock", spanish: "Despertador", category: "Dormitorio" },
    { emoji: "💡", english: "Bedside Lamp", spanish: "Lámpara de Noche", category: "Dormitorio" },
    { emoji: "🪟", english: "Blinds", spanish: "Persianas", category: "Dormitorio" },
    { emoji: "🧸", english: "Pillow", spanish: "Almohada", category: "Dormitorio" },
    { emoji: "🛌", english: "Blanket", spanish: "Manta", category: "Dormitorio" },
    { emoji: "🪞", english: "Mirror", spanish: "Espejo", category: "Dormitorio" },
    
    // Baño
    { emoji: "🚽", english: "Toilet", spanish: "Inodoro", category: "Baño" },
    { emoji: "🚿", english: "Shower", spanish: "Ducha", category: "Baño" },
    { emoji: "🛁", english: "Bathtub", spanish: "Bañera", category: "Baño" },
    { emoji: "🚰", english: "Sink", spanish: "Lavabo", category: "Baño" },
    { emoji: "🪞", english: "Mirror", spanish: "Espejo", category: "Baño" },
    { emoji: "🧴", english: "Soap", spanish: "Jabón", category: "Baño" },
    { emoji: "🧻", english: "Toilet Paper", spanish: "Papel Higiénico", category: "Baño" },
    { emoji: "🧽", english: "Towel", spanish: "Toalla", category: "Baño" },
    { emoji: "🪥", english: "Toothbrush", spanish: "Cepillo de Dientes", category: "Baño" },
    { emoji: "🧴", english: "Shampoo", spanish: "Champú", category: "Baño" },
    { emoji: "🚿", english: "Shower Curtain", spanish: "Cortina de Ducha", category: "Baño" },
    { emoji: "🧴", english: "Medicine Cabinet", spanish: "Botiquín", category: "Baño" },
    { emoji: "🧼", english: "Hand Soap", spanish: "Jabón de Manos", category: "Baño" },
    { emoji: "🧴", english: "Conditioner", spanish: "Acondicionador", category: "Baño" },
    { emoji: "🧴", english: "Body Wash", spanish: "Gel de Baño", category: "Baño" },
    { emoji: "🪒", english: "Razor", spanish: "Rasuradora", category: "Baño" },
    { emoji: "🧴", english: "Lotion", spanish: "Loción", category: "Baño" },
    { emoji: "🧴", english: "Deodorant", spanish: "Desodorante", category: "Baño" },
    { emoji: "🧻", english: "Tissue", spanish: "Pañuelo", category: "Baño" },
    { emoji: "🧽", english: "Bath Mat", spanish: "Tapete de Baño", category: "Baño" },
    { emoji: "🚿", english: "Shower Head", spanish: "Regadera", category: "Baño" },
    { emoji: "🚰", english: "Faucet", spanish: "Grifo", category: "Baño" },
    { emoji: "🧴", english: "Perfume", spanish: "Perfume", category: "Baño" },
    { emoji: "💄", english: "Lipstick", spanish: "Lápiz Labial", category: "Baño" },
    { emoji: "🪮", english: "Comb", spanish: "Peine", category: "Baño" },
    { emoji: "💇", english: "Hair Dryer", spanish: "Secador de Pelo", category: "Baño" },
  ];

  const filteredParts = houseParts.filter(
    (part) =>
      part.english.toLowerCase().includes(search.toLowerCase()) ||
      part.spanish.toLowerCase().includes(search.toLowerCase()) ||
      part.category.toLowerCase().includes(search.toLowerCase())
  );

  const categories = [...new Set(filteredParts.map((p) => p.category))];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🏠 Partes de la Casa</h2>
        <p className="text-muted-foreground">Aprende vocabulario sobre las partes y habitaciones de una casa</p>
      </div>

      <div className="max-w-md mx-auto relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Buscar partes de la casa..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      {categories.map((category) => {
        const categoryParts = filteredParts.filter((p) => p.category === category);
        return (
          <div key={category}>
            <h3 className="text-2xl font-bold text-foreground mb-4">{category}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {categoryParts.map((part) => (
                <div key={part.english} className="learn-card flex items-center justify-between bg-primary/10">
                  <div className="flex items-center gap-3">
                    <span className="text-4xl">{part.emoji}</span>
                    <div>
                      <p className="font-bold text-foreground">{part.english}</p>
                      <p className="text-sm text-muted-foreground">{part.spanish}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => speak(part.english)}
                    className="pronunciation-btn"
                    aria-label={`Pronounce ${part.english}`}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      {filteredParts.length === 0 && (
        <p className="text-center text-muted-foreground">No se encontraron resultados. Intenta con otra búsqueda.</p>
      )}
    </div>
  );
};
