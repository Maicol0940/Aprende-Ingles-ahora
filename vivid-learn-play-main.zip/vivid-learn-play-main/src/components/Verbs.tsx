import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const Verbs = () => {
  const { speak } = useSpeech();

  const verbs = [
    { emoji: "🍽️", base: "Eat", past: "Ate", pastParticiple: "Eaten", continuous: "Eating", spanish: "Comer" },
    { emoji: "🥤", base: "Drink", past: "Drank", pastParticiple: "Drunk", continuous: "Drinking", spanish: "Beber" },
    { emoji: "🚶‍♂️", base: "Go", past: "Went", pastParticiple: "Gone", continuous: "Going", spanish: "Ir" },
    { emoji: "💼", base: "Work", past: "Worked", pastParticiple: "Worked", continuous: "Working", spanish: "Trabajar" },
    { emoji: "🛏️", base: "Sleep", past: "Slept", pastParticiple: "Slept", continuous: "Sleeping", spanish: "Dormir" },
    { emoji: "🏃", base: "Run", past: "Ran", pastParticiple: "Run", continuous: "Running", spanish: "Correr" },
    { emoji: "🧠", base: "Think", past: "Thought", pastParticiple: "Thought", continuous: "Thinking", spanish: "Pensar" },
    { emoji: "❤️", base: "Love", past: "Loved", pastParticiple: "Loved", continuous: "Loving", spanish: "Amar" },
    { emoji: "📚", base: "Study", past: "Studied", pastParticiple: "Studied", continuous: "Studying", spanish: "Estudiar" },
    { emoji: "✍️", base: "Write", past: "Wrote", pastParticiple: "Written", continuous: "Writing", spanish: "Escribir" },
    { emoji: "👀", base: "See", past: "Saw", pastParticiple: "Seen", continuous: "Seeing", spanish: "Ver" },
    { emoji: "🗣️", base: "Speak", past: "Spoke", pastParticiple: "Spoken", continuous: "Speaking", spanish: "Hablar" },
    { emoji: "🎵", base: "Sing", past: "Sang", pastParticiple: "Sung", continuous: "Singing", spanish: "Cantar" },
    { emoji: "🏊", base: "Swim", past: "Swam", pastParticiple: "Swum", continuous: "Swimming", spanish: "Nadar" },
    { emoji: "🚗", base: "Drive", past: "Drove", pastParticiple: "Driven", continuous: "Driving", spanish: "Conducir" },
    { emoji: "📖", base: "Read", past: "Read", pastParticiple: "Read", continuous: "Reading", spanish: "Leer" },
    { emoji: "🎧", base: "Listen", past: "Listened", pastParticiple: "Listened", continuous: "Listening", spanish: "Escuchar" },
    { emoji: "🎨", base: "Draw", past: "Drew", pastParticiple: "Drawn", continuous: "Drawing", spanish: "Dibujar" },
    { emoji: "🎮", base: "Play", past: "Played", pastParticiple: "Played", continuous: "Playing", spanish: "Jugar" },
    { emoji: "🧹", base: "Clean", past: "Cleaned", pastParticiple: "Cleaned", continuous: "Cleaning", spanish: "Limpiar" },
    { emoji: "🍳", base: "Cook", past: "Cooked", pastParticiple: "Cooked", continuous: "Cooking", spanish: "Cocinar" },
    { emoji: "🛒", base: "Buy", past: "Bought", pastParticiple: "Bought", continuous: "Buying", spanish: "Comprar" },
    { emoji: "💰", base: "Sell", past: "Sold", pastParticiple: "Sold", continuous: "Selling", spanish: "Vender" },
    { emoji: "🎁", base: "Give", past: "Gave", pastParticiple: "Given", continuous: "Giving", spanish: "Dar" },
    { emoji: "🤝", base: "Take", past: "Took", pastParticiple: "Taken", continuous: "Taking", spanish: "Tomar" },
    { emoji: "🚪", base: "Come", past: "Came", pastParticiple: "Come", continuous: "Coming", spanish: "Venir" },
    { emoji: "🏠", base: "Leave", past: "Left", pastParticiple: "Left", continuous: "Leaving", spanish: "Salir" },
    { emoji: "🔍", base: "Find", past: "Found", pastParticiple: "Found", continuous: "Finding", spanish: "Encontrar" },
    { emoji: "🙈", base: "Lose", past: "Lost", pastParticiple: "Lost", continuous: "Losing", spanish: "Perder" },
    { emoji: "🎯", base: "Choose", past: "Chose", pastParticiple: "Chosen", continuous: "Choosing", spanish: "Elegir" },
    { emoji: "🗨️", base: "Say", past: "Said", pastParticiple: "Said", continuous: "Saying", spanish: "Decir" },
    { emoji: "💬", base: "Tell", past: "Told", pastParticiple: "Told", continuous: "Telling", spanish: "Contar" },
    { emoji: "👂", base: "Hear", past: "Heard", pastParticiple: "Heard", continuous: "Hearing", spanish: "Oír" },
    { emoji: "🧍", base: "Stand", past: "Stood", pastParticiple: "Stood", continuous: "Standing", spanish: "Estar de pie" },
    { emoji: "🪑", base: "Sit", past: "Sat", pastParticiple: "Sat", continuous: "Sitting", spanish: "Sentarse" },
    { emoji: "🤲", base: "Hold", past: "Held", pastParticiple: "Held", continuous: "Holding", spanish: "Sostener" },
    { emoji: "🔨", base: "Build", past: "Built", pastParticiple: "Built", continuous: "Building", spanish: "Construir" },
    { emoji: "✂️", base: "Cut", past: "Cut", pastParticiple: "Cut", continuous: "Cutting", spanish: "Cortar" },
    { emoji: "🎓", base: "Learn", past: "Learned", pastParticiple: "Learned", continuous: "Learning", spanish: "Aprender" },
    { emoji: "👨‍🏫", base: "Teach", past: "Taught", pastParticiple: "Taught", continuous: "Teaching", spanish: "Enseñar" },
    { emoji: "🚶", base: "Walk", past: "Walked", pastParticiple: "Walked", continuous: "Walking", spanish: "Caminar" },
    { emoji: "🤔", base: "Know", past: "Knew", pastParticiple: "Known", continuous: "Knowing", spanish: "Saber" },
    { emoji: "💭", base: "Remember", past: "Remembered", pastParticiple: "Remembered", continuous: "Remembering", spanish: "Recordar" },
    { emoji: "🤷", base: "Forget", past: "Forgot", pastParticiple: "Forgotten", continuous: "Forgetting", spanish: "Olvidar" },
    { emoji: "🙏", base: "Hope", past: "Hoped", pastParticiple: "Hoped", continuous: "Hoping", spanish: "Esperar" },
    { emoji: "😊", base: "Smile", past: "Smiled", pastParticiple: "Smiled", continuous: "Smiling", spanish: "Sonreír" },
    { emoji: "😢", base: "Cry", past: "Cried", pastParticiple: "Cried", continuous: "Crying", spanish: "Llorar" },
    { emoji: "😂", base: "Laugh", past: "Laughed", pastParticiple: "Laughed", continuous: "Laughing", spanish: "Reír" },
    { emoji: "🤗", base: "Hug", past: "Hugged", pastParticiple: "Hugged", continuous: "Hugging", spanish: "Abrazar" },
    { emoji: "💋", base: "Kiss", past: "Kissed", pastParticiple: "Kissed", continuous: "Kissing", spanish: "Besar" },
    { emoji: "🤝", base: "Meet", past: "Met", pastParticiple: "Met", continuous: "Meeting", spanish: "Conocer" },
    { emoji: "💬", base: "Talk", past: "Talked", pastParticiple: "Talked", continuous: "Talking", spanish: "Hablar" },
    { emoji: "🗣️", base: "Discuss", past: "Discussed", pastParticiple: "Discussed", continuous: "Discussing", spanish: "Discutir" },
    { emoji: "❓", base: "Ask", past: "Asked", pastParticiple: "Asked", continuous: "Asking", spanish: "Preguntar" },
    { emoji: "💡", base: "Answer", past: "Answered", pastParticiple: "Answered", continuous: "Answering", spanish: "Responder" },
    { emoji: "📞", base: "Call", past: "Called", pastParticiple: "Called", continuous: "Calling", spanish: "Llamar" },
    { emoji: "💌", base: "Send", past: "Sent", pastParticiple: "Sent", continuous: "Sending", spanish: "Enviar" },
    { emoji: "📬", base: "Receive", past: "Received", pastParticiple: "Received", continuous: "Receiving", spanish: "Recibir" },
    { emoji: "📝", base: "Sign", past: "Signed", pastParticiple: "Signed", continuous: "Signing", spanish: "Firmar" },
    { emoji: "🖊️", base: "Print", past: "Printed", pastParticiple: "Printed", continuous: "Printing", spanish: "Imprimir" },
    { emoji: "📄", base: "Copy", past: "Copied", pastParticiple: "Copied", continuous: "Copying", spanish: "Copiar" },
    { emoji: "🗑️", base: "Delete", past: "Deleted", pastParticiple: "Deleted", continuous: "Deleting", spanish: "Borrar" },
    { emoji: "💾", base: "Save", past: "Saved", pastParticiple: "Saved", continuous: "Saving", spanish: "Guardar" },
    { emoji: "📂", base: "Open", past: "Opened", pastParticiple: "Opened", continuous: "Opening", spanish: "Abrir" },
    { emoji: "🔒", base: "Close", past: "Closed", pastParticiple: "Closed", continuous: "Closing", spanish: "Cerrar" },
    { emoji: "🔓", base: "Unlock", past: "Unlocked", pastParticiple: "Unlocked", continuous: "Unlocking", spanish: "Desbloquear" },
    { emoji: "🔐", base: "Lock", past: "Locked", pastParticiple: "Locked", continuous: "Locking", spanish: "Bloquear" },
    { emoji: "🎬", base: "Start", past: "Started", pastParticiple: "Started", continuous: "Starting", spanish: "Comenzar" },
    { emoji: "🛑", base: "Stop", past: "Stopped", pastParticiple: "Stopped", continuous: "Stopping", spanish: "Detener" },
    { emoji: "⏸️", base: "Pause", past: "Paused", pastParticiple: "Paused", continuous: "Pausing", spanish: "Pausar" },
    { emoji: "▶️", base: "Continue", past: "Continued", pastParticiple: "Continued", continuous: "Continuing", spanish: "Continuar" },
    { emoji: "🔄", base: "Repeat", past: "Repeated", pastParticiple: "Repeated", continuous: "Repeating", spanish: "Repetir" },
    { emoji: "🔀", base: "Change", past: "Changed", pastParticiple: "Changed", continuous: "Changing", spanish: "Cambiar" },
    { emoji: "➕", base: "Add", past: "Added", pastParticiple: "Added", continuous: "Adding", spanish: "Añadir" },
    { emoji: "➖", base: "Remove", past: "Removed", pastParticiple: "Removed", continuous: "Removing", spanish: "Quitar" },
    { emoji: "✅", base: "Complete", past: "Completed", pastParticiple: "Completed", continuous: "Completing", spanish: "Completar" },
    { emoji: "🎯", base: "Focus", past: "Focused", pastParticiple: "Focused", continuous: "Focusing", spanish: "Enfocarse" },
    { emoji: "🔍", base: "Search", past: "Searched", pastParticiple: "Searched", continuous: "Searching", spanish: "Buscar" },
    { emoji: "✨", base: "Create", past: "Created", pastParticiple: "Created", continuous: "Creating", spanish: "Crear" },
    { emoji: "🗑️", base: "Destroy", past: "Destroyed", pastParticiple: "Destroyed", continuous: "Destroying", spanish: "Destruir" },
    { emoji: "🔧", base: "Fix", past: "Fixed", pastParticiple: "Fixed", continuous: "Fixing", spanish: "Arreglar" },
    { emoji: "💔", base: "Break", past: "Broke", pastParticiple: "Broken", continuous: "Breaking", spanish: "Romper" },
    { emoji: "🧵", base: "Sew", past: "Sewed", pastParticiple: "Sewn", continuous: "Sewing", spanish: "Coser" },
    { emoji: "🪡", base: "Knit", past: "Knitted", pastParticiple: "Knitted", continuous: "Knitting", spanish: "Tejer" },
    { emoji: "📐", base: "Measure", past: "Measured", pastParticiple: "Measured", continuous: "Measuring", spanish: "Medir" },
    { emoji: "⚖️", base: "Weigh", past: "Weighed", pastParticiple: "Weighed", continuous: "Weighing", spanish: "Pesar" },
    { emoji: "➗", base: "Divide", past: "Divided", pastParticiple: "Divided", continuous: "Dividing", spanish: "Dividir" },
    { emoji: "✖️", base: "Multiply", past: "Multiplied", pastParticiple: "Multiplied", continuous: "Multiplying", spanish: "Multiplicar" },
    { emoji: "➕", base: "Subtract", past: "Subtracted", pastParticiple: "Subtracted", continuous: "Subtracting", spanish: "Restar" },
    { emoji: "🧮", base: "Calculate", past: "Calculated", pastParticiple: "Calculated", continuous: "Calculating", spanish: "Calcular" },
    { emoji: "🧪", base: "Mix", past: "Mixed", pastParticiple: "Mixed", continuous: "Mixing", spanish: "Mezclar" },
    { emoji: "🥄", base: "Stir", past: "Stirred", pastParticiple: "Stirred", continuous: "Stirring", spanish: "Revolver" },
    { emoji: "🔥", base: "Burn", past: "Burned", pastParticiple: "Burned", continuous: "Burning", spanish: "Quemar" },
    { emoji: "🧊", base: "Freeze", past: "Froze", pastParticiple: "Frozen", continuous: "Freezing", spanish: "Congelar" },
    { emoji: "🫠", base: "Melt", past: "Melted", pastParticiple: "Melted", continuous: "Melting", spanish: "Derretir" },
    { emoji: "💨", base: "Blow", past: "Blew", pastParticiple: "Blown", continuous: "Blowing", spanish: "Soplar" },
    { emoji: "🌬️", base: "Breathe", past: "Breathed", pastParticiple: "Breathed", continuous: "Breathing", spanish: "Respirar" },
    { emoji: "💪", base: "Push", past: "Pushed", pastParticiple: "Pushed", continuous: "Pushing", spanish: "Empujar" },
    { emoji: "🤜", base: "Pull", past: "Pulled", pastParticiple: "Pulled", continuous: "Pulling", spanish: "Jalar" },
    { emoji: "⬆️", base: "Lift", past: "Lifted", pastParticiple: "Lifted", continuous: "Lifting", spanish: "Levantar" },
    { emoji: "⬇️", base: "Drop", past: "Dropped", pastParticiple: "Dropped", continuous: "Dropping", spanish: "Dejar caer" },
    { emoji: "🤸", base: "Jump", past: "Jumped", pastParticiple: "Jumped", continuous: "Jumping", spanish: "Saltar" },
    { emoji: "🕺", base: "Dance", past: "Danced", pastParticiple: "Danced", continuous: "Dancing", spanish: "Bailar" },
    { emoji: "🧘", base: "Relax", past: "Relaxed", pastParticiple: "Relaxed", continuous: "Relaxing", spanish: "Relajarse" },
    { emoji: "😴", base: "Rest", past: "Rested", pastParticiple: "Rested", continuous: "Resting", spanish: "Descansar" },
    { emoji: "😫", base: "Tire", past: "Tired", pastParticiple: "Tired", continuous: "Tiring", spanish: "Cansar" },
    { emoji: "🥱", base: "Yawn", past: "Yawned", pastParticiple: "Yawned", continuous: "Yawning", spanish: "Bostezar" },
    { emoji: "🤧", base: "Sneeze", past: "Sneezed", pastParticiple: "Sneezed", continuous: "Sneezing", spanish: "Estornudar" },
    { emoji: "😷", base: "Cough", past: "Coughed", pastParticiple: "Coughed", continuous: "Coughing", spanish: "Toser" },
    { emoji: "🤕", base: "Hurt", past: "Hurt", pastParticiple: "Hurt", continuous: "Hurting", spanish: "Lastimar" },
    { emoji: "💊", base: "Heal", past: "Healed", pastParticiple: "Healed", continuous: "Healing", spanish: "Curar" },
    { emoji: "🚿", base: "Wash", past: "Washed", pastParticiple: "Washed", continuous: "Washing", spanish: "Lavar" },
    { emoji: "🧼", base: "Scrub", past: "Scrubbed", pastParticiple: "Scrubbed", continuous: "Scrubbing", spanish: "Fregar" },
    { emoji: "🧽", base: "Wipe", past: "Wiped", pastParticiple: "Wiped", continuous: "Wiping", spanish: "Limpiar" },
    { emoji: "💧", base: "Dry", past: "Dried", pastParticiple: "Dried", continuous: "Drying", spanish: "Secar" },
    { emoji: "👔", base: "Dress", past: "Dressed", pastParticiple: "Dressed", continuous: "Dressing", spanish: "Vestir" },
    { emoji: "👕", base: "Undress", past: "Undressed", pastParticiple: "Undressed", continuous: "Undressing", spanish: "Desvestir" },
    { emoji: "👗", base: "Wear", past: "Wore", pastParticiple: "Worn", continuous: "Wearing", spanish: "Usar" },
    { emoji: "🧦", base: "Put on", past: "Put on", pastParticiple: "Put on", continuous: "Putting on", spanish: "Ponerse" },
    { emoji: "👞", base: "Take off", past: "Took off", pastParticiple: "Taken off", continuous: "Taking off", spanish: "Quitarse" },
    { emoji: "🎩", base: "Try on", past: "Tried on", pastParticiple: "Tried on", continuous: "Trying on", spanish: "Probarse" },
    { emoji: "👜", base: "Carry", past: "Carried", pastParticiple: "Carried", continuous: "Carrying", spanish: "Llevar" },
    { emoji: "🎒", base: "Pack", past: "Packed", pastParticiple: "Packed", continuous: "Packing", spanish: "Empacar" },
    { emoji: "📦", base: "Unpack", past: "Unpacked", pastParticiple: "Unpacked", continuous: "Unpacking", spanish: "Desempacar" },
    { emoji: "🧳", base: "Travel", past: "Traveled", pastParticiple: "Traveled", continuous: "Traveling", spanish: "Viajar" },
    { emoji: "✈️", base: "Fly", past: "Flew", pastParticiple: "Flown", continuous: "Flying", spanish: "Volar" },
    { emoji: "🚢", base: "Sail", past: "Sailed", pastParticiple: "Sailed", continuous: "Sailing", spanish: "Navegar" },
    { emoji: "🚴", base: "Ride", past: "Rode", pastParticiple: "Ridden", continuous: "Riding", spanish: "Montar" },
    { emoji: "🏔️", base: "Climb", past: "Climbed", pastParticiple: "Climbed", continuous: "Climbing", spanish: "Escalar" },
    { emoji: "⛷️", base: "Ski", past: "Skied", pastParticiple: "Skied", continuous: "Skiing", spanish: "Esquiar" },
    { emoji: "🏄", base: "Surf", past: "Surfed", pastParticiple: "Surfed", continuous: "Surfing", spanish: "Surfear" },
    { emoji: "🎣", base: "Fish", past: "Fished", pastParticiple: "Fished", continuous: "Fishing", spanish: "Pescar" },
    { emoji: "🏕️", base: "Camp", past: "Camped", pastParticiple: "Camped", continuous: "Camping", spanish: "Acampar" },
    { emoji: "🔥", base: "Light", past: "Lit", pastParticiple: "Lit", continuous: "Lighting", spanish: "Encender" },
    { emoji: "💡", base: "Turn on", past: "Turned on", pastParticiple: "Turned on", continuous: "Turning on", spanish: "Prender" },
    { emoji: "🌑", base: "Turn off", past: "Turned off", pastParticiple: "Turned off", continuous: "Turning off", spanish: "Apagar" },
    { emoji: "🔊", base: "Raise", past: "Raised", pastParticiple: "Raised", continuous: "Raising", spanish: "Subir" },
    { emoji: "🔉", base: "Lower", past: "Lowered", pastParticiple: "Lowered", continuous: "Lowering", spanish: "Bajar" },
    { emoji: "🔇", base: "Mute", past: "Muted", pastParticiple: "Muted", continuous: "Muting", spanish: "Silenciar" },
    { emoji: "🎤", base: "Record", past: "Recorded", pastParticiple: "Recorded", continuous: "Recording", spanish: "Grabar" },
    { emoji: "📹", base: "Film", past: "Filmed", pastParticiple: "Filmed", continuous: "Filming", spanish: "Filmar" },
    { emoji: "📸", base: "Photograph", past: "Photographed", pastParticiple: "Photographed", continuous: "Photographing", spanish: "Fotografiar" },
    { emoji: "🖼️", base: "Frame", past: "Framed", pastParticiple: "Framed", continuous: "Framing", spanish: "Enmarcar" },
    { emoji: "🎭", base: "Perform", past: "Performed", pastParticiple: "Performed", continuous: "Performing", spanish: "Actuar" },
    { emoji: "🎪", base: "Entertain", past: "Entertained", pastParticiple: "Entertained", continuous: "Entertaining", spanish: "Entretener" },
    { emoji: "🎸", base: "Strum", past: "Strummed", pastParticiple: "Strummed", continuous: "Strumming", spanish: "Rasguear" },
    { emoji: "🥁", base: "Beat", past: "Beat", pastParticiple: "Beaten", continuous: "Beating", spanish: "Golpear" },
    { emoji: "🎹", base: "Compose", past: "Composed", pastParticiple: "Composed", continuous: "Composing", spanish: "Componer" },
    { emoji: "🎼", base: "Arrange", past: "Arranged", pastParticiple: "Arranged", continuous: "Arranging", spanish: "Arreglar" },
    { emoji: "🎺", base: "Blow", past: "Blew", pastParticiple: "Blown", continuous: "Blowing", spanish: "Tocar (instrumento de viento)" },
    { emoji: "🎻", base: "Play", past: "Played", pastParticiple: "Played", continuous: "Playing", spanish: "Tocar (instrumento)" },
    { emoji: "📻", base: "Broadcast", past: "Broadcast", pastParticiple: "Broadcast", continuous: "Broadcasting", spanish: "Transmitir" },
    { emoji: "🏆", base: "Win", past: "Won", pastParticiple: "Won", continuous: "Winning", spanish: "Ganar" },
    { emoji: "😞", base: "Lose", past: "Lost", pastParticiple: "Lost", continuous: "Losing", spanish: "Perder (competencia)" },
    { emoji: "🎲", base: "Bet", past: "Bet", pastParticiple: "Bet", continuous: "Betting", spanish: "Apostar" },
    { emoji: "🤹", base: "Juggle", past: "Juggled", pastParticiple: "Juggled", continuous: "Juggling", spanish: "Hacer malabares" },
    { emoji: "🧗", base: "Scale", past: "Scaled", pastParticiple: "Scaled", continuous: "Scaling", spanish: "Escalar" },
    { emoji: "🏋️", base: "Exercise", past: "Exercised", pastParticiple: "Exercised", continuous: "Exercising", spanish: "Ejercitarse" },
    { emoji: "🤾", base: "Throw", past: "Threw", pastParticiple: "Thrown", continuous: "Throwing", spanish: "Lanzar" },
    { emoji: "🤺", base: "Catch", past: "Caught", pastParticiple: "Caught", continuous: "Catching", spanish: "Atrapar" },
    { emoji: "⚽", base: "Kick", past: "Kicked", pastParticiple: "Kicked", continuous: "Kicking", spanish: "Patear" },
    { emoji: "🏀", base: "Bounce", past: "Bounced", pastParticiple: "Bounced", continuous: "Bouncing", spanish: "Rebotar" },
    { emoji: "🎾", base: "Serve", past: "Served", pastParticiple: "Served", continuous: "Serving", spanish: "Servir (deportes)" },
    { emoji: "🏐", base: "Spike", past: "Spiked", pastParticiple: "Spiked", continuous: "Spiking", spanish: "Rematar" },
    { emoji: "🏈", base: "Tackle", past: "Tackled", pastParticiple: "Tackled", continuous: "Tackling", spanish: "Tacklear" },
    { emoji: "🎯", base: "Aim", past: "Aimed", pastParticiple: "Aimed", continuous: "Aiming", spanish: "Apuntar" },
    { emoji: "🏹", base: "Shoot", past: "Shot", pastParticiple: "Shot", continuous: "Shooting", spanish: "Disparar" },
    { emoji: "🎱", base: "Strike", past: "Struck", pastParticiple: "Struck", continuous: "Striking", spanish: "Golpear" },
    { emoji: "🥊", base: "Punch", past: "Punched", pastParticiple: "Punched", continuous: "Punching", spanish: "Golpear con el puño" },
    { emoji: "🥋", base: "Practice", past: "Practiced", pastParticiple: "Practiced", continuous: "Practicing", spanish: "Practicar" },
    { emoji: "🧩", base: "Solve", past: "Solved", pastParticiple: "Solved", continuous: "Solving", spanish: "Resolver" },
    { emoji: "🔐", base: "Protect", past: "Protected", pastParticiple: "Protected", continuous: "Protecting", spanish: "Proteger" },
    { emoji: "🛡️", base: "Defend", past: "Defended", pastParticiple: "Defended", continuous: "Defending", spanish: "Defender" },
    { emoji: "⚔️", base: "Attack", past: "Attacked", pastParticiple: "Attacked", continuous: "Attacking", spanish: "Atacar" },
    { emoji: "🗡️", base: "Fight", past: "Fought", pastParticiple: "Fought", continuous: "Fighting", spanish: "Pelear" },
    { emoji: "🏳️", base: "Surrender", past: "Surrendered", pastParticiple: "Surrendered", continuous: "Surrendering", spanish: "Rendirse" },
    { emoji: "✌️", base: "Negotiate", past: "Negotiated", pastParticiple: "Negotiated", continuous: "Negotiating", spanish: "Negociar" },
    { emoji: "🤝", base: "Agree", past: "Agreed", pastParticiple: "Agreed", continuous: "Agreeing", spanish: "Estar de acuerdo" },
    { emoji: "🙅", base: "Disagree", past: "Disagreed", pastParticiple: "Disagreed", continuous: "Disagreeing", spanish: "No estar de acuerdo" },
    { emoji: "💪", base: "Insist", past: "Insisted", pastParticiple: "Insisted", continuous: "Insisting", spanish: "Insistir" },
    { emoji: "🙏", base: "Beg", past: "Begged", pastParticiple: "Begged", continuous: "Begging", spanish: "Rogar" },
    { emoji: "🎭", base: "Pretend", past: "Pretended", pastParticiple: "Pretended", continuous: "Pretending", spanish: "Fingir" },
    { emoji: "🤥", base: "Lie", past: "Lied", pastParticiple: "Lied", continuous: "Lying", spanish: "Mentir" },
    { emoji: "🤫", base: "Hide", past: "Hid", pastParticiple: "Hidden", continuous: "Hiding", spanish: "Esconder" },
    { emoji: "🔍", base: "Discover", past: "Discovered", pastParticiple: "Discovered", continuous: "Discovering", spanish: "Descubrir" },
    { emoji: "🧪", base: "Experiment", past: "Experimented", pastParticiple: "Experimented", continuous: "Experimenting", spanish: "Experimentar" },
    { emoji: "🔬", base: "Examine", past: "Examined", pastParticiple: "Examined", continuous: "Examining", spanish: "Examinar" },
    { emoji: "📊", base: "Analyze", past: "Analyzed", pastParticiple: "Analyzed", continuous: "Analyzing", spanish: "Analizar" },
    { emoji: "📈", base: "Increase", past: "Increased", pastParticiple: "Increased", continuous: "Increasing", spanish: "Aumentar" },
    { emoji: "📉", base: "Decrease", past: "Decreased", pastParticiple: "Decreased", continuous: "Decreasing", spanish: "Disminuir" },
    { emoji: "⚖️", base: "Compare", past: "Compared", pastParticiple: "Compared", continuous: "Comparing", spanish: "Comparar" },
    { emoji: "🔗", base: "Connect", past: "Connected", pastParticiple: "Connected", continuous: "Connecting", spanish: "Conectar" },
    { emoji: "✂️", base: "Disconnect", past: "Disconnected", pastParticiple: "Disconnected", continuous: "Disconnecting", spanish: "Desconectar" },
    { emoji: "🔌", base: "Plug in", past: "Plugged in", pastParticiple: "Plugged in", continuous: "Plugging in", spanish: "Enchufar" },
    { emoji: "🔋", base: "Charge", past: "Charged", pastParticiple: "Charged", continuous: "Charging", spanish: "Cargar" },
    { emoji: "🪫", base: "Drain", past: "Drained", pastParticiple: "Drained", continuous: "Draining", spanish: "Drenar" },
    { emoji: "💻", base: "Type", past: "Typed", pastParticiple: "Typed", continuous: "Typing", spanish: "Teclear" },
    { emoji: "🖱️", base: "Click", past: "Clicked", pastParticiple: "Clicked", continuous: "Clicking", spanish: "Hacer clic" },
    { emoji: "📱", base: "Swipe", past: "Swiped", pastParticiple: "Swiped", continuous: "Swiping", spanish: "Deslizar" },
    { emoji: "⌨️", base: "Enter", past: "Entered", pastParticiple: "Entered", continuous: "Entering", spanish: "Ingresar" },
    { emoji: "⬆️", base: "Upload", past: "Uploaded", pastParticiple: "Uploaded", continuous: "Uploading", spanish: "Subir (archivo)" },
    { emoji: "⬇️", base: "Download", past: "Downloaded", pastParticiple: "Downloaded", continuous: "Downloading", spanish: "Descargar" },
    { emoji: "🌐", base: "Browse", past: "Browsed", pastParticiple: "Browsed", continuous: "Browsing", spanish: "Navegar" },
    { emoji: "🔄", base: "Refresh", past: "Refreshed", pastParticiple: "Refreshed", continuous: "Refreshing", spanish: "Actualizar" },
    { emoji: "❌", base: "Cancel", past: "Canceled", pastParticiple: "Canceled", continuous: "Canceling", spanish: "Cancelar" },
    { emoji: "✔️", base: "Confirm", past: "Confirmed", pastParticiple: "Confirmed", continuous: "Confirming", spanish: "Confirmar" },
    { emoji: "⚠️", base: "Warn", past: "Warned", pastParticiple: "Warned", continuous: "Warning", spanish: "Advertir" },
    { emoji: "🚨", base: "Alert", past: "Alerted", pastParticiple: "Alerted", continuous: "Alerting", spanish: "Alertar" },
    { emoji: "📢", base: "Announce", past: "Announced", pastParticiple: "Announced", continuous: "Announcing", spanish: "Anunciar" },
    { emoji: "📣", base: "Declare", past: "Declared", pastParticiple: "Declared", continuous: "Declaring", spanish: "Declarar" },
    { emoji: "🗳️", base: "Vote", past: "Voted", pastParticiple: "Voted", continuous: "Voting", spanish: "Votar" },
    { emoji: "📝", base: "Register", past: "Registered", pastParticiple: "Registered", continuous: "Registering", spanish: "Registrar" },
    { emoji: "✍️", base: "Subscribe", past: "Subscribed", pastParticiple: "Subscribed", continuous: "Subscribing", spanish: "Suscribirse" },
    { emoji: "🚫", base: "Unsubscribe", past: "Unsubscribed", pastParticiple: "Unsubscribed", continuous: "Unsubscribing", spanish: "Cancelar suscripción" },
    { emoji: "📧", base: "Email", past: "Emailed", pastParticiple: "Emailed", continuous: "Emailing", spanish: "Enviar correo" },
    { emoji: "💬", base: "Chat", past: "Chatted", pastParticiple: "Chatted", continuous: "Chatting", spanish: "Chatear" },
    { emoji: "🗨️", base: "Text", past: "Texted", pastParticiple: "Texted", continuous: "Texting", spanish: "Enviar mensaje de texto" },
    { emoji: "📞", base: "Ring", past: "Rang", pastParticiple: "Rung", continuous: "Ringing", spanish: "Sonar" },
    { emoji: "🔔", base: "Notify", past: "Notified", pastParticiple: "Notified", continuous: "Notifying", spanish: "Notificar" },
    { emoji: "🔕", base: "Silence", past: "Silenced", pastParticiple: "Silenced", continuous: "Silencing", spanish: "Silenciar" },
    { emoji: "📺", base: "Watch", past: "Watched", pastParticiple: "Watched", continuous: "Watching", spanish: "Ver (TV)" },
    { emoji: "🎬", base: "Direct", past: "Directed", pastParticiple: "Directed", continuous: "Directing", spanish: "Dirigir" },
    { emoji: "🎥", base: "Produce", past: "Produced", pastParticiple: "Produced", continuous: "Producing", spanish: "Producir" },
    { emoji: "✂️", base: "Edit", past: "Edited", pastParticiple: "Edited", continuous: "Editing", spanish: "Editar" },
    { emoji: "🎨", base: "Design", past: "Designed", pastParticiple: "Designed", continuous: "Designing", spanish: "Diseñar" },
    { emoji: "🖌️", base: "Paint", past: "Painted", pastParticiple: "Painted", continuous: "Painting", spanish: "Pintar" },
    { emoji: "🖍️", base: "Color", past: "Colored", pastParticiple: "Colored", continuous: "Coloring", spanish: "Colorear" },
    { emoji: "✏️", base: "Sketch", past: "Sketched", pastParticiple: "Sketched", continuous: "Sketching", spanish: "Esbozar" },
    { emoji: "🖊️", base: "Trace", past: "Traced", pastParticiple: "Traced", continuous: "Tracing", spanish: "Trazar" },
    { emoji: "📏", base: "Align", past: "Aligned", pastParticiple: "Aligned", continuous: "Aligning", spanish: "Alinear" },
    { emoji: "🔲", base: "Shape", past: "Shaped", pastParticiple: "Shaped", continuous: "Shaping", spanish: "Dar forma" },
    { emoji: "🌈", base: "Brighten", past: "Brightened", pastParticiple: "Brightened", continuous: "Brightening", spanish: "Iluminar" },
    { emoji: "🌑", base: "Darken", past: "Darkened", pastParticiple: "Darkened", continuous: "Darkening", spanish: "Oscurecer" },
    { emoji: "💫", base: "Shine", past: "Shone", pastParticiple: "Shone", continuous: "Shining", spanish: "Brillar" },
    { emoji: "✨", base: "Sparkle", past: "Sparkled", pastParticiple: "Sparkled", continuous: "Sparkling", spanish: "Destellar" },
    { emoji: "🌟", base: "Glow", past: "Glowed", pastParticiple: "Glowed", continuous: "Glowing", spanish: "Resplandecer" },
    { emoji: "💥", base: "Explode", past: "Exploded", pastParticiple: "Exploded", continuous: "Exploding", spanish: "Explotar" },
    { emoji: "💨", base: "Vanish", past: "Vanished", pastParticiple: "Vanished", continuous: "Vanishing", spanish: "Desaparecer" },
    { emoji: "👻", base: "Appear", past: "Appeared", pastParticiple: "Appeared", continuous: "Appearing", spanish: "Aparecer" },
    { emoji: "🔮", base: "Predict", past: "Predicted", pastParticiple: "Predicted", continuous: "Predicting", spanish: "Predecir" },
    { emoji: "🎰", base: "Gamble", past: "Gambled", pastParticiple: "Gambled", continuous: "Gambling", spanish: "Jugar (apuestas)" },
    { emoji: "🎲", base: "Roll", past: "Rolled", pastParticiple: "Rolled", continuous: "Rolling", spanish: "Rodar" },
    { emoji: "🃏", base: "Shuffle", past: "Shuffled", pastParticiple: "Shuffled", continuous: "Shuffling", spanish: "Barajar" },
    { emoji: "🎴", base: "Deal", past: "Dealt", pastParticiple: "Dealt", continuous: "Dealing", spanish: "Repartir" },
    { emoji: "🏁", base: "Finish", past: "Finished", pastParticiple: "Finished", continuous: "Finishing", spanish: "Terminar" },
    { emoji: "🎊", base: "Celebrate", past: "Celebrated", pastParticiple: "Celebrated", continuous: "Celebrating", spanish: "Celebrar" },
    { emoji: "🎉", base: "Party", past: "Partied", pastParticiple: "Partied", continuous: "Partying", spanish: "Festejar" },
    { emoji: "🥳", base: "Enjoy", past: "Enjoyed", pastParticiple: "Enjoyed", continuous: "Enjoying", spanish: "Disfrutar" },
    { emoji: "😊", base: "Appreciate", past: "Appreciated", pastParticiple: "Appreciated", continuous: "Appreciating", spanish: "Apreciar" },
    { emoji: "🙌", base: "Praise", past: "Praised", pastParticiple: "Praised", continuous: "Praising", spanish: "Alabar" },
    { emoji: "👏", base: "Applaud", past: "Applauded", pastParticiple: "Applauded", continuous: "Applauding", spanish: "Aplaudir" },
    { emoji: "🤲", base: "Offer", past: "Offered", pastParticiple: "Offered", continuous: "Offering", spanish: "Ofrecer" },
    { emoji: "🎁", base: "Gift", past: "Gifted", pastParticiple: "Gifted", continuous: "Gifting", spanish: "Regalar" },
    { emoji: "💝", base: "Donate", past: "Donated", pastParticiple: "Donated", continuous: "Donating", spanish: "Donar" },
    { emoji: "🤲", base: "Share", past: "Shared", pastParticiple: "Shared", continuous: "Sharing", spanish: "Compartir" },
    { emoji: "🤗", base: "Welcome", past: "Welcomed", pastParticiple: "Welcomed", continuous: "Welcoming", spanish: "Dar la bienvenida" },
    { emoji: "👋", base: "Greet", past: "Greeted", pastParticiple: "Greeted", continuous: "Greeting", spanish: "Saludar" },
    { emoji: "👋", base: "Wave", past: "Waved", pastParticiple: "Waved", continuous: "Waving", spanish: "Saludar con la mano" },
    { emoji: "🙋", base: "Volunteer", past: "Volunteered", pastParticiple: "Volunteered", continuous: "Volunteering", spanish: "Ser voluntario" },
    { emoji: "💪", base: "Support", past: "Supported", pastParticiple: "Supported", continuous: "Supporting", spanish: "Apoyar" },
    { emoji: "🤝", base: "Help", past: "Helped", pastParticiple: "Helped", continuous: "Helping", spanish: "Ayudar" },
    { emoji: "🆘", base: "Rescue", past: "Rescued", pastParticiple: "Rescued", continuous: "Rescuing", spanish: "Rescatar" },
    { emoji: "💾", base: "Backup", past: "Backed up", pastParticiple: "Backed up", continuous: "Backing up", spanish: "Respaldar" },
    { emoji: "♻️", base: "Recycle", past: "Recycled", pastParticiple: "Recycled", continuous: "Recycling", spanish: "Reciclar" },
    { emoji: "🌱", base: "Grow", past: "Grew", pastParticiple: "Grown", continuous: "Growing", spanish: "Crecer" },
    { emoji: "🌳", base: "Plant", past: "Planted", pastParticiple: "Planted", continuous: "Planting", spanish: "Plantar" },
    { emoji: "💧", base: "Water", past: "Watered", pastParticiple: "Watered", continuous: "Watering", spanish: "Regar" },
    { emoji: "✂️", base: "Trim", past: "Trimmed", pastParticiple: "Trimmed", continuous: "Trimming", spanish: "Podar" },
    { emoji: "🌾", base: "Harvest", past: "Harvested", pastParticiple: "Harvested", continuous: "Harvesting", spanish: "Cosechar" },
    { emoji: "🥕", base: "Pick", past: "Picked", pastParticiple: "Picked", continuous: "Picking", spanish: "Recoger" },
    { emoji: "🍇", base: "Gather", past: "Gathered", pastParticiple: "Gathered", continuous: "Gathering", spanish: "Recolectar" },
    { emoji: "📡", base: "Transmit", past: "Transmitted", pastParticiple: "Transmitted", continuous: "Transmitting", spanish: "Transmitir" },
    { emoji: "🔍", base: "Investigate", past: "Investigated", pastParticiple: "Investigated", continuous: "Investigating", spanish: "Investigar" },
    { emoji: "🕵️", base: "Spy", past: "Spied", pastParticiple: "Spied", continuous: "Spying", spanish: "Espiar" },
    { emoji: "👁️", base: "Watch", past: "Watched", pastParticiple: "Watched", continuous: "Watching", spanish: "Mirar" },
    { emoji: "👀", base: "Look", past: "Looked", pastParticiple: "Looked", continuous: "Looking", spanish: "Ver" },
    { emoji: "🧐", base: "Examine", past: "Examined", pastParticiple: "Examined", continuous: "Examining", spanish: "Examinar" },
    { emoji: "🔬", base: "Analyze", past: "Analyzed", pastParticiple: "Analyzed", continuous: "Analyzing", spanish: "Analizar" },
    { emoji: "🧬", base: "Experiment", past: "Experimented", pastParticiple: "Experimented", continuous: "Experimenting", spanish: "Experimentar" },
    { emoji: "🧪", base: "Test", past: "Tested", pastParticiple: "Tested", continuous: "Testing", spanish: "Probar" },
    { emoji: "📊", base: "Graph", past: "Graphed", pastParticiple: "Graphed", continuous: "Graphing", spanish: "Graficar" },
    { emoji: "📈", base: "Increase", past: "Increased", pastParticiple: "Increased", continuous: "Increasing", spanish: "Aumentar" },
    { emoji: "📉", base: "Decrease", past: "Decreased", pastParticiple: "Decreased", continuous: "Decreasing", spanish: "Disminuir" },
    { emoji: "💹", base: "Trade", past: "Traded", pastParticiple: "Traded", continuous: "Trading", spanish: "Comerciar" },
    { emoji: "💱", base: "Exchange", past: "Exchanged", pastParticiple: "Exchanged", continuous: "Exchanging", spanish: "Intercambiar" },
    { emoji: "💸", base: "Spend", past: "Spent", pastParticiple: "Spent", continuous: "Spending", spanish: "Gastar" },
    { emoji: "💵", base: "Earn", past: "Earned", pastParticiple: "Earned", continuous: "Earning", spanish: "Ganar" },
    { emoji: "💴", base: "Invest", past: "Invested", pastParticiple: "Invested", continuous: "Investing", spanish: "Invertir" },
    { emoji: "💳", base: "Pay", past: "Paid", pastParticiple: "Paid", continuous: "Paying", spanish: "Pagar" },
    { emoji: "🏦", base: "Bank", past: "Banked", pastParticiple: "Banked", continuous: "Banking", spanish: "Depositar" },
    { emoji: "🏧", base: "Withdraw", past: "Withdrew", pastParticiple: "Withdrawn", continuous: "Withdrawing", spanish: "Retirar" },
    { emoji: "💰", base: "Collect", past: "Collected", pastParticiple: "Collected", continuous: "Collecting", spanish: "Coleccionar" },
    { emoji: "🎰", base: "Gamble", past: "Gambled", pastParticiple: "Gambled", continuous: "Gambling", spanish: "Apostar" },
    { emoji: "🎲", base: "Roll", past: "Rolled", pastParticiple: "Rolled", continuous: "Rolling", spanish: "Rodar" },
    { emoji: "🃏", base: "Shuffle", past: "Shuffled", pastParticiple: "Shuffled", continuous: "Shuffling", spanish: "Barajar" },
    { emoji: "🎯", base: "Aim", past: "Aimed", pastParticiple: "Aimed", continuous: "Aiming", spanish: "Apuntar" },
    { emoji: "🏹", base: "Shoot", past: "Shot", pastParticiple: "Shot", continuous: "Shooting", spanish: "Disparar" },
    { emoji: "🎪", base: "Juggle", past: "Juggled", pastParticiple: "Juggled", continuous: "Juggling", spanish: "Hacer malabares" },
    { emoji: "🤹", base: "Balance", past: "Balanced", pastParticiple: "Balanced", continuous: "Balancing", spanish: "Equilibrar" },
    { emoji: "🧗", base: "Scale", past: "Scaled", pastParticiple: "Scaled", continuous: "Scaling", spanish: "Escalar" },
    { emoji: "🏋️", base: "Exercise", past: "Exercised", pastParticiple: "Exercised", continuous: "Exercising", spanish: "Ejercitar" },
    { emoji: "🤸", base: "Flip", past: "Flipped", pastParticiple: "Flipped", continuous: "Flipping", spanish: "Voltear" },
    { emoji: "🧘", base: "Meditate", past: "Meditated", pastParticiple: "Meditated", continuous: "Meditating", spanish: "Meditar" },
    { emoji: "🙏", base: "Pray", past: "Prayed", pastParticiple: "Prayed", continuous: "Praying", spanish: "Rezar" },
    { emoji: "🕯️", base: "Illuminate", past: "Illuminated", pastParticiple: "Illuminated", continuous: "Illuminating", spanish: "Iluminar" },
    { emoji: "💡", base: "Think up", past: "Thought up", pastParticiple: "Thought up", continuous: "Thinking up", spanish: "Idear" },
    { emoji: "🧠", base: "Brainstorm", past: "Brainstormed", pastParticiple: "Brainstormed", continuous: "Brainstorming", spanish: "Hacer lluvia de ideas" },
    { emoji: "💭", base: "Dream", past: "Dreamed", pastParticiple: "Dreamed", continuous: "Dreaming", spanish: "Soñar" },
    { emoji: "😴", base: "Nap", past: "Napped", pastParticiple: "Napped", continuous: "Napping", spanish: "Tomar siesta" },
    { emoji: "⏰", base: "Wake up", past: "Woke up", pastParticiple: "Woken up", continuous: "Waking up", spanish: "Despertarse" },
    { emoji: "🌅", base: "Rise", past: "Rose", pastParticiple: "Risen", continuous: "Rising", spanish: "Levantarse" },
    { emoji: "🌄", base: "Set", past: "Set", pastParticiple: "Set", continuous: "Setting", spanish: "Ponerse" },
    { emoji: "🌆", base: "Shine", past: "Shone", pastParticiple: "Shone", continuous: "Shining", spanish: "Brillar" },
    { emoji: "✨", base: "Sparkle", past: "Sparkled", pastParticiple: "Sparkled", continuous: "Sparkling", spanish: "Centellear" },
    { emoji: "🌟", base: "Twinkle", past: "Twinkled", pastParticiple: "Twinkled", continuous: "Twinkling", spanish: "Titilar" },
    { emoji: "⚡", base: "Flash", past: "Flashed", pastParticiple: "Flashed", continuous: "Flashing", spanish: "Destellar" },
    { emoji: "💫", base: "Glow", past: "Glowed", pastParticiple: "Glowed", continuous: "Glowing", spanish: "Resplandecer" },
    { emoji: "🌈", base: "Appear", past: "Appeared", pastParticiple: "Appeared", continuous: "Appearing", spanish: "Aparecer" },
    { emoji: "👻", base: "Disappear", past: "Disappeared", pastParticiple: "Disappeared", continuous: "Disappearing", spanish: "Desaparecer" },
  ];

  const irregularVerbs = [
    { emoji: "🏃", base: "Run", past: "Ran", pastParticiple: "Run", continuous: "Running", spanish: "Correr" },
    { emoji: "✍️", base: "Write", past: "Wrote", pastParticiple: "Written", continuous: "Writing", spanish: "Escribir" },
    { emoji: "👀", base: "See", past: "Saw", pastParticiple: "Seen", continuous: "Seeing", spanish: "Ver" },
    { emoji: "🗣️", base: "Speak", past: "Spoke", pastParticiple: "Spoken", continuous: "Speaking", spanish: "Hablar" },
    { emoji: "🎵", base: "Sing", past: "Sang", pastParticiple: "Sung", continuous: "Singing", spanish: "Cantar" },
    { emoji: "🏊", base: "Swim", past: "Swam", pastParticiple: "Swum", continuous: "Swimming", spanish: "Nadar" },
    { emoji: "🚗", base: "Drive", past: "Drove", pastParticiple: "Driven", continuous: "Driving", spanish: "Conducir" },
    { emoji: "🎨", base: "Draw", past: "Drew", pastParticiple: "Drawn", continuous: "Drawing", spanish: "Dibujar" },
    { emoji: "🛒", base: "Buy", past: "Bought", pastParticiple: "Bought", continuous: "Buying", spanish: "Comprar" },
    { emoji: "💰", base: "Sell", past: "Sold", pastParticiple: "Sold", continuous: "Selling", spanish: "Vender" },
    { emoji: "🎁", base: "Give", past: "Gave", pastParticiple: "Given", continuous: "Giving", spanish: "Dar" },
    { emoji: "🤝", base: "Take", past: "Took", pastParticiple: "Taken", continuous: "Taking", spanish: "Tomar" },
    { emoji: "🚪", base: "Come", past: "Came", pastParticiple: "Come", continuous: "Coming", spanish: "Venir" },
    { emoji: "🚶‍♂️", base: "Go", past: "Went", pastParticiple: "Gone", continuous: "Going", spanish: "Ir" },
    { emoji: "🍽️", base: "Eat", past: "Ate", pastParticiple: "Eaten", continuous: "Eating", spanish: "Comer" },
    { emoji: "🥤", base: "Drink", past: "Drank", pastParticiple: "Drunk", continuous: "Drinking", spanish: "Beber" },
    { emoji: "🔍", base: "Find", past: "Found", pastParticiple: "Found", continuous: "Finding", spanish: "Encontrar" },
    { emoji: "🙈", base: "Lose", past: "Lost", pastParticiple: "Lost", continuous: "Losing", spanish: "Perder" },
    { emoji: "🎯", base: "Choose", past: "Chose", pastParticiple: "Chosen", continuous: "Choosing", spanish: "Elegir" },
    { emoji: "🗨️", base: "Say", past: "Said", pastParticiple: "Said", continuous: "Saying", spanish: "Decir" },
    { emoji: "💬", base: "Tell", past: "Told", pastParticiple: "Told", continuous: "Telling", spanish: "Contar" },
    { emoji: "👂", base: "Hear", past: "Heard", pastParticiple: "Heard", continuous: "Hearing", spanish: "Oír" },
    { emoji: "🧍", base: "Stand", past: "Stood", pastParticiple: "Stood", continuous: "Standing", spanish: "Estar de pie" },
    { emoji: "🪑", base: "Sit", past: "Sat", pastParticiple: "Sat", continuous: "Sitting", spanish: "Sentarse" },
    { emoji: "🤲", base: "Hold", past: "Held", pastParticiple: "Held", continuous: "Holding", spanish: "Sostener" },
    { emoji: "🔨", base: "Build", past: "Built", pastParticiple: "Built", continuous: "Building", spanish: "Construir" },
    { emoji: "✂️", base: "Cut", past: "Cut", pastParticiple: "Cut", continuous: "Cutting", spanish: "Cortar" },
    { emoji: "👨‍🏫", base: "Teach", past: "Taught", pastParticiple: "Taught", continuous: "Teaching", spanish: "Enseñar" },
    { emoji: "🤔", base: "Know", past: "Knew", pastParticiple: "Known", continuous: "Knowing", spanish: "Saber" },
    { emoji: "🤷", base: "Forget", past: "Forgot", pastParticiple: "Forgotten", continuous: "Forgetting", spanish: "Olvidar" },
    { emoji: "🤝", base: "Meet", past: "Met", pastParticiple: "Met", continuous: "Meeting", spanish: "Conocer" },
    { emoji: "📞", base: "Ring", past: "Rang", pastParticiple: "Rung", continuous: "Ringing", spanish: "Sonar" },
    { emoji: "💌", base: "Send", past: "Sent", pastParticiple: "Sent", continuous: "Sending", spanish: "Enviar" },
    { emoji: "🧠", base: "Think", past: "Thought", pastParticiple: "Thought", continuous: "Thinking", spanish: "Pensar" },
    { emoji: "🛏️", base: "Sleep", past: "Slept", pastParticiple: "Slept", continuous: "Sleeping", spanish: "Dormir" },
    { emoji: "📖", base: "Read", past: "Read", pastParticiple: "Read", continuous: "Reading", spanish: "Leer" },
    { emoji: "🏠", base: "Leave", past: "Left", pastParticiple: "Left", continuous: "Leaving", spanish: "Salir" },
    { emoji: "💔", base: "Break", past: "Broke", pastParticiple: "Broken", continuous: "Breaking", spanish: "Romper" },
    { emoji: "🔥", base: "Burn", past: "Burned/Burnt", pastParticiple: "Burned/Burnt", continuous: "Burning", spanish: "Quemar" },
    { emoji: "🧊", base: "Freeze", past: "Froze", pastParticiple: "Frozen", continuous: "Freezing", spanish: "Congelar" },
    { emoji: "💨", base: "Blow", past: "Blew", pastParticiple: "Blown", continuous: "Blowing", spanish: "Soplar" },
    { emoji: "🤾", base: "Throw", past: "Threw", pastParticiple: "Thrown", continuous: "Throwing", spanish: "Lanzar" },
    { emoji: "🤺", base: "Catch", past: "Caught", pastParticiple: "Caught", continuous: "Catching", spanish: "Atrapar" },
    { emoji: "🏹", base: "Shoot", past: "Shot", pastParticiple: "Shot", continuous: "Shooting", spanish: "Disparar" },
    { emoji: "🎱", base: "Strike", past: "Struck", pastParticiple: "Struck", continuous: "Striking", spanish: "Golpear" },
    { emoji: "🗡️", base: "Fight", past: "Fought", pastParticiple: "Fought", continuous: "Fighting", spanish: "Pelear" },
    { emoji: "🤫", base: "Hide", past: "Hid", pastParticiple: "Hidden", continuous: "Hiding", spanish: "Esconder" },
    { emoji: "🧵", base: "Sew", past: "Sewed", pastParticiple: "Sewn", continuous: "Sewing", spanish: "Coser" },
    { emoji: "🏆", base: "Win", past: "Won", pastParticiple: "Won", continuous: "Winning", spanish: "Ganar" },
    { emoji: "🎴", base: "Deal", past: "Dealt", pastParticiple: "Dealt", continuous: "Dealing", spanish: "Repartir" },
    { emoji: "💫", base: "Shine", past: "Shone", pastParticiple: "Shone", continuous: "Shining", spanish: "Brillar" },
    { emoji: "🌱", base: "Grow", past: "Grew", pastParticiple: "Grown", continuous: "Growing", spanish: "Crecer" },
    { emoji: "👗", base: "Wear", past: "Wore", pastParticiple: "Worn", continuous: "Wearing", spanish: "Usar/Llevar puesto" },
    { emoji: "✈️", base: "Fly", past: "Flew", pastParticiple: "Flown", continuous: "Flying", spanish: "Volar" },
    { emoji: "🚴", base: "Ride", past: "Rode", pastParticiple: "Ridden", continuous: "Riding", spanish: "Montar" },
    { emoji: "🔥", base: "Light", past: "Lit", pastParticiple: "Lit", continuous: "Lighting", spanish: "Encender" },
    { emoji: "🥁", base: "Beat", past: "Beat", pastParticiple: "Beaten", continuous: "Beating", spanish: "Golpear/Batir" },
    { emoji: "⏰", base: "Wake up", past: "Woke up", pastParticiple: "Woken up", continuous: "Waking up", spanish: "Despertarse" },
    { emoji: "🌅", base: "Rise", past: "Rose", pastParticiple: "Risen", continuous: "Rising", spanish: "Levantarse/Salir (sol)" },
    { emoji: "🌄", base: "Set", past: "Set", pastParticiple: "Set", continuous: "Setting", spanish: "Ponerse (sol)" },
    { emoji: "🏧", base: "Withdraw", past: "Withdrew", pastParticiple: "Withdrawn", continuous: "Withdrawing", spanish: "Retirar" },
    { emoji: "💳", base: "Pay", past: "Paid", pastParticiple: "Paid", continuous: "Paying", spanish: "Pagar" },
    { emoji: "💸", base: "Spend", past: "Spent", pastParticiple: "Spent", continuous: "Spending", spanish: "Gastar" },
    { emoji: "🤲", base: "Put", past: "Put", pastParticiple: "Put", continuous: "Putting", spanish: "Poner" },
    { emoji: "🎭", base: "Show", past: "Showed", pastParticiple: "Shown", continuous: "Showing", spanish: "Mostrar" },
    { emoji: "🔊", base: "Hear", past: "Heard", pastParticiple: "Heard", continuous: "Hearing", spanish: "Escuchar" },
    { emoji: "💡", base: "Mean", past: "Meant", pastParticiple: "Meant", continuous: "Meaning", spanish: "Significar" },
    { emoji: "🎯", base: "Hit", past: "Hit", pastParticiple: "Hit", continuous: "Hitting", spanish: "Golpear/Acertar" },
    { emoji: "🚪", base: "Shut", past: "Shut", pastParticiple: "Shut", continuous: "Shutting", spanish: "Cerrar" },
    { emoji: "💭", base: "Dream", past: "Dreamed/Dreamt", pastParticiple: "Dreamed/Dreamt", continuous: "Dreaming", spanish: "Soñar" },
    { emoji: "🎨", base: "Lay", past: "Laid", pastParticiple: "Laid", continuous: "Laying", spanish: "Poner/Colocar" },
    { emoji: "🔔", base: "Ring", past: "Rang", pastParticiple: "Rung", continuous: "Ringing", spanish: "Sonar/Llamar" },
    { emoji: "🌊", base: "Sink", past: "Sank", pastParticiple: "Sunk", continuous: "Sinking", spanish: "Hundirse" },
    { emoji: "🌿", base: "Spring", past: "Sprang", pastParticiple: "Sprung", continuous: "Springing", spanish: "Saltar/Brotar" },
    { emoji: "🪢", base: "Bind", past: "Bound", pastParticiple: "Bound", continuous: "Binding", spanish: "Atar" },
    { emoji: "🔪", base: "Bleed", past: "Bled", pastParticiple: "Bled", continuous: "Bleeding", spanish: "Sangrar" },
    { emoji: "💰", base: "Cost", past: "Cost", pastParticiple: "Cost", continuous: "Costing", spanish: "Costar" },
    { emoji: "🦷", base: "Bite", past: "Bit", pastParticiple: "Bitten", continuous: "Biting", spanish: "Morder" },
    { emoji: "🧠", base: "Understand", past: "Understood", pastParticiple: "Understood", continuous: "Understanding", spanish: "Entender" },
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">⚡ Verbos en Inglés</h2>
        <p className="text-muted-foreground">Aprende las conjugaciones de los verbos con pronunciación</p>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-primary text-primary-foreground">
              <th className="p-4 text-left rounded-tl-xl">Forma Base</th>
              <th className="p-4 text-left">Pasado</th>
              <th className="p-4 text-left">Participio Pasado</th>
              <th className="p-4 text-left">Presente Continuo</th>
              <th className="p-4 text-left">Español</th>
              <th className="p-4 text-center rounded-tr-xl">Pronunciar</th>
            </tr>
          </thead>
          <tbody>
            {verbs.map((verb, index) => (
              <tr
                key={verb.base}
                className={`${
                  index % 2 === 0 ? "bg-card" : "bg-muted/30"
                } hover:bg-primary/10 transition-colors`}
              >
                <td className="p-4 font-semibold">
                  <span className="text-2xl mr-2">{verb.emoji}</span>
                  {verb.base}
                </td>
                <td className="p-4">{verb.past}</td>
                <td className="p-4">{verb.pastParticiple}</td>
                <td className="p-4">{verb.continuous}</td>
                <td className="p-4 text-muted-foreground">{verb.spanish}</td>
                <td className="p-4 text-center">
                  <button
                    onClick={() => speak(verb.base)}
                    className="pronunciation-btn mx-auto"
                    aria-label={`Pronunciar ${verb.base}`}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Sección de Verbos Irregulares */}
      <div className="mt-12">
        <div className="text-center mb-6">
          <h2 className="text-4xl font-bold text-foreground mb-2">🔥 Verbos Irregulares</h2>
          <p className="text-muted-foreground">Verbos con conjugaciones especiales que no siguen las reglas regulares</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-destructive text-destructive-foreground">
                <th className="p-4 text-left rounded-tl-xl">Forma Base</th>
                <th className="p-4 text-left">Pasado</th>
                <th className="p-4 text-left">Participio Pasado</th>
                <th className="p-4 text-left">Presente Continuo</th>
                <th className="p-4 text-left">Español</th>
                <th className="p-4 text-center rounded-tr-xl">Pronunciar</th>
              </tr>
            </thead>
            <tbody>
              {irregularVerbs.map((verb, index) => (
                <tr
                  key={`irregular-${verb.base}`}
                  className={`${
                    index % 2 === 0 ? "bg-card" : "bg-muted/30"
                  } hover:bg-destructive/10 transition-colors`}
                >
                  <td className="p-4 font-semibold">
                    <span className="text-2xl mr-2">{verb.emoji}</span>
                    {verb.base}
                  </td>
                  <td className="p-4 font-bold text-destructive">{verb.past}</td>
                  <td className="p-4 font-bold text-destructive">{verb.pastParticiple}</td>
                  <td className="p-4">{verb.continuous}</td>
                  <td className="p-4 text-muted-foreground">{verb.spanish}</td>
                  <td className="p-4 text-center">
                    <button
                      onClick={() => speak(verb.base)}
                      className="pronunciation-btn mx-auto"
                      aria-label={`Pronunciar ${verb.base}`}
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
