import { Volume2, Search } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";
import { Input } from "./ui/input";
import { useState } from "react";

export const Fruits = () => {
  const { speak } = useSpeech();
  const [search, setSearch] = useState("");

  const items = [
    // Fruits
    { emoji: "🍎", english: "Apple", spanish: "Manzana", category: "fruit" },
    { emoji: "🍌", english: "Banana", spanish: "Banano", category: "fruit" },
    { emoji: "🍊", english: "Orange", spanish: "Naranja", category: "fruit" },
    { emoji: "🍇", english: "Grapes", spanish: "Uvas", category: "fruit" },
    { emoji: "🍓", english: "Strawberry", spanish: "Fresa", category: "fruit" },
    { emoji: "🍉", english: "Watermelon", spanish: "Sandía", category: "fruit" },
    { emoji: "🍑", english: "Peach", spanish: "Durazno", category: "fruit" },
    { emoji: "🍒", english: "Cherry", spanish: "Cereza", category: "fruit" },
    { emoji: "🍍", english: "Pineapple", spanish: "Piña", category: "fruit" },
    { emoji: "🥝", english: "Kiwi", spanish: "Kiwi", category: "fruit" },
    { emoji: "🍐", english: "Pear", spanish: "Pera", category: "fruit" },
    { emoji: "🥭", english: "Mango", spanish: "Mango", category: "fruit" },
    { emoji: "🍋", english: "Lemon", spanish: "Limón", category: "fruit" },
    { emoji: "🥥", english: "Coconut", spanish: "Coco", category: "fruit" },
    { emoji: "🫐", english: "Blueberry", spanish: "Arándano", category: "fruit" },
    // Vegetables
    { emoji: "🥕", english: "Carrot", spanish: "Zanahoria", category: "vegetable" },
    { emoji: "🍅", english: "Tomato", spanish: "Tomate", category: "vegetable" },
    { emoji: "🥔", english: "Potato", spanish: "Papa", category: "vegetable" },
    { emoji: "🥒", english: "Cucumber", spanish: "Pepino", category: "vegetable" },
    { emoji: "🌽", english: "Corn", spanish: "Maíz", category: "vegetable" },
    { emoji: "🥬", english: "Lettuce", spanish: "Lechuga", category: "vegetable" },
    { emoji: "🧅", english: "Onion", spanish: "Cebolla", category: "vegetable" },
    { emoji: "🧄", english: "Garlic", spanish: "Ajo", category: "vegetable" },
    { emoji: "🥦", english: "Broccoli", spanish: "Brócoli", category: "vegetable" },
    { emoji: "🫑", english: "Bell Pepper", spanish: "Pimiento", category: "vegetable" },
    { emoji: "🌶️", english: "Chili Pepper", spanish: "Chile", category: "vegetable" },
    { emoji: "🍆", english: "Eggplant", spanish: "Berenjena", category: "vegetable" },
    { emoji: "🥗", english: "Salad", spanish: "Ensalada", category: "vegetable" },
    { emoji: "🥑", english: "Avocado", spanish: "Aguacate", category: "vegetable" },
    { emoji: "🫛", english: "Peas", spanish: "Guisantes", category: "vegetable" },
    // More fruits
    { emoji: "🍈", english: "Melon", spanish: "Melón", category: "fruit" },
    { emoji: "🥭", english: "Papaya", spanish: "Papaya", category: "fruit" },
    { emoji: "🍏", english: "Green Apple", spanish: "Manzana Verde", category: "fruit" },
    { emoji: "🫒", english: "Olive", spanish: "Aceituna", category: "fruit" },
    { emoji: "🥝", english: "Dragon Fruit", spanish: "Fruta del Dragón", category: "fruit" },
    { emoji: "🍋", english: "Lime", spanish: "Lima", category: "fruit" },
    { emoji: "🍑", english: "Apricot", spanish: "Albaricoque", category: "fruit" },
    { emoji: "🍒", english: "Cranberry", spanish: "Arándano Rojo", category: "fruit" },
    { emoji: "🍓", english: "Raspberry", spanish: "Frambuesa", category: "fruit" },
    { emoji: "🫐", english: "Blackberry", spanish: "Mora", category: "fruit" },
    { emoji: "🍇", english: "Raisins", spanish: "Pasas", category: "fruit" },
    { emoji: "🥥", english: "Palm", spanish: "Palma", category: "fruit" },
    { emoji: "🍊", english: "Tangerine", spanish: "Mandarina", category: "fruit" },
    { emoji: "🍊", english: "Clementine", spanish: "Clementina", category: "fruit" },
    { emoji: "🍑", english: "Nectarine", spanish: "Nectarina", category: "fruit" },
    { emoji: "🍐", english: "Quince", spanish: "Membrillo", category: "fruit" },
    { emoji: "🍒", english: "Acerola", spanish: "Acerola", category: "fruit" },
    { emoji: "🥭", english: "Guava", spanish: "Guayaba", category: "fruit" },
    { emoji: "🍋", english: "Grapefruit", spanish: "Toronja", category: "fruit" },
    { emoji: "🍍", english: "Passion Fruit", spanish: "Maracuyá", category: "fruit" },
    // More vegetables
    { emoji: "🥬", english: "Cabbage", spanish: "Repollo", category: "vegetable" },
    { emoji: "🥒", english: "Zucchini", spanish: "Calabacín", category: "vegetable" },
    { emoji: "🍠", english: "Sweet Potato", spanish: "Batata", category: "vegetable" },
    { emoji: "🥕", english: "Radish", spanish: "Rábano", category: "vegetable" },
    { emoji: "🥔", english: "Yam", spanish: "Ñame", category: "vegetable" },
    { emoji: "🌽", english: "Popcorn", spanish: "Palomitas", category: "vegetable" },
    { emoji: "🍄", english: "Mushroom", spanish: "Hongo", category: "vegetable" },
    { emoji: "🥬", english: "Spinach", spanish: "Espinaca", category: "vegetable" },
    { emoji: "🥒", english: "Pickle", spanish: "Pepinillo", category: "vegetable" },
    { emoji: "🌶️", english: "Jalapeño", spanish: "Jalapeño", category: "vegetable" },
    { emoji: "🫑", english: "Green Pepper", spanish: "Pimiento Verde", category: "vegetable" },
    { emoji: "🥦", english: "Cauliflower", spanish: "Coliflor", category: "vegetable" },
    { emoji: "🧅", english: "Shallot", spanish: "Chalote", category: "vegetable" },
    { emoji: "🧄", english: "Leek", spanish: "Puerro", category: "vegetable" },
    { emoji: "🥗", english: "Arugula", spanish: "Rúcula", category: "vegetable" },
    { emoji: "🥬", english: "Kale", spanish: "Col Rizada", category: "vegetable" },
    { emoji: "🥕", english: "Beet", spanish: "Remolacha", category: "vegetable" },
    { emoji: "🌽", english: "Celery", spanish: "Apio", category: "vegetable" },
    { emoji: "🍅", english: "Cherry Tomato", spanish: "Tomate Cherry", category: "vegetable" },
    { emoji: "🥒", english: "Squash", spanish: "Calabaza", category: "vegetable" },
    { emoji: "🥔", english: "Cassava", spanish: "Yuca", category: "vegetable" },
    { emoji: "🌽", english: "Asparagus", spanish: "Espárrago", category: "vegetable" },
    { emoji: "🥬", english: "Chard", spanish: "Acelga", category: "vegetable" },
    { emoji: "🥒", english: "Kohlrabi", spanish: "Colinabo", category: "vegetable" },
    { emoji: "🧅", english: "Spring Onion", spanish: "Cebolla de Verdeo", category: "vegetable" },
    { emoji: "🫑", english: "Red Pepper", spanish: "Pimiento Rojo", category: "vegetable" },
    { emoji: "🥔", english: "Turnip", spanish: "Nabo", category: "vegetable" },
    { emoji: "🥕", english: "Parsnip", spanish: "Chirivía", category: "vegetable" },
    { emoji: "🌽", english: "Artichoke", spanish: "Alcachofa", category: "vegetable" },
    { emoji: "🥬", english: "Brussels Sprout", spanish: "Col de Bruselas", category: "vegetable" },
    { emoji: "🍄", english: "Truffle", spanish: "Trufa", category: "vegetable" },
    { emoji: "🥒", english: "Gherkin", spanish: "Pepinillo Encurtido", category: "vegetable" },
    { emoji: "🫛", english: "Green Bean", spanish: "Ejote", category: "vegetable" },
    { emoji: "🥬", english: "Endive", spanish: "Endivia", category: "vegetable" },
    { emoji: "🥒", english: "Pumpkin", spanish: "Calabaza Grande", category: "vegetable" },
    { emoji: "🌽", english: "Baby Corn", spanish: "Maíz Bebé", category: "vegetable" },
    { emoji: "🍄", english: "Shiitake", spanish: "Shiitake", category: "vegetable" },
    { emoji: "🍄", english: "Portobello", spanish: "Portobello", category: "vegetable" },
  ];

  const filteredItems = items.filter(
    (item) =>
      item.english.toLowerCase().includes(search.toLowerCase()) ||
      item.spanish.toLowerCase().includes(search.toLowerCase())
  );

  const fruits = filteredItems.filter((item) => item.category === "fruit");
  const vegetables = filteredItems.filter((item) => item.category === "vegetable");

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🍎 Frutas y Verduras</h2>
        <p className="text-muted-foreground">Aprende los nombres de frutas y verduras en inglés</p>
      </div>

      <div className="max-w-md mx-auto relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Buscar frutas o verduras..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      {fruits.length > 0 && (
        <div>
          <h3 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-2">
            <span className="text-3xl">🍓</span> Frutas
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {fruits.map((item) => (
              <div key={item.english} className="learn-card flex items-center justify-between bg-accent">
                <div className="flex items-center gap-3">
                  <span className="text-4xl">{item.emoji}</span>
                  <div>
                    <p className="font-bold text-foreground">{item.english}</p>
                    <p className="text-sm text-muted-foreground">{item.spanish}</p>
                  </div>
                </div>
                <button
                  onClick={() => speak(item.english)}
                  className="pronunciation-btn"
                  aria-label={`Pronounce ${item.english}`}
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {vegetables.length > 0 && (
        <div>
          <h3 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-2">
            <span className="text-3xl">🥕</span> Verduras
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {vegetables.map((item) => (
              <div key={item.english} className="learn-card flex items-center justify-between bg-secondary">
                <div className="flex items-center gap-3">
                  <span className="text-4xl">{item.emoji}</span>
                  <div>
                    <p className="font-bold text-foreground">{item.english}</p>
                    <p className="text-sm text-muted-foreground">{item.spanish}</p>
                  </div>
                </div>
                <button
                  onClick={() => speak(item.english)}
                  className="pronunciation-btn"
                  aria-label={`Pronounce ${item.english}`}
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {filteredItems.length === 0 && (
        <p className="text-center text-muted-foreground">No se encontraron resultados. Intenta con otra búsqueda.</p>
      )}
    </div>
  );
};
