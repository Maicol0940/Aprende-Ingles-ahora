interface NavigationProps {
  onNavigate: (section: string) => void;
}

export const Navigation = ({ onNavigate }: NavigationProps) => {
  const sections = [
    { id: "alphabet", emoji: "🔤", name: "Abecedario", color: "bg-primary" },
    { id: "verbs", emoji: "⚡", name: "Verbos", color: "bg-secondary" },
    { id: "fruits", emoji: "🍎", name: "Frutas y Verduras", color: "bg-accent" },
    { id: "foods", emoji: "🍕", name: "Comidas", color: "bg-coral" },
    { id: "professions", emoji: "👷", name: "Profesiones", color: "bg-lavender" },
    { id: "objects", emoji: "📦", name: "Objetos", color: "bg-success" },
    { id: "houseParts", emoji: "🏠", name: "Partes de la Casa", color: "bg-accent" },
    { id: "bodyParts", emoji: "🧍", name: "Partes del Cuerpo", color: "bg-primary" },
    { id: "numbers", emoji: "🔢", name: "Números", color: "bg-secondary" },
    { id: "sports", emoji: "⚽", name: "Deportes", color: "bg-primary" },
    { id: "animals", emoji: "🦁", name: "Animales", color: "bg-primary" },
    { id: "colors", emoji: "🎨", name: "Colores", color: "bg-secondary" },
    { id: "weather", emoji: "🌤️", name: "Clima", color: "bg-accent" },
    { id: "daysMonths", emoji: "📅", name: "Días y Meses", color: "bg-coral" },
    { id: "family", emoji: "👨‍👩‍👧‍👦", name: "Familia", color: "bg-lavender" },
    { id: "clothing", emoji: "👕", name: "Ropa", color: "bg-coral" },
    { id: "transportation", emoji: "🚗", name: "Transporte", color: "bg-accent" },
    { id: "adjectives", emoji: "📝", name: "Adjetivos", color: "bg-primary" },
    { id: "places", emoji: "🏙️", name: "Lugares", color: "bg-success" },
    { id: "emotions", emoji: "😊", name: "Emociones", color: "bg-secondary" },
    { id: "phrases", emoji: "💭", name: "Frases Comunes", color: "bg-lavender" },
    { id: "stories", emoji: "📚", name: "Cuentos", color: "bg-accent" },
    { id: "game", emoji: "🎮", name: "Juegos", color: "bg-coral" },
    { id: "translator", emoji: "🌍", name: "Traductor", color: "bg-lavender" },
    { id: "prayer", emoji: "✝️", name: "Oración", color: "bg-success" },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 p-6">
      {sections.map((section) => {
        return (
          <button
            key={section.id}
            onClick={() => onNavigate(section.id)}
            className={`learn-card flex flex-col items-center justify-center gap-3 py-8 ${section.color} text-black hover:scale-105`}
          >
            <span className="text-6xl">{section.emoji}</span>
            <span className="text-xl font-bold">{section.name}</span>
          </button>
        );
      })}
    </div>
  );
};
