import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const Transportation = () => {
  const { speak } = useSpeech();

  const transportation = [
    // Land Vehicles
    { english: "Car", spanish: "Coche", emoji: "🚗", category: "Vehículos Terrestres" },
    { english: "Bus", spanish: "Autobús", emoji: "🚌", category: "Vehículos Terrestres" },
    { english: "Truck", spanish: "Camión", emoji: "🚚", category: "Vehículos Terrestres" },
    { english: "Van", spanish: "Furgoneta", emoji: "🚐", category: "Vehículos Terrestres" },
    { english: "Motorcycle", spanish: "Motocicleta", emoji: "🏍️", category: "Vehículos Terrestres" },
    { english: "Bicycle", spanish: "Bicicleta", emoji: "🚲", category: "Vehículos Terrestres" },
    { english: "Scooter", spanish: "Patinete", emoji: "🛴", category: "Vehículos Terrestres" },
    { english: "Taxi", spanish: "Taxi", emoji: "🚕", category: "Vehículos Terrestres" },
    { english: "Police car", spanish: "Coche de policía", emoji: "🚓", category: "Vehículos Terrestres" },
    { english: "Ambulance", spanish: "Ambulancia", emoji: "🚑", category: "Vehículos Terrestres" },
    { english: "Fire truck", spanish: "Camión de bomberos", emoji: "🚒", category: "Vehículos Terrestres" },
    { english: "Train", spanish: "Tren", emoji: "🚆", category: "Vehículos Terrestres" },
    { english: "Subway", spanish: "Metro", emoji: "🚇", category: "Vehículos Terrestres" },
    { english: "Tram", spanish: "Tranvía", emoji: "🚊", category: "Vehículos Terrestres" },
    { english: "Trolleybus", spanish: "Trolebús", emoji: "🚎", category: "Vehículos Terrestres" },
    { english: "Minibus", spanish: "Microbús", emoji: "🚐", category: "Vehículos Terrestres" },
    { english: "Limousine", spanish: "Limusina", emoji: "🚗", category: "Vehículos Terrestres" },
    { english: "SUV", spanish: "Todoterreno", emoji: "🚙", category: "Vehículos Terrestres" },
    { english: "Pickup truck", spanish: "Camioneta", emoji: "🛻", category: "Vehículos Terrestres" },
    { english: "Delivery truck", spanish: "Camión de reparto", emoji: "🚚", category: "Vehículos Terrestres" },
    { english: "Garbage truck", spanish: "Camión de basura", emoji: "🚛", category: "Vehículos Terrestres" },
    { english: "Tow truck", spanish: "Grúa", emoji: "🚚", category: "Vehículos Terrestres" },
    { english: "Electric car", spanish: "Coche eléctrico", emoji: "🚗", category: "Vehículos Terrestres" },
    { english: "Hybrid car", spanish: "Coche híbrido", emoji: "🚗", category: "Vehículos Terrestres" },
    { english: "Sports car", spanish: "Coche deportivo", emoji: "🏎️", category: "Vehículos Terrestres" },
    { english: "Race car", spanish: "Coche de carreras", emoji: "🏎️", category: "Vehículos Terrestres" },
    { english: "ATV", spanish: "Cuatrimoto", emoji: "🏍️", category: "Vehículos Terrestres" },
    { english: "Go-kart", spanish: "Kart", emoji: "🏎️", category: "Vehículos Terrestres" },
    { english: "Electric bike", spanish: "Bicicleta eléctrica", emoji: "🚲", category: "Vehículos Terrestres" },
    { english: "Mountain bike", spanish: "Bicicleta de montaña", emoji: "🚵", category: "Vehículos Terrestres" },
    { english: "Skateboard", spanish: "Monopatín", emoji: "🛹", category: "Vehículos Terrestres" },
    { english: "Roller skates", spanish: "Patines", emoji: "🛼", category: "Vehículos Terrestres" },
    { english: "Segway", spanish: "Segway", emoji: "🛴", category: "Vehículos Terrestres" },
    { english: "Hoverboard", spanish: "Hoverboard", emoji: "🛴", category: "Vehículos Terrestres" },

    // Rail Transport
    { english: "High-speed train", spanish: "Tren de alta velocidad", emoji: "🚄", category: "Transporte Ferroviario" },
    { english: "Bullet train", spanish: "Tren bala", emoji: "🚅", category: "Transporte Ferroviario" },
    { english: "Passenger train", spanish: "Tren de pasajeros", emoji: "🚆", category: "Transporte Ferroviario" },
    { english: "Freight train", spanish: "Tren de carga", emoji: "🚂", category: "Transporte Ferroviario" },
    { english: "Steam locomotive", spanish: "Locomotora de vapor", emoji: "🚂", category: "Transporte Ferroviario" },
    { english: "Monorail", spanish: "Monorraíl", emoji: "🚝", category: "Transporte Ferroviario" },
    { english: "Light rail", spanish: "Tren ligero", emoji: "🚈", category: "Transporte Ferroviario" },
    { english: "Cable car", spanish: "Teleférico", emoji: "🚡", category: "Transporte Ferroviario" },
    { english: "Funicular", spanish: "Funicular", emoji: "🚟", category: "Transporte Ferroviario" },

    // Air Transport
    { english: "Airplane", spanish: "Avión", emoji: "✈️", category: "Transporte Aéreo" },
    { english: "Helicopter", spanish: "Helicóptero", emoji: "🚁", category: "Transporte Aéreo" },
    { english: "Hot air balloon", spanish: "Globo aerostático", emoji: "🎈", category: "Transporte Aéreo" },
    { english: "Glider", spanish: "Planeador", emoji: "✈️", category: "Transporte Aéreo" },
    { english: "Jet", spanish: "Jet", emoji: "🛩️", category: "Transporte Aéreo" },
    { english: "Private plane", spanish: "Avión privado", emoji: "🛩️", category: "Transporte Aéreo" },
    { english: "Fighter jet", spanish: "Avión de combate", emoji: "✈️", category: "Transporte Aéreo" },
    { english: "Cargo plane", spanish: "Avión de carga", emoji: "✈️", category: "Transporte Aéreo" },
    { english: "Parachute", spanish: "Paracaídas", emoji: "🪂", category: "Transporte Aéreo" },
    { english: "Drone", spanish: "Dron", emoji: "🚁", category: "Transporte Aéreo" },
    { english: "Hang glider", spanish: "Ala delta", emoji: "🪂", category: "Transporte Aéreo" },
    { english: "Paraglider", spanish: "Parapente", emoji: "🪂", category: "Transporte Aéreo" },

    // Water Transport
    { english: "Ship", spanish: "Barco", emoji: "🚢", category: "Transporte Acuático" },
    { english: "Boat", spanish: "Bote", emoji: "⛵", category: "Transporte Acuático" },
    { english: "Sailboat", spanish: "Velero", emoji: "⛵", category: "Transporte Acuático" },
    { english: "Yacht", spanish: "Yate", emoji: "🛥️", category: "Transporte Acuático" },
    { english: "Ferry", spanish: "Ferry", emoji: "⛴️", category: "Transporte Acuático" },
    { english: "Cruise ship", spanish: "Crucero", emoji: "🚢", category: "Transporte Acuático" },
    { english: "Speedboat", spanish: "Lancha rápida", emoji: "🚤", category: "Transporte Acuático" },
    { english: "Motorboat", spanish: "Lancha motora", emoji: "🚤", category: "Transporte Acuático" },
    { english: "Canoe", spanish: "Canoa", emoji: "🛶", category: "Transporte Acuático" },
    { english: "Kayak", spanish: "Kayak", emoji: "🛶", category: "Transporte Acuático" },
    { english: "Rowboat", spanish: "Bote de remos", emoji: "🚣", category: "Transporte Acuático" },
    { english: "Submarine", spanish: "Submarino", emoji: "🛶", category: "Transporte Acuático" },
    { english: "Jet ski", spanish: "Moto acuática", emoji: "🚤", category: "Transporte Acuático" },
    { english: "Hovercraft", spanish: "Aerodeslizador", emoji: "🚤", category: "Transporte Acuático" },
    { english: "Fishing boat", spanish: "Barco pesquero", emoji: "🚣", category: "Transporte Acuático" },
    { english: "Cargo ship", spanish: "Barco de carga", emoji: "🚢", category: "Transporte Acuático" },
    { english: "Tanker", spanish: "Petrolero", emoji: "🚢", category: "Transporte Acuático" },
    { english: "Raft", spanish: "Balsa", emoji: "🛶", category: "Transporte Acuático" },
    { english: "Pontoon boat", spanish: "Pontón", emoji: "⛵", category: "Transporte Acuático" },
    { english: "Lifeboat", spanish: "Bote salvavidas", emoji: "🚣", category: "Transporte Acuático" },

    // Heavy & Construction
    { english: "Bulldozer", spanish: "Bulldózer", emoji: "🚜", category: "Maquinaria Pesada" },
    { english: "Excavator", spanish: "Excavadora", emoji: "🚜", category: "Maquinaria Pesada" },
    { english: "Crane", spanish: "Grúa", emoji: "🏗️", category: "Maquinaria Pesada" },
    { english: "Dump truck", spanish: "Volquete", emoji: "🚛", category: "Maquinaria Pesada" },
    { english: "Tractor", spanish: "Tractor", emoji: "🚜", category: "Maquinaria Pesada" },
    { english: "Forklift", spanish: "Montacargas", emoji: "🚜", category: "Maquinaria Pesada" },
    { english: "Cement mixer", spanish: "Hormigonera", emoji: "🚛", category: "Maquinaria Pesada" },
    { english: "Road roller", spanish: "Apisonadora", emoji: "🚜", category: "Maquinaria Pesada" },
    { english: "Loader", spanish: "Cargadora", emoji: "🚜", category: "Maquinaria Pesada" },

    // Other
    { english: "Rickshaw", spanish: "Rickshaw", emoji: "🛺", category: "Otros" },
    { english: "Carriage", spanish: "Carruaje", emoji: "🛺", category: "Otros" },
    { english: "Horse cart", spanish: "Carro de caballos", emoji: "🐴", category: "Otros" },
    { english: "Sled", spanish: "Trineo", emoji: "🛷", category: "Otros" },
    { english: "Snowmobile", spanish: "Moto de nieve", emoji: "🛷", category: "Otros" },
    { english: "Space shuttle", spanish: "Transbordador espacial", emoji: "🚀", category: "Otros" },
    { english: "Rocket", spanish: "Cohete", emoji: "🚀", category: "Otros" },
    { english: "Satellite", spanish: "Satélite", emoji: "🛰️", category: "Otros" },
    { english: "UFO", spanish: "OVNI", emoji: "🛸", category: "Otros" },
  ];

  const groupedTransport = transportation.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, typeof transportation>);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🚗 Transportation</h2>
        <p className="text-muted-foreground">Aprende vocabulario de transporte en inglés</p>
      </div>

      {Object.entries(groupedTransport).map(([category, items]) => (
        <div key={category}>
          <h3 className="text-2xl font-bold text-primary mb-4">{category}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {items.map((item) => (
              <div
                key={item.english}
                className="learn-card bg-gradient-to-br from-accent to-accent/70 flex items-center justify-between p-4"
              >
                <div className="flex items-center gap-3">
                  <span className="text-4xl">{item.emoji}</span>
                  <div>
                    <p className="font-bold text-white text-lg">{item.english}</p>
                    <p className="text-sm text-white/80">{item.spanish}</p>
                  </div>
                </div>
                <button
                  onClick={() => speak(item.english)}
                  className="pronunciation-btn bg-white text-accent"
                  aria-label={`Pronounce ${item.english}`}
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};
