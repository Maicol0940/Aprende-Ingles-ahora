import { useState } from "react";
import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";
import { Button } from "./ui/button";

export const Prayer = () => {
  const { speak } = useSpeech();

  const prayers = {
    ourFather: [
      {
        english: "Our Father, who art in heaven,",
        spanish: "Padre nuestro, que estás en el cielo,",
      },
      {
        english: "Hallowed be thy Name.",
        spanish: "Santificado sea tu nombre.",
      },
      {
        english: "Thy Kingdom come.",
        spanish: "Venga a nosotros tu reino.",
      },
      {
        english: "Thy will be done, on earth as it is in heaven.",
        spanish: "Hágase tu voluntad en la tierra como en el cielo.",
      },
      {
        english: "Give us this day our daily bread.",
        spanish: "Danos hoy nuestro pan de cada día.",
      },
      {
        english: "And forgive us our trespasses,",
        spanish: "Y perdona nuestras ofensas,",
      },
      {
        english: "As we forgive those who trespass against us.",
        spanish: "Como también nosotros perdonamos a los que nos ofenden.",
      },
      {
        english: "And lead us not into temptation,",
        spanish: "No nos dejes caer en la tentación,",
      },
      {
        english: "But deliver us from evil.",
        spanish: "Y líbranos del mal.",
      },
      {
        english: "Amen.",
        spanish: "Amén.",
      },
    ],
    hailMary: [
      {
        english: "Hail Mary, full of grace,",
        spanish: "Dios te salve, María, llena eres de gracia,",
      },
      {
        english: "The Lord is with thee.",
        spanish: "El Señor es contigo.",
      },
      {
        english: "Blessed art thou among women,",
        spanish: "Bendita tú eres entre todas las mujeres,",
      },
      {
        english: "And blessed is the fruit of thy womb, Jesus.",
        spanish: "Y bendito es el fruto de tu vientre, Jesús.",
      },
      {
        english: "Holy Mary, Mother of God,",
        spanish: "Santa María, Madre de Dios,",
      },
      {
        english: "Pray for us sinners,",
        spanish: "Ruega por nosotros pecadores,",
      },
      {
        english: "Now and at the hour of our death.",
        spanish: "Ahora y en la hora de nuestra muerte.",
      },
      {
        english: "Amen.",
        spanish: "Amén.",
      },
    ],
    apostlesCreed: [
      {
        english: "I believe in God, the Father Almighty,",
        spanish: "Creo en Dios, Padre todopoderoso,",
      },
      {
        english: "Creator of heaven and earth.",
        spanish: "Creador del cielo y de la tierra.",
      },
      {
        english: "And in Jesus Christ, His only Son, our Lord,",
        spanish: "Creo en Jesucristo, su único Hijo, nuestro Señor,",
      },
      {
        english: "Who was conceived by the Holy Spirit,",
        spanish: "Que fue concebido por obra y gracia del Espíritu Santo,",
      },
      {
        english: "Born of the Virgin Mary,",
        spanish: "Nació de Santa María Virgen,",
      },
      {
        english: "Suffered under Pontius Pilate,",
        spanish: "Padeció bajo el poder de Poncio Pilato,",
      },
      {
        english: "Was crucified, died, and was buried.",
        spanish: "Fue crucificado, muerto y sepultado,",
      },
      {
        english: "He descended into hell.",
        spanish: "Descendió a los infiernos,",
      },
      {
        english: "On the third day He rose again from the dead.",
        spanish: "Al tercer día resucitó de entre los muertos,",
      },
      {
        english: "He ascended into heaven,",
        spanish: "Subió a los cielos,",
      },
      {
        english: "And is seated at the right hand of God the Father Almighty.",
        spanish: "Y está sentado a la derecha de Dios, Padre todopoderoso.",
      },
      {
        english: "From there He will come to judge the living and the dead.",
        spanish: "Desde allí ha de venir a juzgar a vivos y muertos.",
      },
      {
        english: "I believe in the Holy Spirit,",
        spanish: "Creo en el Espíritu Santo,",
      },
      {
        english: "The Holy Catholic Church,",
        spanish: "La santa Iglesia católica,",
      },
      {
        english: "The communion of saints,",
        spanish: "La comunión de los santos,",
      },
      {
        english: "The forgiveness of sins,",
        spanish: "El perdón de los pecados,",
      },
      {
        english: "The resurrection of the body,",
        spanish: "La resurrección de la carne,",
      },
      {
        english: "And life everlasting.",
        spanish: "Y la vida eterna.",
      },
      {
        english: "Amen.",
        spanish: "Amén.",
      },
    ],
    gloryBe: [
      {
        english: "Glory be to the Father,",
        spanish: "Gloria al Padre,",
      },
      {
        english: "And to the Son,",
        spanish: "Al Hijo,",
      },
      {
        english: "And to the Holy Spirit.",
        spanish: "Y al Espíritu Santo.",
      },
      {
        english: "As it was in the beginning,",
        spanish: "Como era en el principio,",
      },
      {
        english: "Is now, and ever shall be,",
        spanish: "Ahora y siempre,",
      },
      {
        english: "World without end.",
        spanish: "Por los siglos de los siglos.",
      },
      {
        english: "Amen.",
        spanish: "Amén.",
      },
    ],
  };

  const [selectedPrayer, setSelectedPrayer] = useState<keyof typeof prayers | null>(null);

  const prayerInfo = {
    ourFather: { title: "The Lord's Prayer", subtitle: "El Padre Nuestro", emoji: "✝️" },
    hailMary: { title: "Hail Mary", subtitle: "Ave María", emoji: "🙏" },
    apostlesCreed: { title: "Apostles' Creed", subtitle: "El Credo", emoji: "📿" },
    gloryBe: { title: "Glory Be", subtitle: "Gloria al Padre", emoji: "✨" },
  };

  const speakFullPrayer = (prayerKey: keyof typeof prayers) => {
    const fullPrayerEnglish = prayers[prayerKey].map((line) => line.english).join(" ");
    speak(fullPrayerEnglish);
  };

  if (!selectedPrayer) {
    return (
      <div className="space-y-8 max-w-6xl mx-auto">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-foreground mb-2">✝️ Christian Prayers</h2>
          <p className="text-muted-foreground">Oraciones Cristianas en Inglés</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {(Object.keys(prayers) as Array<keyof typeof prayers>).map((key) => (
            <div
              key={key}
              onClick={() => setSelectedPrayer(key)}
              className="learn-card bg-gradient-to-br from-primary to-primary/70 cursor-pointer hover:scale-105 transition-transform duration-200 p-8 text-center space-y-4"
            >
              <div className="text-6xl">{prayerInfo[key].emoji}</div>
              <div>
                <h3 className="text-2xl font-bold text-white mb-1">{prayerInfo[key].title}</h3>
                <p className="text-white/90 italic">{prayerInfo[key].subtitle}</p>
              </div>
              <p className="text-white/80 text-sm">Click to view and listen</p>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const currentPrayer = prayers[selectedPrayer];
  const currentInfo = prayerInfo[selectedPrayer];

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="flex items-center justify-between">
        <Button
          onClick={() => setSelectedPrayer(null)}
          variant="outline"
          className="gap-2"
        >
          ← Back to Prayers
        </Button>
      </div>

      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">
          {currentInfo.emoji} {currentInfo.title}
        </h2>
        <p className="text-muted-foreground">{currentInfo.subtitle}</p>
      </div>

      <div className="learn-card bg-gradient-to-br from-lavender to-lavender/70 space-y-6">
        <div className="text-center">
          <Button onClick={() => speakFullPrayer(selectedPrayer)} className="gap-2 bg-primary" size="lg">
            <Volume2 className="w-5 h-5" />
            Listen to Full Prayer
          </Button>
        </div>

        <div className="space-y-4">
          {currentPrayer.map((line, index) => (
            <div
              key={index}
              className="bg-white/90 rounded-xl p-4 flex items-start gap-4 hover:bg-white transition-colors"
            >
              <button
                onClick={() => speak(line.english)}
                className="pronunciation-btn shrink-0 mt-1"
                aria-label={`Pronounce line ${index + 1}`}
              >
                <Volume2 className="w-4 h-4" />
              </button>
              <div className="flex-1 space-y-1">
                <p className="text-lg font-semibold text-foreground">{line.english}</p>
                <p className="text-muted-foreground italic">{line.spanish}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
