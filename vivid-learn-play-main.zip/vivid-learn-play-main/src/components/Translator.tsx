import { useState } from "react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Volume2, ArrowLeftRight } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";
import { toast } from "sonner";

export const Translator = () => {
  const { speak } = useSpeech();
  const [inputText, setInputText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [isEnglishToSpanish, setIsEnglishToSpanish] = useState(true);

  const translate = async () => {
    if (!inputText.trim()) {
      toast.error("Por favor ingresa texto para traducir");
      return;
    }

    const toastId = toast.loading("Traduciendo...");

    try {
      const sourceLang = isEnglishToSpanish ? "en" : "es";
      const targetLang = isEnglishToSpanish ? "es" : "en";
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/translate`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({
            text: inputText,
            sourceLang,
            targetLang,
          }),
        }
      );
      
      if (!response.ok) {
        const errorData = await response.json();
        toast.error(errorData.error || "Error en la traducción", { id: toastId });
        return;
      }
      
      const data = await response.json();
      
      if (data.translatedText) {
        setTranslatedText(data.translatedText);
        toast.success("Traducción completada", { id: toastId });
      } else {
        toast.error("Error en la traducción. Intenta de nuevo.", { id: toastId });
      }
    } catch (error) {
      console.error("Translation error:", error);
      toast.error("Error de conexión. Verifica tu internet.", { id: toastId });
    }
  };

  const swapLanguages = () => {
    setIsEnglishToSpanish(!isEnglishToSpanish);
    setInputText(translatedText);
    setTranslatedText(inputText);
  };

  const clearAll = () => {
    setInputText("");
    setTranslatedText("");
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🌍 English ↔ Spanish Translator</h2>
        <p className="text-muted-foreground">Translate text between English and Spanish</p>
      </div>

      <div className="grid md:grid-cols-[1fr_auto_1fr] gap-4 items-center">
        <div className="learn-card bg-gradient-to-br from-primary to-primary/70 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-white">
              {isEnglishToSpanish ? "🇬🇧 English" : "🇪🇸 Español"}
            </h3>
            {inputText && (
              <button
                onClick={() => speak(inputText, isEnglishToSpanish ? "en-US" : "es-ES")}
                className="pronunciation-btn bg-white text-primary"
                aria-label="Listen to input"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            )}
          </div>
          <Textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Enter text here..."
            className="min-h-[200px] bg-white/95 border-none text-foreground"
          />
        </div>

        <Button
          onClick={swapLanguages}
          variant="outline"
          size="icon"
          className="mx-auto rotate-90 md:rotate-0"
        >
          <ArrowLeftRight className="w-5 h-5" />
        </Button>

        <div className="learn-card bg-gradient-to-br from-secondary to-secondary/70 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-foreground">
              {isEnglishToSpanish ? "🇪🇸 Español" : "🇬🇧 English"}
            </h3>
            {translatedText && (
              <button
                onClick={() => speak(translatedText, isEnglishToSpanish ? "es-ES" : "en-US")}
                className="pronunciation-btn"
                aria-label="Listen to translation"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            )}
          </div>
          <Textarea
            value={translatedText}
            readOnly
            placeholder="Translation will appear here..."
            className="min-h-[200px] bg-white/95 border-none text-foreground"
          />
        </div>
      </div>

      <div className="flex justify-center gap-4">
        <Button onClick={translate} className="bg-primary" size="lg">
          Translate
        </Button>
        <Button onClick={clearAll} variant="outline" size="lg">
          Clear
        </Button>
      </div>
    </div>
  );
};
