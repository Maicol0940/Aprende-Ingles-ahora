import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const Colors = () => {
  const { speak } = useSpeech();

  const colors = [
    { name: "Red", spanish: "Rojo", hex: "#EF4444", textColor: "white" },
    { name: "Blue", spanish: "Azul", hex: "#3B82F6", textColor: "white" },
    { name: "Green", spanish: "Verde", hex: "#10B981", textColor: "white" },
    { name: "Yellow", spanish: "Amarillo", hex: "#FBBF24", textColor: "black" },
    { name: "Orange", spanish: "Naranja", hex: "#F97316", textColor: "white" },
    { name: "Purple", spanish: "Morado", hex: "#A855F7", textColor: "white" },
    { name: "Pink", spanish: "Rosa", hex: "#EC4899", textColor: "white" },
    { name: "Brown", spanish: "Marrón", hex: "#92400E", textColor: "white" },
    { name: "Black", spanish: "Negro", hex: "#000000", textColor: "white" },
    { name: "White", spanish: "Blanco", hex: "#FFFFFF", textColor: "black" },
    { name: "Gray", spanish: "Gris", hex: "#6B7280", textColor: "white" },
    { name: "Beige", spanish: "Beige", hex: "#D4A574", textColor: "black" },
    { name: "Turquoise", spanish: "Turquesa", hex: "#06B6D4", textColor: "white" },
    { name: "Indigo", spanish: "Índigo", hex: "#4F46E5", textColor: "white" },
    { name: "Violet", spanish: "Violeta", hex: "#8B5CF6", textColor: "white" },
    { name: "Magenta", spanish: "Magenta", hex: "#D946EF", textColor: "white" },
    { name: "Cyan", spanish: "Cian", hex: "#22D3EE", textColor: "black" },
    { name: "Lime", spanish: "Lima", hex: "#84CC16", textColor: "black" },
    { name: "Olive", spanish: "Oliva", hex: "#808000", textColor: "white" },
    { name: "Navy", spanish: "Azul Marino", hex: "#1E3A8A", textColor: "white" },
    { name: "Maroon", spanish: "Granate", hex: "#7F1D1D", textColor: "white" },
    { name: "Gold", spanish: "Dorado", hex: "#FFD700", textColor: "black" },
    { name: "Silver", spanish: "Plateado", hex: "#C0C0C0", textColor: "black" },
    { name: "Coral", spanish: "Coral", hex: "#FF7F50", textColor: "white" },
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🎨 Colors</h2>
        <p className="text-muted-foreground">Aprende los colores en inglés</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {colors.map((color) => (
          <div
            key={color.name}
            className="learn-card flex flex-col items-center justify-center gap-3 py-8 transition-transform hover:scale-105"
            style={{ backgroundColor: color.hex }}
          >
            <div
              className="w-16 h-16 rounded-full border-4 shadow-lg"
              style={{ backgroundColor: color.hex, borderColor: color.textColor }}
            />
            <div className="text-center">
              <p className="text-lg font-bold mb-1" style={{ color: color.textColor }}>
                {color.name}
              </p>
              <p className="text-sm italic" style={{ color: color.textColor, opacity: 0.9 }}>
                {color.spanish}
              </p>
            </div>
            <button
              onClick={() => speak(color.name)}
              className="pronunciation-btn"
              style={{
                backgroundColor: color.textColor,
                color: color.hex,
              }}
              aria-label={`Pronounce ${color.name}`}
            >
              <Volume2 className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
