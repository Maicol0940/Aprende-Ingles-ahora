import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const Adjectives = () => {
  const { speak } = useSpeech();

  const adjectives = [
    // Appearance
    { english: "Beautiful", spanish: "Hermoso/a", opposite: "Ugly / Feo/a", category: "Apariencia" },
    { english: "Pretty", spanish: "Bonito/a", opposite: "Plain / Simple", category: "Apariencia" },
    { english: "Handsome", spanish: "Guapo", opposite: "Unattractive / Poco atractivo", category: "Apariencia" },
    { english: "Ugly", spanish: "Feo/a", opposite: "Beautiful / Hermoso", category: "Apariencia" },
    { english: "Attractive", spanish: "Atractivo/a", opposite: "Unattractive / Poco atractivo", category: "Apariencia" },
    { english: "Cute", spanish: "Lindo/a", opposite: "Ugly / Feo", category: "Apariencia" },
    { english: "Elegant", spanish: "Elegante", opposite: "Sloppy / Descuidado", category: "Apariencia" },
    { english: "Stylish", spanish: "Con estilo", opposite: "Unfashionable / Pasado de moda", category: "Apariencia" },

    // Size
    { english: "Big", spanish: "Grande", opposite: "Small / Pequeño", category: "Tamaño" },
    { english: "Small", spanish: "Pequeño", opposite: "Big / Grande", category: "Tamaño" },
    { english: "Large", spanish: "Grande", opposite: "Small / Pequeño", category: "Tamaño" },
    { english: "Tiny", spanish: "Diminuto", opposite: "Huge / Enorme", category: "Tamaño" },
    { english: "Huge", spanish: "Enorme", opposite: "Tiny / Diminuto", category: "Tamaño" },
    { english: "Gigantic", spanish: "Gigante", opposite: "Tiny / Diminuto", category: "Tamaño" },
    { english: "Enormous", spanish: "Enorme", opposite: "Tiny / Diminuto", category: "Tamaño" },
    { english: "Massive", spanish: "Masivo", opposite: "Tiny / Diminuto", category: "Tamaño" },
    { english: "Tall", spanish: "Alto", opposite: "Short / Bajo", category: "Tamaño" },
    { english: "Short", spanish: "Bajo/Corto", opposite: "Tall/Long / Alto/Largo", category: "Tamaño" },
    { english: "Long", spanish: "Largo", opposite: "Short / Corto", category: "Tamaño" },
    { english: "Wide", spanish: "Ancho", opposite: "Narrow / Estrecho", category: "Tamaño" },
    { english: "Narrow", spanish: "Estrecho", opposite: "Wide / Ancho", category: "Tamaño" },
    { english: "Thick", spanish: "Grueso", opposite: "Thin / Delgado", category: "Tamaño" },
    { english: "Thin", spanish: "Delgado", opposite: "Thick / Grueso", category: "Tamaño" },

    // Personality
    { english: "Kind", spanish: "Amable", opposite: "Mean / Malo", category: "Personalidad" },
    { english: "Nice", spanish: "Agradable", opposite: "Mean / Desagradable", category: "Personalidad" },
    { english: "Friendly", spanish: "Amistoso", opposite: "Unfriendly / Hostil", category: "Personalidad" },
    { english: "Mean", spanish: "Malo", opposite: "Kind / Amable", category: "Personalidad" },
    { english: "Generous", spanish: "Generoso", opposite: "Stingy / Tacaño", category: "Personalidad" },
    { english: "Selfish", spanish: "Egoísta", opposite: "Generous / Generoso", category: "Personalidad" },
    { english: "Honest", spanish: "Honesto", opposite: "Dishonest / Deshonesto", category: "Personalidad" },
    { english: "Loyal", spanish: "Leal", opposite: "Disloyal / Desleal", category: "Personalidad" },
    { english: "Patient", spanish: "Paciente", opposite: "Impatient / Impaciente", category: "Personalidad" },
    { english: "Impatient", spanish: "Impaciente", opposite: "Patient / Paciente", category: "Personalidad" },
    { english: "Shy", spanish: "Tímido", opposite: "Outgoing / Extrovertido", category: "Personalidad" },
    { english: "Outgoing", spanish: "Extrovertido", opposite: "Shy / Tímido", category: "Personalidad" },
    { english: "Confident", spanish: "Seguro de sí mismo", opposite: "Insecure / Inseguro", category: "Personalidad" },
    { english: "Funny", spanish: "Gracioso", opposite: "Boring / Aburrido", category: "Personalidad" },
    { english: "Serious", spanish: "Serio", opposite: "Playful / Juguetón", category: "Personalidad" },
    { english: "Calm", spanish: "Calmado", opposite: "Nervous / Nervioso", category: "Personalidad" },
    { english: "Brave", spanish: "Valiente", opposite: "Cowardly / Cobarde", category: "Personalidad" },
    { english: "Smart", spanish: "Inteligente", opposite: "Dumb / Tonto", category: "Personalidad" },
    { english: "Intelligent", spanish: "Inteligente", opposite: "Dumb / Tonto", category: "Personalidad" },
    { english: "Clever", spanish: "Listo", opposite: "Dumb / Tonto", category: "Personalidad" },
    { english: "Creative", spanish: "Creativo", opposite: "Uncreative / Poco creativo", category: "Personalidad" },
    { english: "Lazy", spanish: "Perezoso", opposite: "Hardworking / Trabajador", category: "Personalidad" },
    { english: "Hardworking", spanish: "Trabajador", opposite: "Lazy / Perezoso", category: "Personalidad" },

    // Condition
    { english: "New", spanish: "Nuevo", opposite: "Old / Viejo", category: "Condición" },
    { english: "Old", spanish: "Viejo", opposite: "New / Nuevo", category: "Condición" },
    { english: "Modern", spanish: "Moderno", opposite: "Ancient / Antiguo", category: "Condición" },
    { english: "Ancient", spanish: "Antiguo", opposite: "Modern / Moderno", category: "Condición" },
    { english: "Clean", spanish: "Limpio", opposite: "Dirty / Sucio", category: "Condición" },
    { english: "Dirty", spanish: "Sucio", opposite: "Clean / Limpio", category: "Condición" },
    { english: "Fresh", spanish: "Fresco", opposite: "Stale / Rancio", category: "Condición" },
    { english: "Broken", spanish: "Roto", opposite: "Fixed / Arreglado", category: "Condición" },
    { english: "Damaged", spanish: "Dañado", opposite: "Intact / Intacto", category: "Condición" },
    { english: "Perfect", spanish: "Perfecto", opposite: "Imperfect / Imperfecto", category: "Condición" },

    // Temperature
    { english: "Hot", spanish: "Caliente", opposite: "Cold / Frío", category: "Temperatura" },
    { english: "Cold", spanish: "Frío", opposite: "Hot / Caliente", category: "Temperatura" },
    { english: "Warm", spanish: "Cálido", opposite: "Cool / Fresco", category: "Temperatura" },
    { english: "Cool", spanish: "Fresco", opposite: "Warm / Cálido", category: "Temperatura" },
    { english: "Freezing", spanish: "Congelado", opposite: "Boiling / Hirviendo", category: "Temperatura" },
    { english: "Boiling", spanish: "Hirviendo", opposite: "Freezing / Congelado", category: "Temperatura" },

    // Speed
    { english: "Fast", spanish: "Rápido", opposite: "Slow / Lento", category: "Velocidad" },
    { english: "Slow", spanish: "Lento", opposite: "Fast / Rápido", category: "Velocidad" },
    { english: "Quick", spanish: "Rápido", opposite: "Slow / Lento", category: "Velocidad" },
    { english: "Rapid", spanish: "Rápido", opposite: "Slow / Lento", category: "Velocidad" },

    // Difficulty
    { english: "Easy", spanish: "Fácil", opposite: "Difficult / Difícil", category: "Dificultad" },
    { english: "Difficult", spanish: "Difícil", opposite: "Easy / Fácil", category: "Dificultad" },
    { english: "Hard", spanish: "Duro/Difícil", opposite: "Easy/Soft / Fácil/Suave", category: "Dificultad" },
    { english: "Simple", spanish: "Simple", opposite: "Complex / Complejo", category: "Dificultad" },
    { english: "Complex", spanish: "Complejo", opposite: "Simple / Simple", category: "Dificultad" },
    { english: "Complicated", spanish: "Complicado", opposite: "Simple / Simple", category: "Dificultad" },

    // Feelings & Emotions
    { english: "Happy", spanish: "Feliz", opposite: "Sad / Triste", category: "Sentimientos" },
    { english: "Sad", spanish: "Triste", opposite: "Happy / Feliz", category: "Sentimientos" },
    { english: "Excited", spanish: "Emocionado", opposite: "Bored / Aburrido", category: "Sentimientos" },
    { english: "Bored", spanish: "Aburrido", opposite: "Excited / Emocionado", category: "Sentimientos" },
    { english: "Angry", spanish: "Enojado", opposite: "Calm / Calmado", category: "Sentimientos" },
    { english: "Scared", spanish: "Asustado", opposite: "Brave / Valiente", category: "Sentimientos" },
    { english: "Worried", spanish: "Preocupado", opposite: "Relaxed / Relajado", category: "Sentimientos" },
    { english: "Surprised", spanish: "Sorprendido", opposite: "Unsurprised / No sorprendido", category: "Sentimientos" },
    { english: "Tired", spanish: "Cansado", opposite: "Energetic / Energético", category: "Sentimientos" },
    { english: "Energetic", spanish: "Energético", opposite: "Tired / Cansado", category: "Sentimientos" },
    { english: "Nervous", spanish: "Nervioso", opposite: "Calm / Calmado", category: "Sentimientos" },
    { english: "Relaxed", spanish: "Relajado", opposite: "Stressed / Estresado", category: "Sentimientos" },
    { english: "Stressed", spanish: "Estresado", opposite: "Relaxed / Relajado", category: "Sentimientos" },
    { english: "Proud", spanish: "Orgulloso", opposite: "Ashamed / Avergonzado", category: "Sentimientos" },
    { english: "Jealous", spanish: "Celoso", opposite: "Content / Contento", category: "Sentimientos" },
    { english: "Embarrassed", spanish: "Avergonzado", opposite: "Proud / Orgulloso", category: "Sentimientos" },

    // Quality
    { english: "Good", spanish: "Bueno", opposite: "Bad / Malo", category: "Calidad" },
    { english: "Bad", spanish: "Malo", opposite: "Good / Bueno", category: "Calidad" },
    { english: "Excellent", spanish: "Excelente", opposite: "Terrible / Terrible", category: "Calidad" },
    { english: "Terrible", spanish: "Terrible", opposite: "Excellent / Excelente", category: "Calidad" },
    { english: "Amazing", spanish: "Increíble", opposite: "Awful / Horrible", category: "Calidad" },
    { english: "Awful", spanish: "Horrible", opposite: "Amazing / Increíble", category: "Calidad" },
    { english: "Wonderful", spanish: "Maravilloso", opposite: "Terrible / Terrible", category: "Calidad" },
    { english: "Perfect", spanish: "Perfecto", opposite: "Imperfect / Imperfecto", category: "Calidad" },

    // Weight
    { english: "Heavy", spanish: "Pesado", opposite: "Light / Ligero", category: "Peso" },
    { english: "Light", spanish: "Ligero", opposite: "Heavy / Pesado", category: "Peso" },

    // Taste
    { english: "Sweet", spanish: "Dulce", opposite: "Bitter / Amargo", category: "Sabor" },
    { english: "Salty", spanish: "Salado", opposite: "Sweet / Dulce", category: "Sabor" },
    { english: "Sour", spanish: "Ácido", opposite: "Sweet / Dulce", category: "Sabor" },
    { english: "Bitter", spanish: "Amargo", opposite: "Sweet / Dulce", category: "Sabor" },
    { english: "Spicy", spanish: "Picante", opposite: "Mild / Suave", category: "Sabor" },
    { english: "Delicious", spanish: "Delicioso", opposite: "Disgusting / Repugnante", category: "Sabor" },
    { english: "Tasty", spanish: "Sabroso", opposite: "Tasteless / Insípido", category: "Sabor" },

    // Other
    { english: "Rich", spanish: "Rico", opposite: "Poor / Pobre", category: "Otros" },
    { english: "Poor", spanish: "Pobre", opposite: "Rich / Rico", category: "Otros" },
    { english: "Expensive", spanish: "Caro", opposite: "Cheap / Barato", category: "Otros" },
    { english: "Cheap", spanish: "Barato", opposite: "Expensive / Caro", category: "Otros" },
    { english: "Loud", spanish: "Ruidoso", opposite: "Quiet / Silencioso", category: "Otros" },
    { english: "Quiet", spanish: "Silencioso", opposite: "Loud / Ruidoso", category: "Otros" },
    { english: "Soft", spanish: "Suave", opposite: "Hard / Duro", category: "Otros" },
    { english: "Rough", spanish: "Áspero", opposite: "Smooth / Suave", category: "Otros" },
    { english: "Smooth", spanish: "Suave", opposite: "Rough / Áspero", category: "Otros" },
    { english: "Empty", spanish: "Vacío", opposite: "Full / Lleno", category: "Otros" },
    { english: "Full", spanish: "Lleno", opposite: "Empty / Vacío", category: "Otros" },
    { english: "Wet", spanish: "Mojado", opposite: "Dry / Seco", category: "Otros" },
    { english: "Dry", spanish: "Seco", opposite: "Wet / Mojado", category: "Otros" },
    { english: "Strong", spanish: "Fuerte", opposite: "Weak / Débil", category: "Otros" },
    { english: "Weak", spanish: "Débil", opposite: "Strong / Fuerte", category: "Otros" },
    { english: "Bright", spanish: "Brillante", opposite: "Dark / Oscuro", category: "Otros" },
    { english: "Dark", spanish: "Oscuro", opposite: "Bright / Brillante", category: "Otros" },
    { english: "Sharp", spanish: "Afilado", opposite: "Dull / Sin filo", category: "Otros" },
    { english: "Dangerous", spanish: "Peligroso", opposite: "Safe / Seguro", category: "Otros" },
    { english: "Safe", spanish: "Seguro", opposite: "Dangerous / Peligroso", category: "Otros" },
    { english: "Right", spanish: "Correcto", opposite: "Wrong / Incorrecto", category: "Otros" },
    { english: "Wrong", spanish: "Incorrecto", opposite: "Right / Correcto", category: "Otros" },
  ];

  const groupedAdjectives = adjectives.reduce((acc, adj) => {
    if (!acc[adj.category]) {
      acc[adj.category] = [];
    }
    acc[adj.category].push(adj);
    return acc;
  }, {} as Record<string, typeof adjectives>);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">📝 Adjectives</h2>
        <p className="text-muted-foreground">Aprende adjetivos comunes en inglés</p>
      </div>

      {Object.entries(groupedAdjectives).map(([category, items]) => (
        <div key={category}>
          <h3 className="text-2xl font-bold text-primary mb-4">{category}</h3>
          <div className="overflow-x-auto rounded-lg border border-border shadow-lg">
            <table className="w-full">
              <thead className="bg-primary text-white sticky top-0">
                <tr>
                  <th className="p-4 text-left font-bold">English</th>
                  <th className="p-4 text-left font-bold">Español</th>
                  <th className="p-4 text-left font-bold">Opposite (Opuesto)</th>
                  <th className="p-4 text-center font-bold">Pronunciation</th>
                </tr>
              </thead>
              <tbody>
                {items.map((adj, index) => (
                  <tr
                    key={adj.english}
                    className={`${
                      index % 2 === 0 ? "bg-card" : "bg-muted/30"
                    } hover:bg-accent/20 transition-colors`}
                  >
                    <td className="p-4 font-bold text-foreground">{adj.english}</td>
                    <td className="p-4 text-muted-foreground">{adj.spanish}</td>
                    <td className="p-4 text-sm text-muted-foreground">{adj.opposite}</td>
                    <td className="p-4">
                      <button
                        onClick={() => speak(adj.english)}
                        className="pronunciation-btn mx-auto"
                        aria-label={`Pronounce ${adj.english}`}
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </div>
  );
};
