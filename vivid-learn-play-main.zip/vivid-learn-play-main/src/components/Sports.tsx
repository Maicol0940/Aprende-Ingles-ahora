import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const Sports = () => {
  const { speak } = useSpeech();

  const sports = [
    { spanish: "Fútbol", english: "Soccer / Football", emoji: "⚽" },
    { spanish: "Baloncesto", english: "Basketball", emoji: "🏀" },
    { spanish: "Béisbol", english: "Baseball", emoji: "⚾" },
    { spanish: "Tenis", english: "Tennis", emoji: "🎾" },
    { spanish: "Voleibol", english: "Volleyball", emoji: "🏐" },
    { spanish: "Natación", english: "Swimming", emoji: "🏊" },
    { spanish: "Atletismo", english: "Athletics / Track and Field", emoji: "🏃" },
    { spanish: "Ciclismo", english: "Cycling", emoji: "🚴" },
    { spanish: "Boxeo", english: "Boxing", emoji: "🥊" },
    { spanish: "Artes Marciales", english: "Martial Arts", emoji: "🥋" },
    { spanish: "Gimnasia", english: "Gymnastics", emoji: "🤸" },
    { spanish: "Golf", english: "Golf", emoji: "⛳" },
    { spanish: "Hockey", english: "Hockey", emoji: "🏒" },
    { spanish: "Rugby", english: "Rugby", emoji: "🏉" },
    { spanish: "Esquí", english: "Skiing", emoji: "⛷️" },
    { spanish: "Snowboard", english: "Snowboarding", emoji: "🏂" },
    { spanish: "Surf", english: "Surfing", emoji: "🏄" },
    { spanish: "Patinaje", english: "Skating", emoji: "⛸️" },
    { spanish: "Escalada", english: "Climbing", emoji: "🧗" },
    { spanish: "Halterofilia", english: "Weightlifting", emoji: "🏋️" },
    { spanish: "Yoga", english: "Yoga", emoji: "🧘" },
    { spanish: "Buceo", english: "Diving", emoji: "🤿" },
    { spanish: "Kayak", english: "Kayaking", emoji: "🛶" },
    { spanish: "Remo", english: "Rowing", emoji: "🚣" },
    { spanish: "Equitación", english: "Horse Riding", emoji: "🏇" },
    { spanish: "Esgrima", english: "Fencing", emoji: "🤺" },
    { spanish: "Tiro con Arco", english: "Archery", emoji: "🏹" },
    { spanish: "Bolos", english: "Bowling", emoji: "🎳" },
    { spanish: "Bádminton", english: "Badminton", emoji: "🏸" },
    { spanish: "Ping Pong", english: "Table Tennis / Ping Pong", emoji: "🏓" },
    { spanish: "Cricket", english: "Cricket", emoji: "🏏" },
    { spanish: "Softbol", english: "Softball", emoji: "🥎" },
    { spanish: "Fútbol Americano", english: "American Football", emoji: "🏈" },
    { spanish: "Lacrosse", english: "Lacrosse", emoji: "🥍" },
    { spanish: "Paracaidismo", english: "Skydiving", emoji: "🪂" },
    { spanish: "Parapente", english: "Paragliding", emoji: "🪂" },
    { spanish: "Ala Delta", english: "Hang Gliding", emoji: "🪂" },
    { spanish: "Triatlón", english: "Triathlon", emoji: "🏊‍♂️" },
    { spanish: "Maratón", english: "Marathon", emoji: "🏃‍♀️" },
    { spanish: "Parkour", english: "Parkour", emoji: "🤸" },
    { spanish: "Lucha Libre", english: "Wrestling", emoji: "🤼" },
    { spanish: "Atletismo de Campo", english: "Field Athletics", emoji: "🏃" },
    { spanish: "Salto de Altura", english: "High Jump", emoji: "🏃" },
    { spanish: "Salto con Pértiga", english: "Pole Vault", emoji: "🏃" },
    { spanish: "Lanzamiento de Disco", english: "Discus Throw", emoji: "🏃" },
    { spanish: "Lanzamiento de Jabalina", english: "Javelin Throw", emoji: "🏃" },
    { spanish: "Lanzamiento de Peso", english: "Shot Put", emoji: "🏃" },
    { spanish: "Salto de Longitud", english: "Long Jump", emoji: "🏃" },
    { spanish: "Decatlón", english: "Decathlon", emoji: "🏃" },
    { spanish: "Pentatlón", english: "Pentathlon", emoji: "🏃" },
    { spanish: "Polo", english: "Polo", emoji: "🏇" },
    { spanish: "Canotaje", english: "Canoeing", emoji: "🛶" },
    { spanish: "Vela", english: "Sailing", emoji: "⛵" },
    { spanish: "Waterpolo", english: "Water Polo", emoji: "🤽" },
    { spanish: "Rafting", english: "Rafting", emoji: "🚣" },
    { spanish: "Windsurf", english: "Windsurfing", emoji: "🏄" },
    { spanish: "Kitesurfing", english: "Kitesurfing", emoji: "🪁" },
    { spanish: "Motociclismo", english: "Motorcycling", emoji: "🏍️" },
    { spanish: "Automovilismo", english: "Motor Racing", emoji: "🏎️" },
    { spanish: "Karting", english: "Go-Kart Racing", emoji: "🏎️" },
    { spanish: "BMX", english: "BMX", emoji: "🚴" },
    { spanish: "Ciclismo de Montaña", english: "Mountain Biking", emoji: "🚵" },
    { spanish: "Patinaje Artístico", english: "Figure Skating", emoji: "⛸️" },
    { spanish: "Patinaje de Velocidad", english: "Speed Skating", emoji: "⛸️" },
    { spanish: "Curling", english: "Curling", emoji: "🥌" },
    { spanish: "Bobsled", english: "Bobsleigh", emoji: "🛷" },
    { spanish: "Luge", english: "Luge", emoji: "🛷" },
    { spanish: "Skeleton", english: "Skeleton", emoji: "🛷" },
    { spanish: "Biatlón", english: "Biathlon", emoji: "🎿" },
    { spanish: "Esquí de Fondo", english: "Cross-Country Skiing", emoji: "⛷️" },
    { spanish: "Salto de Esquí", english: "Ski Jumping", emoji: "🎿" },
    { spanish: "Freestyle Skiing", english: "Freestyle Skiing", emoji: "⛷️" },
    { spanish: "Slalom", english: "Slalom", emoji: "⛷️" },
    { spanish: "Alpinismo", english: "Mountaineering", emoji: "⛰️" },
    { spanish: "Senderismo", english: "Hiking", emoji: "🥾" },
    { spanish: "Trekking", english: "Trekking", emoji: "🥾" },
    { spanish: "Orientación", english: "Orienteering", emoji: "🧭" },
    { spanish: "CrossFit", english: "CrossFit", emoji: "🏋️" },
    { spanish: "Pilates", english: "Pilates", emoji: "🧘" },
    { spanish: "Zumba", english: "Zumba", emoji: "💃" },
    { spanish: "Aeróbicos", english: "Aerobics", emoji: "🤸" },
    { spanish: "Spinning", english: "Spinning", emoji: "🚴" },
    { spanish: "Tai Chi", english: "Tai Chi", emoji: "🧘" },
    { spanish: "Capoeira", english: "Capoeira", emoji: "🤸" },
    { spanish: "Judo", english: "Judo", emoji: "🥋" },
    { spanish: "Karate", english: "Karate", emoji: "🥋" },
    { spanish: "Taekwondo", english: "Taekwondo", emoji: "🥋" },
    { spanish: "Kung Fu", english: "Kung Fu", emoji: "🥋" },
    { spanish: "Muay Thai", english: "Muay Thai", emoji: "🥊" },
    { spanish: "Kickboxing", english: "Kickboxing", emoji: "🥊" },
    { spanish: "MMA", english: "Mixed Martial Arts (MMA)", emoji: "🥊" },
    { spanish: "Jiu-Jitsu", english: "Jiu-Jitsu", emoji: "🥋" },
    { spanish: "Krav Maga", english: "Krav Maga", emoji: "🥋" },
    { spanish: "Aikido", english: "Aikido", emoji: "🥋" },
    { spanish: "Cheerleading", english: "Cheerleading", emoji: "📣" },
    { spanish: "Danza", english: "Dance", emoji: "💃" },
    { spanish: "Ballet", english: "Ballet", emoji: "🩰" },
    { spanish: "Patinaje sobre Ruedas", english: "Roller Skating", emoji: "🛼" },
    { spanish: "Skateboarding", english: "Skateboarding", emoji: "🛹" },
    { spanish: "Longboard", english: "Longboarding", emoji: "🛹" },
    { spanish: "Scooter", english: "Scooter Riding", emoji: "🛴" },
    { spanish: "Parkour Freerunning", english: "Freerunning", emoji: "🤸" },
    { spanish: "Slackline", english: "Slacklining", emoji: "🧗" },
    { spanish: "Bungee Jumping", english: "Bungee Jumping", emoji: "🪂" },
    { spanish: "Pesca Deportiva", english: "Sport Fishing", emoji: "🎣" },
    { spanish: "Caza", english: "Hunting", emoji: "🦌" },
    { spanish: "Tiro al Blanco", english: "Target Shooting", emoji: "🎯" },
    { spanish: "Paintball", english: "Paintball", emoji: "🔫" },
    { spanish: "Airsoft", english: "Airsoft", emoji: "🔫" },
    { spanish: "Dardos", english: "Darts", emoji: "🎯" },
    { spanish: "Billar", english: "Billiards / Pool", emoji: "🎱" },
    { spanish: "Snooker", english: "Snooker", emoji: "🎱" },
    { spanish: "Ajedrez", english: "Chess", emoji: "♟️" },
    { spanish: "Póker", english: "Poker", emoji: "🃏" },
    { spanish: "E-Sports", english: "E-Sports", emoji: "🎮" },
    { spanish: "Carreras de Drones", english: "Drone Racing", emoji: "🚁" },
    { spanish: "Paracaidismo en Interiores", english: "Indoor Skydiving", emoji: "🪂" },
    { spanish: "Trampolín", english: "Trampoline", emoji: "🤸" },
    { spanish: "Parkour en Gimnasio", english: "Gym Parkour", emoji: "🤸" },
  ];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🏆 Deportes / Sports</h2>
        <p className="text-muted-foreground">Aprende el vocabulario de deportes en inglés</p>
      </div>

      <div className="overflow-x-auto rounded-lg border border-border shadow-lg">
        <table className="w-full">
          <thead className="bg-primary text-white sticky top-0">
            <tr>
              <th className="p-4 text-left font-bold">Emoji</th>
              <th className="p-4 text-left font-bold">Español</th>
              <th className="p-4 text-left font-bold">English</th>
              <th className="p-4 text-center font-bold">Pronunciación</th>
            </tr>
          </thead>
          <tbody>
            {sports.map((sport, index) => (
              <tr
                key={index}
                className={`${
                  index % 2 === 0 ? "bg-card" : "bg-muted/30"
                } hover:bg-accent/20 transition-colors`}
              >
                <td className="p-4 text-3xl">{sport.emoji}</td>
                <td className="p-4 font-medium text-foreground">{sport.spanish}</td>
                <td className="p-4 text-foreground">{sport.english}</td>
                <td className="p-4">
                  <button
                    onClick={() => speak(sport.english, "en-US")}
                    className="pronunciation-btn mx-auto"
                    aria-label={`Pronunciar ${sport.english}`}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
