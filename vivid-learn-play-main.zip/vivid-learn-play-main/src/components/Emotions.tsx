import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const Emotions = () => {
  const { speak } = useSpeech();

  const emotions = [
    // Basic Emotions
    { english: "Happy", spanish: "Feliz", emoji: "😊", intensity: "Positive", category: "Básicas" },
    { english: "Sad", spanish: "Triste", emoji: "😢", intensity: "Negative", category: "Básicas" },
    { english: "Angry", spanish: "Enojado", emoji: "😠", intensity: "Negative", category: "Básicas" },
    { english: "Scared", spanish: "Asustado", emoji: "😨", intensity: "Negative", category: "Básicas" },
    { english: "Surprised", spanish: "Sorprendido", emoji: "😲", intensity: "Neutral", category: "Básicas" },
    { english: "Disgusted", spanish: "Disgustado", emoji: "🤢", intensity: "Negative", category: "Básicas" },

    // Joy & Happiness
    { english: "Joyful", spanish: "Alegre", emoji: "😄", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Cheerful", spanish: "Animado", emoji: "😊", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Excited", spanish: "Emocionado", emoji: "🤩", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Delighted", spanish: "Encantado", emoji: "😁", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Content", spanish: "Contento", emoji: "🙂", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Satisfied", spanish: "Satisfecho", emoji: "😌", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Pleased", spanish: "Complacido", emoji: "😊", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Thrilled", spanish: "Emocionado", emoji: "🤗", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Ecstatic", spanish: "Eufórico", emoji: "🤩", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Elated", spanish: "Exultante", emoji: "😃", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Grateful", spanish: "Agradecido", emoji: "🙏", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Thankful", spanish: "Agradecido", emoji: "😊", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Amused", spanish: "Divertido", emoji: "😄", intensity: "Positive", category: "Alegría y Felicidad" },
    { english: "Playful", spanish: "Juguetón", emoji: "😜", intensity: "Positive", category: "Alegría y Felicidad" },

    // Sadness & Grief
    { english: "Unhappy", spanish: "Infeliz", emoji: "☹️", intensity: "Negative", category: "Tristeza y Dolor" },
    { english: "Depressed", spanish: "Deprimido", emoji: "😞", intensity: "Negative", category: "Tristeza y Dolor" },
    { english: "Miserable", spanish: "Miserable", emoji: "😭", intensity: "Negative", category: "Tristeza y Dolor" },
    { english: "Heartbroken", spanish: "Con el corazón roto", emoji: "💔", intensity: "Negative", category: "Tristeza y Dolor" },
    { english: "Disappointed", spanish: "Decepcionado", emoji: "😔", intensity: "Negative", category: "Tristeza y Dolor" },
    { english: "Discouraged", spanish: "Desanimado", emoji: "😞", intensity: "Negative", category: "Tristeza y Dolor" },
    { english: "Hopeless", spanish: "Sin esperanza", emoji: "😩", intensity: "Negative", category: "Tristeza y Dolor" },
    { english: "Lonely", spanish: "Solo", emoji: "😔", intensity: "Negative", category: "Tristeza y Dolor" },
    { english: "Isolated", spanish: "Aislado", emoji: "😞", intensity: "Negative", category: "Tristeza y Dolor" },
    { english: "Melancholic", spanish: "Melancólico", emoji: "😔", intensity: "Negative", category: "Tristeza y Dolor" },
    { english: "Sorrowful", spanish: "Afligido", emoji: "😢", intensity: "Negative", category: "Tristeza y Dolor" },
    { english: "Regretful", spanish: "Arrepentido", emoji: "😔", intensity: "Negative", category: "Tristeza y Dolor" },

    // Anger & Frustration
    { english: "Furious", spanish: "Furioso", emoji: "😡", intensity: "Negative", category: "Enojo y Frustración" },
    { english: "Irritated", spanish: "Irritado", emoji: "😒", intensity: "Negative", category: "Enojo y Frustración" },
    { english: "Annoyed", spanish: "Molesto", emoji: "😠", intensity: "Negative", category: "Enojo y Frustración" },
    { english: "Frustrated", spanish: "Frustrado", emoji: "😤", intensity: "Negative", category: "Enojo y Frustración" },
    { english: "Mad", spanish: "Enojado", emoji: "😠", intensity: "Negative", category: "Enojo y Frustración" },
    { english: "Enraged", spanish: "Enfurecido", emoji: "🤬", intensity: "Negative", category: "Enojo y Frustración" },
    { english: "Bitter", spanish: "Amargado", emoji: "😒", intensity: "Negative", category: "Enojo y Frustración" },
    { english: "Resentful", spanish: "Resentido", emoji: "😠", intensity: "Negative", category: "Enojo y Frustración" },
    { english: "Outraged", spanish: "Indignado", emoji: "😡", intensity: "Negative", category: "Enojo y Frustración" },
    { english: "Hostile", spanish: "Hostil", emoji: "😤", intensity: "Negative", category: "Enojo y Frustración" },

    // Fear & Anxiety
    { english: "Afraid", spanish: "Temeroso", emoji: "😨", intensity: "Negative", category: "Miedo y Ansiedad" },
    { english: "Terrified", spanish: "Aterrorizado", emoji: "😱", intensity: "Negative", category: "Miedo y Ansiedad" },
    { english: "Frightened", spanish: "Asustado", emoji: "😰", intensity: "Negative", category: "Miedo y Ansiedad" },
    { english: "Anxious", spanish: "Ansioso", emoji: "😰", intensity: "Negative", category: "Miedo y Ansiedad" },
    { english: "Worried", spanish: "Preocupado", emoji: "😟", intensity: "Negative", category: "Miedo y Ansiedad" },
    { english: "Nervous", spanish: "Nervioso", emoji: "😬", intensity: "Negative", category: "Miedo y Ansiedad" },
    { english: "Panicked", spanish: "En pánico", emoji: "😱", intensity: "Negative", category: "Miedo y Ansiedad" },
    { english: "Stressed", spanish: "Estresado", emoji: "😩", intensity: "Negative", category: "Miedo y Ansiedad" },
    { english: "Tense", spanish: "Tenso", emoji: "😬", intensity: "Negative", category: "Miedo y Ansiedad" },
    { english: "Uneasy", spanish: "Intranquilo", emoji: "😟", intensity: "Negative", category: "Miedo y Ansiedad" },
    { english: "Insecure", spanish: "Inseguro", emoji: "😕", intensity: "Negative", category: "Miedo y Ansiedad" },
    { english: "Overwhelmed", spanish: "Abrumado", emoji: "😵", intensity: "Negative", category: "Miedo y Ansiedad" },

    // Love & Affection
    { english: "Loving", spanish: "Amoroso", emoji: "😍", intensity: "Positive", category: "Amor y Afecto" },
    { english: "Affectionate", spanish: "Cariñoso", emoji: "🥰", intensity: "Positive", category: "Amor y Afecto" },
    { english: "Adoring", spanish: "Adorable", emoji: "😘", intensity: "Positive", category: "Amor y Afecto" },
    { english: "Passionate", spanish: "Apasionado", emoji: "😍", intensity: "Positive", category: "Amor y Afecto" },
    { english: "Romantic", spanish: "Romántico", emoji: "💕", intensity: "Positive", category: "Amor y Afecto" },
    { english: "Tender", spanish: "Tierno", emoji: "🥰", intensity: "Positive", category: "Amor y Afecto" },
    { english: "Caring", spanish: "Cariñoso", emoji: "😊", intensity: "Positive", category: "Amor y Afecto" },
    { english: "Warm", spanish: "Cálido", emoji: "🤗", intensity: "Positive", category: "Amor y Afecto" },

    // Calm & Peace
    { english: "Calm", spanish: "Calmado", emoji: "😌", intensity: "Positive", category: "Calma y Paz" },
    { english: "Peaceful", spanish: "Pacífico", emoji: "😇", intensity: "Positive", category: "Calma y Paz" },
    { english: "Relaxed", spanish: "Relajado", emoji: "😎", intensity: "Positive", category: "Calma y Paz" },
    { english: "Serene", spanish: "Sereno", emoji: "😌", intensity: "Positive", category: "Calma y Paz" },
    { english: "Tranquil", spanish: "Tranquilo", emoji: "🧘", intensity: "Positive", category: "Calma y Paz" },
    { english: "Comfortable", spanish: "Cómodo", emoji: "😊", intensity: "Positive", category: "Calma y Paz" },

    // Confusion & Doubt
    { english: "Confused", spanish: "Confundido", emoji: "😕", intensity: "Neutral", category: "Confusión y Duda" },
    { english: "Puzzled", spanish: "Perplejo", emoji: "🤔", intensity: "Neutral", category: "Confusión y Duda" },
    { english: "Uncertain", spanish: "Incierto", emoji: "😐", intensity: "Neutral", category: "Confusión y Duda" },
    { english: "Doubtful", spanish: "Dudoso", emoji: "🤨", intensity: "Neutral", category: "Confusión y Duda" },
    { english: "Skeptical", spanish: "Escéptico", emoji: "🤨", intensity: "Neutral", category: "Confusión y Duda" },
    { english: "Bewildered", spanish: "Desconcertado", emoji: "😵", intensity: "Neutral", category: "Confusión y Duda" },
    { english: "Perplexed", spanish: "Perplejo", emoji: "😕", intensity: "Neutral", category: "Confusión y Duda" },

    // Pride & Confidence
    { english: "Proud", spanish: "Orgulloso", emoji: "😌", intensity: "Positive", category: "Orgullo y Confianza" },
    { english: "Confident", spanish: "Seguro", emoji: "😎", intensity: "Positive", category: "Orgullo y Confianza" },
    { english: "Accomplished", spanish: "Realizado", emoji: "😊", intensity: "Positive", category: "Orgullo y Confianza" },
    { english: "Successful", spanish: "Exitoso", emoji: "😄", intensity: "Positive", category: "Orgullo y Confianza" },
    { english: "Capable", spanish: "Capaz", emoji: "💪", intensity: "Positive", category: "Orgullo y Confianza" },
    { english: "Empowered", spanish: "Empoderado", emoji: "💪", intensity: "Positive", category: "Orgullo y Confianza" },

    // Shame & Guilt
    { english: "Ashamed", spanish: "Avergonzado", emoji: "😳", intensity: "Negative", category: "Vergüenza y Culpa" },
    { english: "Embarrassed", spanish: "Avergonzado", emoji: "😳", intensity: "Negative", category: "Vergüenza y Culpa" },
    { english: "Guilty", spanish: "Culpable", emoji: "😔", intensity: "Negative", category: "Vergüenza y Culpa" },
    { english: "Humiliated", spanish: "Humillado", emoji: "😣", intensity: "Negative", category: "Vergüenza y Culpa" },
    { english: "Mortified", spanish: "Mortificado", emoji: "😖", intensity: "Negative", category: "Vergüenza y Culpa" },

    // Envy & Jealousy
    { english: "Jealous", spanish: "Celoso", emoji: "😒", intensity: "Negative", category: "Envidia y Celos" },
    { english: "Envious", spanish: "Envidioso", emoji: "😒", intensity: "Negative", category: "Envidia y Celos" },
    { english: "Covetous", spanish: "Codicioso", emoji: "🤑", intensity: "Negative", category: "Envidia y Celos" },

    // Boredom & Indifference
    { english: "Bored", spanish: "Aburrido", emoji: "😑", intensity: "Neutral", category: "Aburrimiento e Indiferencia" },
    { english: "Indifferent", spanish: "Indiferente", emoji: "😐", intensity: "Neutral", category: "Aburrimiento e Indiferencia" },
    { english: "Apathetic", spanish: "Apático", emoji: "😶", intensity: "Neutral", category: "Aburrimiento e Indiferencia" },
    { english: "Uninterested", spanish: "Desinteresado", emoji: "😑", intensity: "Neutral", category: "Aburrimiento e Indiferencia" },

    // Tiredness
    { english: "Tired", spanish: "Cansado", emoji: "😴", intensity: "Negative", category: "Cansancio" },
    { english: "Exhausted", spanish: "Exhausto", emoji: "😩", intensity: "Negative", category: "Cansancio" },
    { english: "Weary", spanish: "Agotado", emoji: "😫", intensity: "Negative", category: "Cansancio" },
    { english: "Drained", spanish: "Agotado", emoji: "😵", intensity: "Negative", category: "Cansancio" },
    { english: "Sleepy", spanish: "Somnoliento", emoji: "🥱", intensity: "Neutral", category: "Cansancio" },

    // Energy & Motivation
    { english: "Energetic", spanish: "Energético", emoji: "⚡", intensity: "Positive", category: "Energía y Motivación" },
    { english: "Enthusiastic", spanish: "Entusiasta", emoji: "🤩", intensity: "Positive", category: "Energía y Motivación" },
    { english: "Motivated", spanish: "Motivado", emoji: "💪", intensity: "Positive", category: "Energía y Motivación" },
    { english: "Inspired", spanish: "Inspirado", emoji: "✨", intensity: "Positive", category: "Energía y Motivación" },
    { english: "Determined", spanish: "Determinado", emoji: "😤", intensity: "Positive", category: "Energía y Motivación" },
    { english: "Focused", spanish: "Concentrado", emoji: "🎯", intensity: "Positive", category: "Energía y Motivación" },
  ];

  const groupedEmotions = emotions.reduce((acc, emotion) => {
    if (!acc[emotion.category]) {
      acc[emotion.category] = [];
    }
    acc[emotion.category].push(emotion);
    return acc;
  }, {} as Record<string, typeof emotions>);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">😊 Emotions & Feelings</h2>
        <p className="text-muted-foreground">Aprende a expresar emociones y sentimientos en inglés</p>
      </div>

      {Object.entries(groupedEmotions).map(([category, items]) => (
        <div key={category}>
          <h3 className="text-2xl font-bold text-primary mb-4">{category}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {items.map((emotion) => (
              <div
                key={emotion.english}
                className={`learn-card flex items-center justify-between p-4 ${
                  emotion.intensity === "Positive"
                    ? "bg-gradient-to-br from-success to-success/70"
                    : emotion.intensity === "Negative"
                    ? "bg-gradient-to-br from-coral to-coral/70"
                    : "bg-gradient-to-br from-secondary to-secondary/70"
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-4xl">{emotion.emoji}</span>
                  <div>
                    <p className="font-bold text-white text-lg">{emotion.english}</p>
                    <p className="text-sm text-white/80">{emotion.spanish}</p>
                  </div>
                </div>
                <button
                  onClick={() => speak(emotion.english)}
                  className="pronunciation-btn bg-white text-primary"
                  aria-label={`Pronounce ${emotion.english}`}
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};
