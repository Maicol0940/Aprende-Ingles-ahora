import { Volume2, Search } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";
import { Input } from "./ui/input";
import { useState } from "react";

export const Professions = () => {
  const { speak } = useSpeech();
  const [search, setSearch] = useState("");

  const professions = [
    { emoji: "👩‍🏫", english: "Teacher", spanish: "Profesor/a" },
    { emoji: "👨‍⚕️", english: "Doctor", spanish: "Doctor/a" },
    { emoji: "👩‍⚕️", english: "Nurse", spanish: "Enfermero/a" },
    { emoji: "👮", english: "Police Officer", spanish: "Policía" },
    { emoji: "👷", english: "Engineer", spanish: "Ingeniero/a" },
    { emoji: "⚖️", english: "Lawyer", spanish: "Abogado/a" },
    { emoji: "👨‍🍳", english: "Chef", spanish: "Cocinero/a" },
    { emoji: "🚜", english: "Farmer", spanish: "Granjero/a" },
    { emoji: "👨‍💼", english: "Businessman", spanish: "Empresario" },
    { emoji: "👩‍💻", english: "Programmer", spanish: "Programador/a" },
    { emoji: "👨‍🔧", english: "Mechanic", spanish: "Mecánico/a" },
    { emoji: "👩‍🔬", english: "Scientist", spanish: "Científico/a" },
    { emoji: "👨‍🎨", english: "Artist", spanish: "Artista" },
    { emoji: "👩‍✈️", english: "Pilot", spanish: "Piloto" },
    { emoji: "🚒", english: "Firefighter", spanish: "Bombero/a" },
    { emoji: "👨‍🏭", english: "Factory Worker", spanish: "Trabajador de Fábrica" },
    { emoji: "👩‍🎤", english: "Singer", spanish: "Cantante" },
    { emoji: "📸", english: "Photographer", spanish: "Fotógrafo/a" },
    { emoji: "🎭", english: "Actor", spanish: "Actor/Actriz" },
    { emoji: "📰", english: "Journalist", spanish: "Periodista" },
    { emoji: "🏗️", english: "Architect", spanish: "Arquitecto/a" },
    { emoji: "💇", english: "Hairdresser", spanish: "Peluquero/a" },
    { emoji: "🧑‍🚀", english: "Astronaut", spanish: "Astronauta" },
    { emoji: "👨‍🌾", english: "Gardener", spanish: "Jardinero/a" },
    { emoji: "👩‍⚖️", english: "Judge", spanish: "Juez/a" },
    { emoji: "👨‍💻", english: "Web Developer", spanish: "Desarrollador Web" },
    { emoji: "👩‍💼", english: "Manager", spanish: "Gerente" },
    { emoji: "🎓", english: "Professor", spanish: "Profesor Universitario" },
    { emoji: "👨‍🔬", english: "Chemist", spanish: "Químico/a" },
    { emoji: "👩‍🏭", english: "Operator", spanish: "Operador/a" },
    { emoji: "🚑", english: "Paramedic", spanish: "Paramédico/a" },
    { emoji: "👨‍🚒", english: "Firefighter Captain", spanish: "Capitán de Bomberos" },
    { emoji: "👮‍♀️", english: "Detective", spanish: "Detective" },
    { emoji: "⚽", english: "Athlete", spanish: "Atleta" },
    { emoji: "🏋️", english: "Personal Trainer", spanish: "Entrenador Personal" },
    { emoji: "🎬", english: "Director", spanish: "Director/a" },
    { emoji: "📺", english: "TV Host", spanish: "Presentador/a de TV" },
    { emoji: "🎙️", english: "Radio Host", spanish: "Locutor/a" },
    { emoji: "🖌️", english: "Designer", spanish: "Diseñador/a" },
    { emoji: "🎨", english: "Painter", spanish: "Pintor/a" },
    { emoji: "🎭", english: "Playwright", spanish: "Dramaturgo/a" },
    { emoji: "🎸", english: "Musician", spanish: "Músico/a" },
    { emoji: "🎹", english: "Pianist", spanish: "Pianista" },
    { emoji: "🥁", english: "Drummer", spanish: "Baterista" },
    { emoji: "🎺", english: "Trumpeter", spanish: "Trompetista" },
    { emoji: "🎻", english: "Violinist", spanish: "Violinista" },
    { emoji: "📖", english: "Writer", spanish: "Escritor/a" },
    { emoji: "📝", english: "Editor", spanish: "Editor/a" },
    { emoji: "📚", english: "Librarian", spanish: "Bibliotecario/a" },
    { emoji: "🔭", english: "Astronomer", spanish: "Astrónomo/a" },
    { emoji: "🧬", english: "Biologist", spanish: "Biólogo/a" },
    { emoji: "🦷", english: "Dentist", spanish: "Dentista" },
    { emoji: "👁️", english: "Optometrist", spanish: "Optometrista" },
    { emoji: "💊", english: "Pharmacist", spanish: "Farmacéutico/a" },
    { emoji: "🧘", english: "Yoga Instructor", spanish: "Instructor de Yoga" },
    { emoji: "💼", english: "Accountant", spanish: "Contador/a" },
    { emoji: "📊", english: "Analyst", spanish: "Analista" },
    { emoji: "📈", english: "Financial Advisor", spanish: "Asesor Financiero" },
    { emoji: "🏦", english: "Banker", spanish: "Banquero/a" },
    { emoji: "🛒", english: "Cashier", spanish: "Cajero/a" },
    { emoji: "🎯", english: "Marketing Specialist", spanish: "Especialista en Marketing" },
    { emoji: "📱", english: "Social Media Manager", spanish: "Gestor de Redes Sociales" },
    { emoji: "🎥", english: "Videographer", spanish: "Videógrafo/a" },
    { emoji: "📸", english: "Photo Editor", spanish: "Editor de Fotos" },
    { emoji: "🎮", english: "Game Designer", spanish: "Diseñador de Juegos" },
    { emoji: "🤖", english: "AI Engineer", spanish: "Ingeniero de IA" },
    { emoji: "🔒", english: "Security Guard", spanish: "Guardia de Seguridad" },
    { emoji: "🧳", english: "Travel Agent", spanish: "Agente de Viajes" },
    { emoji: "✈️", english: "Flight Attendant", spanish: "Azafata/o" },
    { emoji: "🚢", english: "Sailor", spanish: "Marinero/a" },
    { emoji: "🚂", english: "Train Driver", spanish: "Conductor de Tren" },
    { emoji: "🚕", english: "Taxi Driver", spanish: "Taxista" },
    { emoji: "🚛", english: "Truck Driver", spanish: "Camionero/a" },
    { emoji: "📦", english: "Delivery Person", spanish: "Repartidor/a" },
    { emoji: "🍽️", english: "Waiter", spanish: "Mesero/a" },
    { emoji: "🍕", english: "Pizza Maker", spanish: "Pizzero/a" },
    { emoji: "🍰", english: "Baker", spanish: "Panadero/a" },
    { emoji: "☕", english: "Barista", spanish: "Barista" },
    { emoji: "🏪", english: "Shop Owner", spanish: "Dueño de Tienda" },
    { emoji: "🏗️", english: "Construction Worker", spanish: "Trabajador de Construcción" },
    { emoji: "🔨", english: "Carpenter", spanish: "Carpintero/a" },
    { emoji: "🔧", english: "Plumber", spanish: "Plomero/a" },
    { emoji: "💡", english: "Electrician", spanish: "Electricista" },
    { emoji: "🎨", english: "Interior Designer", spanish: "Diseñador de Interiores" },
    { emoji: "🏡", english: "Real Estate Agent", spanish: "Agente Inmobiliario" },
    { emoji: "🧼", english: "Cleaner", spanish: "Limpiador/a" },
    { emoji: "🌻", english: "Florist", spanish: "Florista" },
    { emoji: "🐕", english: "Veterinarian", spanish: "Veterinario/a" },
    { emoji: "🐾", english: "Pet Groomer", spanish: "Peluquero de Mascotas" },
    { emoji: "🐴", english: "Jockey", spanish: "Jinete" },
    { emoji: "🎪", english: "Circus Performer", spanish: "Artista de Circo" },
    { emoji: "🤹", english: "Juggler", spanish: "Malabarista" },
    { emoji: "🎩", english: "Magician", spanish: "Mago/a" },
    { emoji: "🎨", english: "Tattoo Artist", spanish: "Tatuador/a" },
    { emoji: "💅", english: "Nail Technician", spanish: "Técnico de Uñas" },
    { emoji: "💄", english: "Makeup Artist", spanish: "Maquillador/a" },
    { emoji: "👗", english: "Fashion Designer", spanish: "Diseñador de Moda" },
    { emoji: "🧵", english: "Tailor", spanish: "Sastre" },
    { emoji: "👞", english: "Shoemaker", spanish: "Zapatero/a" },
    { emoji: "⌚", english: "Watchmaker", spanish: "Relojero/a" },
    { emoji: "💎", english: "Jeweler", spanish: "Joyero/a" },
    { emoji: "🔬", english: "Lab Technician", spanish: "Técnico de Laboratorio" },
    { emoji: "🧪", english: "Researcher", spanish: "Investigador/a" },
    { emoji: "📡", english: "Telecommunications Engineer", spanish: "Ingeniero de Telecomunicaciones" },
    { emoji: "🛰️", english: "Satellite Engineer", spanish: "Ingeniero de Satélites" },
    { emoji: "🎬", english: "Film Producer", spanish: "Productor de Cine" },
    { emoji: "🎥", english: "Cinematographer", spanish: "Cinematógrafo" },
    { emoji: "🎭", english: "Theater Director", spanish: "Director de Teatro" },
    { emoji: "🎪", english: "Clown", spanish: "Payaso" },
    { emoji: "🎨", english: "Sculptor", spanish: "Escultor/a" },
    { emoji: "🖼️", english: "Curator", spanish: "Curador/a" },
    { emoji: "📚", english: "Translator", spanish: "Traductor/a" },
    { emoji: "🗣️", english: "Interpreter", spanish: "Intérprete" },
    { emoji: "✈️", english: "Air Traffic Controller", spanish: "Controlador Aéreo" },
    { emoji: "🚢", english: "Captain", spanish: "Capitán" },
    { emoji: "🧑‍✈️", english: "Co-pilot", spanish: "Copiloto" },
    { emoji: "🚂", english: "Train Conductor", spanish: "Conductor de Tren" },
    { emoji: "🚌", english: "Bus Driver", spanish: "Conductor de Autobús" },
    { emoji: "🚕", english: "Uber Driver", spanish: "Conductor de Uber" },
    { emoji: "🏍️", english: "Motorcycle Courier", spanish: "Mensajero en Moto" },
    { emoji: "🚴", english: "Bike Messenger", spanish: "Mensajero en Bici" },
    { emoji: "🛵", english: "Scooter Rider", spanish: "Conductor de Scooter" },
    { emoji: "🍕", english: "Restaurant Manager", spanish: "Gerente de Restaurante" },
    { emoji: "🍽️", english: "Sommelier", spanish: "Sommelier" },
    { emoji: "🍰", english: "Pastry Chef", spanish: "Chef Pastelero" },
    { emoji: "🥖", english: "Bread Maker", spanish: "Panadero Artesanal" },
    { emoji: "🍺", english: "Bartender", spanish: "Cantinero/a" },
    { emoji: "☕", english: "Coffee Roaster", spanish: "Tostador de Café" },
    { emoji: "🍕", english: "Food Critic", spanish: "Crítico Gastronómico" },
    { emoji: "📸", english: "Wedding Photographer", spanish: "Fotógrafo de Bodas" },
    { emoji: "🎥", english: "YouTuber", spanish: "YouTuber" },
    { emoji: "📱", english: "Influencer", spanish: "Influencer" },
    { emoji: "🎮", english: "Game Tester", spanish: "Probador de Juegos" },
    { emoji: "🎮", english: "Streamer", spanish: "Streamer" },
    { emoji: "🎮", english: "E-sports Player", spanish: "Jugador de E-sports" },
    { emoji: "💻", english: "Data Scientist", spanish: "Científico de Datos" },
    { emoji: "🤖", english: "Machine Learning Engineer", spanish: "Ingeniero de Machine Learning" },
    { emoji: "🔐", english: "Cybersecurity Specialist", spanish: "Especialista en Ciberseguridad" },
    { emoji: "☁️", english: "Cloud Engineer", spanish: "Ingeniero de Nube" },
    { emoji: "📊", english: "Business Analyst", spanish: "Analista de Negocios" },
    { emoji: "📈", english: "Stock Trader", spanish: "Comerciante de Acciones" },
    { emoji: "💼", english: "Investment Banker", spanish: "Banquero de Inversión" },
    { emoji: "🏦", english: "Loan Officer", spanish: "Oficial de Préstamos" },
    { emoji: "💳", english: "Credit Analyst", spanish: "Analista de Crédito" },
    { emoji: "📊", english: "Auditor", spanish: "Auditor/a" },
  ];

  const filteredProfessions = professions.filter(
    (prof) =>
      prof.english.toLowerCase().includes(search.toLowerCase()) ||
      prof.spanish.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">👷 Profesiones y Trabajos</h2>
        <p className="text-muted-foreground">Aprende vocabulario de profesiones en inglés</p>
      </div>

      <div className="max-w-md mx-auto relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Buscar profesiones..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredProfessions.map((prof) => (
          <div key={prof.english} className="learn-card flex items-center justify-between bg-lavender">
            <div className="flex items-center gap-3">
              <span className="text-4xl">{prof.emoji}</span>
              <div>
                <p className="font-bold text-foreground">{prof.english}</p>
                <p className="text-sm text-muted-foreground">{prof.spanish}</p>
              </div>
            </div>
            <button
              onClick={() => speak(prof.english)}
              className="pronunciation-btn"
              aria-label={`Pronounce ${prof.english}`}
            >
              <Volume2 className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      {filteredProfessions.length === 0 && (
        <p className="text-center text-muted-foreground">No se encontraron profesiones. Intenta con otra búsqueda.</p>
      )}
    </div>
  );
};
