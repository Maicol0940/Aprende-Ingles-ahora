import { useState } from "react";
import { Volume2, Search } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";
import { Input } from "./ui/input";

export const Animals = () => {
  const { speak } = useSpeech();
  const [searchTerm, setSearchTerm] = useState("");

  const animals = [
    // Domésticos 🏠
    { emoji: "🐕", english: "Dog", spanish: "Perro", sound: "Woof", category: "Domésticos" },
    { emoji: "🐈", english: "Cat", spanish: "Gato", sound: "Meow", category: "Domésticos" },
    { emoji: "🐎", english: "Horse", spanish: "Caballo", sound: "Neigh", category: "Domésticos" },
    { emoji: "🐄", english: "Cow", spanish: "Vaca", sound: "Moo", category: "Domésticos" },
    { emoji: "🐷", english: "Pig", spanish: "Cerdo", sound: "Oink", category: "Domésticos" },
    { emoji: "🐑", english: "Sheep", spanish: "Oveja", sound: "Baa", category: "Domésticos" },
    { emoji: "🐐", english: "Goat", spanish: "Cabra", sound: "Bleat", category: "Domésticos" },
    { emoji: "🐓", english: "Rooster", spanish: "Gallo", sound: "Cock-a-doodle-doo", category: "Domésticos" },
    { emoji: "🐔", english: "Chicken", spanish: "Gallina", sound: "Cluck", category: "Domésticos" },
    { emoji: "🦆", english: "Duck", spanish: "Pato", sound: "Quack", category: "Domésticos" },
    { emoji: "🦃", english: "Turkey", spanish: "Pavo", sound: "Gobble", category: "Domésticos" },
    { emoji: "🐇", english: "Rabbit", spanish: "Conejo", sound: "Squeak", category: "Domésticos" },
    { emoji: "🐁", english: "Mouse", spanish: "Ratón", sound: "Squeak", category: "Domésticos" },
    { emoji: "🐹", english: "Hamster", spanish: "Hámster", sound: "Squeak", category: "Domésticos" },

    // Salvajes 🌴
    { emoji: "🦁", english: "Lion", spanish: "León", sound: "Roar", category: "Salvajes" },
    { emoji: "🐯", english: "Tiger", spanish: "Tigre", sound: "Roar", category: "Salvajes" },
    { emoji: "🐻", english: "Bear", spanish: "Oso", sound: "Growl", category: "Salvajes" },
    { emoji: "🐺", english: "Wolf", spanish: "Lobo", sound: "Howl", category: "Salvajes" },
    { emoji: "🦊", english: "Fox", spanish: "Zorro", sound: "Yip", category: "Salvajes" },
    { emoji: "🐘", english: "Elephant", spanish: "Elefante", sound: "Trumpet", category: "Salvajes" },
    { emoji: "🦏", english: "Rhinoceros", spanish: "Rinoceronte", sound: "Snort", category: "Salvajes" },
    { emoji: "🦛", english: "Hippopotamus", spanish: "Hipopótamo", sound: "Grunt", category: "Salvajes" },
    { emoji: "🦒", english: "Giraffe", spanish: "Jirafa", sound: "Hum", category: "Salvajes" },
    { emoji: "🦓", english: "Zebra", spanish: "Cebra", sound: "Whinny", category: "Salvajes" },
    { emoji: "🐆", english: "Leopard", spanish: "Leopardo", sound: "Roar", category: "Salvajes" },
    { emoji: "🐅", english: "Cheetah", spanish: "Guepardo", sound: "Chirp", category: "Salvajes" },
    { emoji: "🦍", english: "Gorilla", spanish: "Gorila", sound: "Grunt", category: "Salvajes" },
    { emoji: "🦧", english: "Orangutan", spanish: "Orangután", sound: "Call", category: "Salvajes" },
    { emoji: "🐒", english: "Monkey", spanish: "Mono", sound: "Screech", category: "Salvajes" },
    { emoji: "🐪", english: "Camel", spanish: "Camello", sound: "Groan", category: "Salvajes" },
    { emoji: "🦘", english: "Kangaroo", spanish: "Canguro", sound: "Chortle", category: "Salvajes" },
    { emoji: "🐨", english: "Koala", spanish: "Koala", sound: "Grunt", category: "Salvajes" },
    { emoji: "🐼", english: "Panda", spanish: "Panda", sound: "Bleat", category: "Salvajes" },

    // Acuáticos 🌊
    { emoji: "🐋", english: "Whale", spanish: "Ballena", sound: "Sing", category: "Acuáticos" },
    { emoji: "🐬", english: "Dolphin", spanish: "Delfín", sound: "Click", category: "Acuáticos" },
    { emoji: "🦈", english: "Shark", spanish: "Tiburón", sound: "Silent", category: "Acuáticos" },
    { emoji: "🐠", english: "Fish", spanish: "Pez", sound: "Bubble", category: "Acuáticos" },
    { emoji: "🐟", english: "Tropical Fish", spanish: "Pez Tropical", sound: "Bubble", category: "Acuáticos" },
    { emoji: "🐡", english: "Blowfish", spanish: "Pez Globo", sound: "Bubble", category: "Acuáticos" },
    { emoji: "🦑", english: "Squid", spanish: "Calamar", sound: "Silent", category: "Acuáticos" },
    { emoji: "🐙", english: "Octopus", spanish: "Pulpo", sound: "Silent", category: "Acuáticos" },
    { emoji: "🦀", english: "Crab", spanish: "Cangrejo", sound: "Click", category: "Acuáticos" },
    { emoji: "🦞", english: "Lobster", spanish: "Langosta", sound: "Click", category: "Acuáticos" },
    { emoji: "🦐", english: "Shrimp", spanish: "Camarón", sound: "Silent", category: "Acuáticos" },
    { emoji: "🐢", english: "Turtle", spanish: "Tortuga", sound: "Hiss", category: "Acuáticos" },
    { emoji: "🦭", english: "Seal", spanish: "Foca", sound: "Bark", category: "Acuáticos" },
    { emoji: "🦦", english: "Otter", spanish: "Nutria", sound: "Chirp", category: "Acuáticos" },

    // Aves 🦅
    { emoji: "🦅", english: "Eagle", spanish: "Águila", sound: "Screech", category: "Aves" },
    { emoji: "🦉", english: "Owl", spanish: "Búho", sound: "Hoot", category: "Aves" },
    { emoji: "🦜", english: "Parrot", spanish: "Loro", sound: "Squawk", category: "Aves" },
    { emoji: "🦚", english: "Peacock", spanish: "Pavo Real", sound: "Scream", category: "Aves" },
    { emoji: "🦢", english: "Swan", spanish: "Cisne", sound: "Honk", category: "Aves" },
    { emoji: "🦩", english: "Flamingo", spanish: "Flamenco", sound: "Honk", category: "Aves" },
    { emoji: "🐦", english: "Bird", spanish: "Pájaro", sound: "Chirp", category: "Aves" },
    { emoji: "🐧", english: "Penguin", spanish: "Pingüino", sound: "Squawk", category: "Aves" },
    { emoji: "🦆", english: "Duck", spanish: "Pato", sound: "Quack", category: "Aves" },
    { emoji: "🕊️", english: "Dove", spanish: "Paloma", sound: "Coo", category: "Aves" },
    { emoji: "🦤", english: "Dodo", spanish: "Dodo", sound: "Unknown", category: "Aves" },

    // Insectos 🐛
    { emoji: "🐝", english: "Bee", spanish: "Abeja", sound: "Buzz", category: "Insectos" },
    { emoji: "🐛", english: "Caterpillar", spanish: "Oruga", sound: "Silent", category: "Insectos" },
    { emoji: "🦋", english: "Butterfly", spanish: "Mariposa", sound: "Silent", category: "Insectos" },
    { emoji: "🐜", english: "Ant", spanish: "Hormiga", sound: "Silent", category: "Insectos" },
    { emoji: "🦗", english: "Cricket", spanish: "Grillo", sound: "Chirp", category: "Insectos" },
    { emoji: "🪲", english: "Beetle", spanish: "Escarabajo", sound: "Silent", category: "Insectos" },
    { emoji: "🐞", english: "Ladybug", spanish: "Mariquita", sound: "Silent", category: "Insectos" },
    { emoji: "🦟", english: "Mosquito", spanish: "Mosquito", sound: "Buzz", category: "Insectos" },
    { emoji: "🪰", english: "Fly", spanish: "Mosca", sound: "Buzz", category: "Insectos" },
    { emoji: "🕷️", english: "Spider", spanish: "Araña", sound: "Silent", category: "Insectos" },
    { emoji: "🦂", english: "Scorpion", spanish: "Escorpión", sound: "Silent", category: "Insectos" },

    // Reptiles 🦎
    { emoji: "🐍", english: "Snake", spanish: "Serpiente", sound: "Hiss", category: "Reptiles" },
    { emoji: "🦎", english: "Lizard", spanish: "Lagarto", sound: "Hiss", category: "Reptiles" },
    { emoji: "🐊", english: "Crocodile", spanish: "Cocodrilo", sound: "Hiss", category: "Reptiles" },
    { emoji: "🐢", english: "Turtle", spanish: "Tortuga", sound: "Hiss", category: "Reptiles" },
    { emoji: "🦕", english: "Dinosaur", spanish: "Dinosaurio", sound: "Roar", category: "Reptiles" },
    { emoji: "🦖", english: "T-Rex", spanish: "Tiranosaurio", sound: "Roar", category: "Reptiles" },
  ];

  const filteredAnimals = animals.filter(
    (animal) =>
      animal.english.toLowerCase().includes(searchTerm.toLowerCase()) ||
      animal.spanish.toLowerCase().includes(searchTerm.toLowerCase()) ||
      animal.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const groupedAnimals = filteredAnimals.reduce((acc, animal) => {
    if (!acc[animal.category]) {
      acc[animal.category] = [];
    }
    acc[animal.category].push(animal);
    return acc;
  }, {} as Record<string, typeof animals>);

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🦁 Animals</h2>
        <p className="text-muted-foreground">Aprende los nombres de animales en inglés</p>
      </div>

      <div className="max-w-md mx-auto relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
        <Input
          type="text"
          placeholder="Buscar animal..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="space-y-8">
        {Object.entries(groupedAnimals).map(([category, items]) => (
          <div key={category}>
            <h3 className="text-2xl font-bold text-primary mb-4 text-center">{category}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {items.map((animal) => (
                <div
                  key={animal.english}
                  className="learn-card bg-gradient-to-br from-primary to-primary/70 p-4 text-center space-y-2"
                >
                  <div className="text-5xl">{animal.emoji}</div>
                  <h4 className="text-lg font-bold text-white">{animal.english}</h4>
                  <p className="text-sm text-white/90 italic">{animal.spanish}</p>
                  <p className="text-xs text-white/70">"{animal.sound}"</p>
                  <button
                    onClick={() => speak(animal.english)}
                    className="pronunciation-btn mx-auto bg-white text-primary"
                    aria-label={`Pronounce ${animal.english}`}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
