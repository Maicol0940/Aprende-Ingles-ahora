import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const Family = () => {
  const { speak } = useSpeech();

  const familyMembers = [
    // Nuclear Family
    { english: "Mother", spanish: "Madre", emoji: "👩", category: "Familia Nuclear" },
    { english: "Father", spanish: "Padre", emoji: "👨", category: "Familia Nuclear" },
    { english: "Mom / Mommy", spanish: "Mamá / Mami", emoji: "👩", category: "Familia Nuclear" },
    { english: "Dad / Daddy", spanish: "Papá / Papi", emoji: "👨", category: "Familia Nuclear" },
    { english: "Son", spanish: "Hijo", emoji: "👦", category: "Familia Nuclear" },
    { english: "Daughter", spanish: "Hija", emoji: "👧", category: "Familia Nuclear" },
    { english: "Brother", spanish: "Hermano", emoji: "👦", category: "Familia Nuclear" },
    { english: "Sister", spanish: "Hermana", emoji: "👧", category: "Familia Nuclear" },
    { english: "Twin", spanish: "Gemelo/a", emoji: "👯", category: "Familia Nuclear" },
    { english: "Child", spanish: "Niño/a", emoji: "🧒", category: "Familia Nuclear" },
    { english: "Baby", spanish: "Bebé", emoji: "👶", category: "Familia Nuclear" },
    { english: "Toddler", spanish: "Niño Pequeño", emoji: "🧒", category: "Familia Nuclear" },
    { english: "Teenager", spanish: "Adolescente", emoji: "🧑", category: "Familia Nuclear" },
    { english: "Parents", spanish: "Padres", emoji: "👨‍👩‍👦", category: "Familia Nuclear" },
    { english: "Siblings", spanish: "Hermanos", emoji: "👦👧", category: "Familia Nuclear" },

    // Extended Family
    { english: "Grandfather", spanish: "Abuelo", emoji: "👴", category: "Familia Extendida" },
    { english: "Grandmother", spanish: "Abuela", emoji: "👵", category: "Familia Extendida" },
    { english: "Grandpa", spanish: "Abuelito", emoji: "👴", category: "Familia Extendida" },
    { english: "Grandma", spanish: "Abuelita", emoji: "👵", category: "Familia Extendida" },
    { english: "Grandparents", spanish: "Abuelos", emoji: "👴👵", category: "Familia Extendida" },
    { english: "Grandson", spanish: "Nieto", emoji: "👦", category: "Familia Extendida" },
    { english: "Granddaughter", spanish: "Nieta", emoji: "👧", category: "Familia Extendida" },
    { english: "Grandchild", spanish: "Nieto/a", emoji: "🧒", category: "Familia Extendida" },
    { english: "Uncle", spanish: "Tío", emoji: "👨", category: "Familia Extendida" },
    { english: "Aunt", spanish: "Tía", emoji: "👩", category: "Familia Extendida" },
    { english: "Nephew", spanish: "Sobrino", emoji: "👦", category: "Familia Extendida" },
    { english: "Niece", spanish: "Sobrina", emoji: "👧", category: "Familia Extendida" },
    { english: "Cousin", spanish: "Primo/a", emoji: "🧑", category: "Familia Extendida" },
    { english: "Great-grandfather", spanish: "Bisabuelo", emoji: "👴", category: "Familia Extendida" },
    { english: "Great-grandmother", spanish: "Bisabuela", emoji: "👵", category: "Familia Extendida" },
    { english: "Great-grandchild", spanish: "Bisnieto/a", emoji: "👶", category: "Familia Extendida" },

    // In-Laws & Marriage
    { english: "Husband", spanish: "Esposo", emoji: "🤵", category: "Matrimonio" },
    { english: "Wife", spanish: "Esposa", emoji: "👰", category: "Matrimonio" },
    { english: "Spouse", spanish: "Cónyuge", emoji: "💑", category: "Matrimonio" },
    { english: "Partner", spanish: "Pareja", emoji: "💑", category: "Matrimonio" },
    { english: "Fiancé", spanish: "Prometido", emoji: "💍", category: "Matrimonio" },
    { english: "Fiancée", spanish: "Prometida", emoji: "💍", category: "Matrimonio" },
    { english: "Boyfriend", spanish: "Novio", emoji: "👦", category: "Matrimonio" },
    { english: "Girlfriend", spanish: "Novia", emoji: "👧", category: "Matrimonio" },
    { english: "Father-in-law", spanish: "Suegro", emoji: "👨", category: "Matrimonio" },
    { english: "Mother-in-law", spanish: "Suegra", emoji: "👩", category: "Matrimonio" },
    { english: "Son-in-law", spanish: "Yerno", emoji: "🤵", category: "Matrimonio" },
    { english: "Daughter-in-law", spanish: "Nuera", emoji: "👰", category: "Matrimonio" },
    { english: "Brother-in-law", spanish: "Cuñado", emoji: "👨", category: "Matrimonio" },
    { english: "Sister-in-law", spanish: "Cuñada", emoji: "👩", category: "Matrimonio" },
    { english: "Stepfather", spanish: "Padrastro", emoji: "👨", category: "Matrimonio" },
    { english: "Stepmother", spanish: "Madrastra", emoji: "👩", category: "Matrimonio" },
    { english: "Stepson", spanish: "Hijastro", emoji: "👦", category: "Matrimonio" },
    { english: "Stepdaughter", spanish: "Hijastra", emoji: "👧", category: "Matrimonio" },
    { english: "Stepbrother", spanish: "Hermanastro", emoji: "👦", category: "Matrimonio" },
    { english: "Stepsister", spanish: "Hermanastra", emoji: "👧", category: "Matrimonio" },
    { english: "Half-brother", spanish: "Medio hermano", emoji: "👦", category: "Matrimonio" },
    { english: "Half-sister", spanish: "Media hermana", emoji: "👧", category: "Matrimonio" },

    // Others
    { english: "Godfather", spanish: "Padrino", emoji: "👨", category: "Otros" },
    { english: "Godmother", spanish: "Madrina", emoji: "👩", category: "Otros" },
    { english: "Godson", spanish: "Ahijado", emoji: "👦", category: "Otros" },
    { english: "Goddaughter", spanish: "Ahijada", emoji: "👧", category: "Otros" },
    { english: "Guardian", spanish: "Tutor/a", emoji: "👤", category: "Otros" },
    { english: "Ancestor", spanish: "Ancestro", emoji: "🧓", category: "Otros" },
    { english: "Descendant", spanish: "Descendiente", emoji: "🧒", category: "Otros" },
    { english: "Relative", spanish: "Pariente", emoji: "👥", category: "Otros" },
    { english: "Family", spanish: "Familia", emoji: "👨‍👩‍👧‍👦", category: "Otros" },
    { english: "Household", spanish: "Hogar", emoji: "🏠", category: "Otros" },
    { english: "Single parent", spanish: "Padre/Madre soltero/a", emoji: "👤", category: "Otros" },
    { english: "Adopted child", spanish: "Hijo/a adoptado/a", emoji: "🧒", category: "Otros" },
    { english: "Foster parent", spanish: "Padre/Madre de acogida", emoji: "👤", category: "Otros" },
    { english: "Foster child", spanish: "Hijo/a de acogida", emoji: "🧒", category: "Otros" },
  ];

  const groupedMembers = familyMembers.reduce((acc, member) => {
    if (!acc[member.category]) {
      acc[member.category] = [];
    }
    acc[member.category].push(member);
    return acc;
  }, {} as Record<string, typeof familyMembers>);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">👨‍👩‍👧‍👦 Family Members</h2>
        <p className="text-muted-foreground">Aprende los miembros de la familia en inglés</p>
      </div>

      {Object.entries(groupedMembers).map(([category, members]) => (
        <div key={category}>
          <h3 className="text-2xl font-bold text-primary mb-4">{category}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {members.map((member) => (
              <div
                key={member.english}
                className="learn-card bg-gradient-to-br from-lavender to-lavender/70 flex items-center justify-between p-4"
              >
                <div className="flex items-center gap-3">
                  <span className="text-4xl">{member.emoji}</span>
                  <div>
                    <p className="font-bold text-white text-lg">{member.english}</p>
                    <p className="text-sm text-white/80">{member.spanish}</p>
                  </div>
                </div>
                <button
                  onClick={() => speak(member.english)}
                  className="pronunciation-btn bg-white text-lavender"
                  aria-label={`Pronounce ${member.english}`}
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};
