import { Volume2, Search } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";
import { Input } from "./ui/input";
import { useState } from "react";

export const Foods = () => {
  const { speak } = useSpeech();
  const [search, setSearch] = useState("");

  const foods = [
    // Breakfast
    { emoji: "🥞", english: "Pancakes", spanish: "Panqueques", category: "Breakfast" },
    { emoji: "🍳", english: "Eggs", spanish: "Huevos", category: "Breakfast" },
    { emoji: "🥓", english: "Bacon", spanish: "Tocino", category: "Breakfast" },
    { emoji: "🥐", english: "Croissant", spanish: "Croissant", category: "Breakfast" },
    { emoji: "🧇", english: "Waffle", spanish: "Waffle", category: "Breakfast" },
    { emoji: "🥣", english: "Cereal", spanish: "Cereal", category: "Breakfast" },
    { emoji: "🥛", english: "Milk", spanish: "Leche", category: "Breakfast" },
    { emoji: "☕", english: "Coffee", spanish: "Café", category: "Breakfast" },
    
    // Lunch & Dinner
    { emoji: "🍕", english: "Pizza", spanish: "Pizza", category: "Main Course" },
    { emoji: "🍔", english: "Hamburger", spanish: "Hamburguesa", category: "Main Course" },
    { emoji: "🌭", english: "Hot Dog", spanish: "Perro Caliente", category: "Main Course" },
    { emoji: "🍗", english: "Chicken", spanish: "Pollo", category: "Main Course" },
    { emoji: "🥩", english: "Steak", spanish: "Filete", category: "Main Course" },
    { emoji: "🍖", english: "Meat", spanish: "Carne", category: "Main Course" },
    { emoji: "🍝", english: "Pasta", spanish: "Pasta", category: "Main Course" },
    { emoji: "🍜", english: "Noodles", spanish: "Fideos", category: "Main Course" },
    { emoji: "🍲", english: "Soup", spanish: "Sopa", category: "Main Course" },
    { emoji: "🥘", english: "Paella", spanish: "Paella", category: "Main Course" },
    { emoji: "🍛", english: "Curry", spanish: "Curry", category: "Main Course" },
    { emoji: "🍚", english: "Rice", spanish: "Arroz", category: "Main Course" },
    { emoji: "🥙", english: "Kebab", spanish: "Kebab", category: "Main Course" },
    { emoji: "🌮", english: "Taco", spanish: "Taco", category: "Main Course" },
    { emoji: "🌯", english: "Burrito", spanish: "Burrito", category: "Main Course" },
    { emoji: "🥗", english: "Salad", spanish: "Ensalada", category: "Main Course" },
    { emoji: "🥪", english: "Sandwich", spanish: "Sándwich", category: "Main Course" },
    { emoji: "🍤", english: "Shrimp", spanish: "Camarones", category: "Main Course" },
    { emoji: "🍣", english: "Sushi", spanish: "Sushi", category: "Main Course" },
    { emoji: "🦞", english: "Lobster", spanish: "Langosta", category: "Main Course" },
    
    // Desserts
    { emoji: "🍰", english: "Cake", spanish: "Pastel", category: "Dessert" },
    { emoji: "🎂", english: "Birthday Cake", spanish: "Pastel de Cumpleaños", category: "Dessert" },
    { emoji: "🧁", english: "Cupcake", spanish: "Magdalena", category: "Dessert" },
    { emoji: "🍪", english: "Cookie", spanish: "Galleta", category: "Dessert" },
    { emoji: "🍩", english: "Donut", spanish: "Dona", category: "Dessert" },
    { emoji: "🍨", english: "Ice Cream", spanish: "Helado", category: "Dessert" },
    { emoji: "🍧", english: "Shaved Ice", spanish: "Granizado", category: "Dessert" },
    { emoji: "🍦", english: "Soft Ice Cream", spanish: "Helado Suave", category: "Dessert" },
    { emoji: "🥧", english: "Pie", spanish: "Tarta", category: "Dessert" },
    { emoji: "🍮", english: "Pudding", spanish: "Pudín", category: "Dessert" },
    { emoji: "🍫", english: "Chocolate", spanish: "Chocolate", category: "Dessert" },
    { emoji: "🍬", english: "Candy", spanish: "Caramelo", category: "Dessert" },
    
    // More Main Courses
    { emoji: "🍱", english: "Bento Box", spanish: "Caja Bento", category: "Main Course" },
    { emoji: "🥟", english: "Dumpling", spanish: "Empanada", category: "Main Course" },
    { emoji: "🥠", english: "Fortune Cookie", spanish: "Galleta de la Fortuna", category: "Main Course" },
    { emoji: "🍢", english: "Oden", spanish: "Oden", category: "Main Course" },
    { emoji: "🍡", english: "Dango", spanish: "Dango", category: "Main Course" },
    { emoji: "🍧", english: "Ramen", spanish: "Ramen", category: "Main Course" },
    { emoji: "🥮", english: "Mooncake", spanish: "Pastel de Luna", category: "Main Course" },
    { emoji: "🍥", english: "Fish Cake", spanish: "Pastel de Pescado", category: "Main Course" },
    { emoji: "🥫", english: "Canned Food", spanish: "Comida Enlatada", category: "Main Course" },
    { emoji: "🍿", english: "Popcorn", spanish: "Palomitas", category: "Main Course" },
    { emoji: "🧆", english: "Falafel", spanish: "Falafel", category: "Main Course" },
    { emoji: "🥚", english: "Egg", spanish: "Huevo", category: "Main Course" },
    { emoji: "🧀", english: "Cheese", spanish: "Queso", category: "Main Course" },
    { emoji: "🍖", english: "Ribs", spanish: "Costillas", category: "Main Course" },
    { emoji: "🥩", english: "Beef", spanish: "Carne de Res", category: "Main Course" },
    { emoji: "🍗", english: "Poultry", spanish: "Aves", category: "Main Course" },
    { emoji: "🥓", english: "Pork", spanish: "Cerdo", category: "Main Course" },
    { emoji: "🦴", english: "Bone", spanish: "Hueso", category: "Main Course" },
    { emoji: "🌭", english: "Sausage", spanish: "Salchicha", category: "Main Course" },
    { emoji: "🥖", english: "Baguette", spanish: "Baguette", category: "Main Course" },
    { emoji: "🫓", english: "Flatbread", spanish: "Pan Plano", category: "Main Course" },
    { emoji: "🥨", english: "Pretzel", spanish: "Pretzel", category: "Main Course" },
    { emoji: "🥯", english: "Bagel", spanish: "Bagel", category: "Main Course" },
    { emoji: "🧇", english: "Quesadilla", spanish: "Quesadilla", category: "Main Course" },
    { emoji: "🫔", english: "Tamale", spanish: "Tamal", category: "Main Course" },
    { emoji: "🥘", english: "Stew", spanish: "Guiso", category: "Main Course" },
    { emoji: "🍲", english: "Hot Pot", spanish: "Olla Caliente", category: "Main Course" },
    { emoji: "🥧", english: "Quiche", spanish: "Quiche", category: "Main Course" },
    { emoji: "🧈", english: "Butter", spanish: "Mantequilla", category: "Main Course" },
    { emoji: "🍞", english: "Bread", spanish: "Pan", category: "Main Course" },
    
    // More Breakfast
    { emoji: "🥚", english: "Scrambled Eggs", spanish: "Huevos Revueltos", category: "Breakfast" },
    { emoji: "🍳", english: "Fried Egg", spanish: "Huevo Frito", category: "Breakfast" },
    { emoji: "🥐", english: "Pastry", spanish: "Pastelería", category: "Breakfast" },
    { emoji: "🍞", english: "Toast", spanish: "Tostada", category: "Breakfast" },
    { emoji: "🥯", english: "Cream Cheese", spanish: "Queso Crema", category: "Breakfast" },
    { emoji: "🧈", english: "Jam", spanish: "Mermelada", category: "Breakfast" },
    { emoji: "🍯", english: "Honey", spanish: "Miel", category: "Breakfast" },
    { emoji: "🥤", english: "Juice", spanish: "Jugo", category: "Breakfast" },
    { emoji: "🫖", english: "Tea", spanish: "Té", category: "Breakfast" },
    { emoji: "🍵", english: "Green Tea", spanish: "Té Verde", category: "Breakfast" },
    { emoji: "🧋", english: "Bubble Tea", spanish: "Té de Burbujas", category: "Breakfast" },
    { emoji: "🧃", english: "Juice Box", spanish: "Caja de Jugo", category: "Breakfast" },
    
    // More Desserts
    { emoji: "🍭", english: "Lollipop", spanish: "Chupetín", category: "Dessert" },
    { emoji: "🍮", english: "Flan", spanish: "Flan", category: "Dessert" },
    { emoji: "🍯", english: "Honey Cake", spanish: "Pastel de Miel", category: "Dessert" },
    { emoji: "🥐", english: "Pain au Chocolat", spanish: "Pan de Chocolate", category: "Dessert" },
    { emoji: "🧁", english: "Muffin", spanish: "Muffin", category: "Dessert" },
    { emoji: "🍰", english: "Cheesecake", spanish: "Pastel de Queso", category: "Dessert" },
    { emoji: "🎂", english: "Layer Cake", spanish: "Pastel de Capas", category: "Dessert" },
    { emoji: "🍪", english: "Biscuit", spanish: "Bizcocho", category: "Dessert" },
    { emoji: "🍩", english: "Cruller", spanish: "Churro", category: "Dessert" },
    { emoji: "🧈", english: "Butter Cookie", spanish: "Galleta de Mantequilla", category: "Dessert" },
    { emoji: "🍫", english: "Chocolate Bar", spanish: "Barra de Chocolate", category: "Dessert" },
    { emoji: "🍬", english: "Gummy", spanish: "Gomita", category: "Dessert" },
    { emoji: "🥧", english: "Apple Pie", spanish: "Pastel de Manzana", category: "Dessert" },
    { emoji: "🍮", english: "Custard", spanish: "Natilla", category: "Dessert" },
    { emoji: "🍨", english: "Gelato", spanish: "Gelato", category: "Dessert" },
    { emoji: "🍧", english: "Sorbet", spanish: "Sorbete", category: "Dessert" },
    { emoji: "🍦", english: "Frozen Yogurt", spanish: "Yogur Congelado", category: "Dessert" },
    { emoji: "🧁", english: "Brownie", spanish: "Brownie", category: "Dessert" },
    { emoji: "🍰", english: "Tiramisu", spanish: "Tiramisú", category: "Dessert" },
    { emoji: "🎂", english: "Wedding Cake", spanish: "Pastel de Bodas", category: "Dessert" },
    
    // Beverages
    { emoji: "🥤", english: "Soda", spanish: "Gaseosa", category: "Bebidas" },
    { emoji: "🧃", english: "Apple Juice", spanish: "Jugo de Manzana", category: "Bebidas" },
    { emoji: "🧋", english: "Milk Tea", spanish: "Té con Leche", category: "Bebidas" },
    { emoji: "🍵", english: "Hot Tea", spanish: "Té Caliente", category: "Bebidas" },
    { emoji: "☕", english: "Espresso", spanish: "Café Expreso", category: "Bebidas" },
    { emoji: "🥛", english: "Chocolate Milk", spanish: "Leche con Chocolate", category: "Bebidas" },
    { emoji: "🧊", english: "Ice Water", spanish: "Agua con Hielo", category: "Bebidas" },
    { emoji: "🍹", english: "Tropical Drink", spanish: "Bebida Tropical", category: "Bebidas" },
    { emoji: "🍸", english: "Cocktail", spanish: "Cóctel", category: "Bebidas" },
    { emoji: "🍷", english: "Wine", spanish: "Vino", category: "Bebidas" },
    { emoji: "🍺", english: "Beer", spanish: "Cerveza", category: "Bebidas" },
    { emoji: "🍻", english: "Cheers", spanish: "Salud", category: "Bebidas" },
    { emoji: "🥂", english: "Champagne", spanish: "Champaña", category: "Bebidas" },
    { emoji: "🍾", english: "Bottle", spanish: "Botella", category: "Bebidas" },
    { emoji: "🥤", english: "Lemonade", spanish: "Limonada", category: "Bebidas" },
    { emoji: "🧃", english: "Orange Juice", spanish: "Jugo de Naranja", category: "Bebidas" },
    { emoji: "🥛", english: "Almond Milk", spanish: "Leche de Almendras", category: "Bebidas" },
    { emoji: "☕", english: "Cappuccino", spanish: "Capuchino", category: "Bebidas" },
    { emoji: "☕", english: "Latte", spanish: "Café con Leche", category: "Bebidas" },
    { emoji: "🍵", english: "Black Tea", spanish: "Té Negro", category: "Bebidas" },
    { emoji: "🍵", english: "Herbal Tea", spanish: "Té de Hierbas", category: "Bebidas" },
    { emoji: "🥤", english: "Iced Coffee", spanish: "Café Helado", category: "Bebidas" },
    { emoji: "🧋", english: "Smoothie", spanish: "Batido", category: "Bebidas" },
    { emoji: "🥤", english: "Milkshake", spanish: "Malteada", category: "Bebidas" },
    { emoji: "🍹", english: "Mojito", spanish: "Mojito", category: "Bebidas" },
    { emoji: "🍸", english: "Martini", spanish: "Martini", category: "Bebidas" },
    { emoji: "🍷", english: "Red Wine", spanish: "Vino Tinto", category: "Bebidas" },
    { emoji: "🍷", english: "White Wine", spanish: "Vino Blanco", category: "Bebidas" },
    { emoji: "🥃", english: "Whiskey", spanish: "Whisky", category: "Bebidas" },
    { emoji: "🍺", english: "Ale", spanish: "Cerveza Ale", category: "Bebidas" },
    { emoji: "🍺", english: "Lager", spanish: "Cerveza Lager", category: "Bebidas" },
  ];

  const filteredFoods = foods.filter(
    (food) =>
      food.english.toLowerCase().includes(search.toLowerCase()) ||
      food.spanish.toLowerCase().includes(search.toLowerCase()) ||
      food.category.toLowerCase().includes(search.toLowerCase())
  );

  const categories = [...new Set(filteredFoods.map((f) => f.category))];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🍕 Comidas</h2>
        <p className="text-muted-foreground">Aprende vocabulario de comidas en inglés</p>
      </div>

      <div className="max-w-md mx-auto relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Buscar comidas..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      {categories.map((category) => {
        const categoryFoods = filteredFoods.filter((f) => f.category === category);
        return (
          <div key={category}>
            <h3 className="text-2xl font-bold text-foreground mb-4">{category}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {categoryFoods.map((food) => (
                <div key={food.english} className="learn-card flex items-center justify-between bg-coral">
                  <div className="flex items-center gap-3">
                    <span className="text-4xl">{food.emoji}</span>
                    <div>
                      <p className="font-bold text-foreground">{food.english}</p>
                      <p className="text-sm text-muted-foreground">{food.spanish}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => speak(food.english)}
                    className="pronunciation-btn"
                    aria-label={`Pronounce ${food.english}`}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      {filteredFoods.length === 0 && (
        <p className="text-center text-muted-foreground">No se encontraron comidas. Intenta con otra búsqueda.</p>
      )}
    </div>
  );
};
