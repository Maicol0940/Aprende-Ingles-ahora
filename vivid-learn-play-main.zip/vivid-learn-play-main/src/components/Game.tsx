import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Trophy, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { Input } from "./ui/input";

type GameType = "match" | "complete" | "arrange" | "trivia";

export const Game = () => {
  const [gameType, setGameType] = useState<GameType | null>(null);
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [currentPairs, setCurrentPairs] = useState<Array<{ english: string; spanish: string }>>([]);
  const [selectedEnglish, setSelectedEnglish] = useState<string | null>(null);
  const [selectedSpanish, setSelectedSpanish] = useState<string | null>(null);
  const [matchedPairs, setMatchedPairs] = useState<Set<string>>(new Set());
  const [shuffledEnglish, setShuffledEnglish] = useState<string[]>([]);
  const [shuffledSpanish, setShuffledSpanish] = useState<string[]>([]);
  
  // Complete sentence state
  const [currentSentence, setCurrentSentence] = useState<{ sentence: string; missing: string; answer: string } | null>(null);
  const [userAnswer, setUserAnswer] = useState("");
  
  // Arrange sentence state
  const [currentArrange, setCurrentArrange] = useState<{ words: string[]; correct: string } | null>(null);
  const [arrangedWords, setArrangedWords] = useState<string[]>([]);
  
  // Trivia state
  const [currentTrivia, setCurrentTrivia] = useState<{ question: string; options: string[]; correct: string } | null>(null);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const allPairs = [
    { english: "Hello", spanish: "Hola" },
    { english: "Goodbye", spanish: "Adiós" },
    { english: "Thank you", spanish: "Gracias" },
    { english: "Please", spanish: "Por favor" },
    { english: "Yes", spanish: "Sí" },
    { english: "No", spanish: "No" },
    { english: "Water", spanish: "Agua" },
    { english: "Food", spanish: "Comida" },
    { english: "House", spanish: "Casa" },
    { english: "Friend", spanish: "Amigo" },
    { english: "Family", spanish: "Familia" },
    { english: "Love", spanish: "Amor" },
    { english: "Time", spanish: "Tiempo" },
    { english: "Day", spanish: "Día" },
    { english: "Night", spanish: "Noche" },
    { english: "Good", spanish: "Bueno" },
    { english: "Bad", spanish: "Malo" },
    { english: "Big", spanish: "Grande" },
    { english: "Small", spanish: "Pequeño" },
    { english: "Happy", spanish: "Feliz" },
  ];

  const sentenceData = [
    { sentence: "I ___ to school every day", missing: "go", answer: "go" },
    { sentence: "She ___ a book right now", missing: "is reading", answer: "is reading" },
    { sentence: "They ___ playing soccer", missing: "are", answer: "are" },
    { sentence: "We ___ pizza yesterday", missing: "ate", answer: "ate" },
    { sentence: "He ___ very happy", missing: "is", answer: "is" },
    { sentence: "My name ___ John", missing: "is", answer: "is" },
    { sentence: "I ___ English", missing: "speak", answer: "speak" },
    { sentence: "She ___ her homework", missing: "does", answer: "does" },
    { sentence: "They ___ to the park", missing: "went", answer: "went" },
    { sentence: "I ___ a dog", missing: "have", answer: "have" },
    { sentence: "We ___ learning English", missing: "are", answer: "are" },
    { sentence: "He ___ coffee every morning", missing: "drinks", answer: "drinks" },
    { sentence: "She ___ in New York", missing: "lives", answer: "lives" },
    { sentence: "They ___ very tired", missing: "are", answer: "are" },
    { sentence: "I ___ to the cinema", missing: "want", answer: "want" },
  ];

  const arrangeData = [
    { words: ["am", "I", "happy"], correct: "I am happy" },
    { words: ["is", "She", "student", "a"], correct: "She is a student" },
    { words: ["like", "I", "pizza"], correct: "I like pizza" },
    { words: ["playing", "are", "They", "soccer"], correct: "They are playing soccer" },
    { words: ["to", "go", "school", "I"], correct: "I go to school" },
    { words: ["book", "reading", "is", "a", "He"], correct: "He is reading a book" },
    { words: ["have", "dog", "I", "a"], correct: "I have a dog" },
    { words: ["live", "We", "house", "a", "in"], correct: "We live in a house" },
    { words: ["eat", "They", "breakfast"], correct: "They eat breakfast" },
    { words: ["speaks", "English", "She"], correct: "She speaks English" },
    { words: ["work", "every", "I", "day"], correct: "I work every day" },
    { words: ["loves", "music", "He"], correct: "He loves music" },
    { words: ["study", "We", "together"], correct: "We study together" },
    { words: ["happy", "very", "am", "I"], correct: "I am very happy" },
    { words: ["coffee", "She", "drinks", "morning", "every"], correct: "She drinks coffee every morning" },
  ];

  const triviaData = [
    {
      question: "What is the capital of the United States?",
      options: ["New York", "Washington D.C.", "Los Angeles", "Chicago"],
      correct: "Washington D.C."
    },
    {
      question: "How many continents are there in the world?",
      options: ["5", "6", "7", "8"],
      correct: "7"
    },
    {
      question: "Which planet is known as the Red Planet?",
      options: ["Venus", "Mars", "Jupiter", "Saturn"],
      correct: "Mars"
    },
    {
      question: "What is the largest ocean on Earth?",
      options: ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"],
      correct: "Pacific Ocean"
    },
    {
      question: "Who painted the Mona Lisa?",
      options: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo"],
      correct: "Leonardo da Vinci"
    },
    {
      question: "What is the smallest country in the world?",
      options: ["Monaco", "Vatican City", "San Marino", "Liechtenstein"],
      correct: "Vatican City"
    },
    {
      question: "How many days are there in a leap year?",
      options: ["364", "365", "366", "367"],
      correct: "366"
    },
    {
      question: "What is the tallest mountain in the world?",
      options: ["K2", "Kangchenjunga", "Mount Everest", "Lhotse"],
      correct: "Mount Everest"
    },
    {
      question: "Which country is famous for the Eiffel Tower?",
      options: ["Italy", "Spain", "France", "Germany"],
      correct: "France"
    },
    {
      question: "What is the largest mammal in the world?",
      options: ["Elephant", "Blue Whale", "Giraffe", "Polar Bear"],
      correct: "Blue Whale"
    },
    {
      question: "How many colors are in a rainbow?",
      options: ["5", "6", "7", "8"],
      correct: "7"
    },
    {
      question: "What is the fastest land animal?",
      options: ["Lion", "Cheetah", "Leopard", "Tiger"],
      correct: "Cheetah"
    },
    {
      question: "Which language has the most native speakers?",
      options: ["English", "Spanish", "Mandarin Chinese", "Hindi"],
      correct: "Mandarin Chinese"
    },
    {
      question: "What year did World War II end?",
      options: ["1943", "1944", "1945", "1946"],
      correct: "1945"
    },
    {
      question: "How many bones are in the human body?",
      options: ["196", "206", "216", "226"],
      correct: "206"
    },
    {
      question: "What is the largest desert in the world?",
      options: ["Sahara", "Arabian", "Gobi", "Antarctic"],
      correct: "Antarctic"
    },
    {
      question: "Who wrote 'Romeo and Juliet'?",
      options: ["Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"],
      correct: "William Shakespeare"
    },
    {
      question: "What is the chemical symbol for gold?",
      options: ["Go", "Gd", "Au", "Ag"],
      correct: "Au"
    },
    {
      question: "How many strings does a standard guitar have?",
      options: ["4", "5", "6", "7"],
      correct: "6"
    },
    {
      question: "What is the longest river in the world?",
      options: ["Amazon", "Nile", "Yangtze", "Mississippi"],
      correct: "Nile"
    },
    {
      question: "Which country invented pizza?",
      options: ["Greece", "Italy", "Spain", "France"],
      correct: "Italy"
    },
    {
      question: "What is the capital of Japan?",
      options: ["Osaka", "Kyoto", "Tokyo", "Hiroshima"],
      correct: "Tokyo"
    },
    {
      question: "How many players are on a soccer team?",
      options: ["9", "10", "11", "12"],
      correct: "11"
    },
    {
      question: "What is the largest organ in the human body?",
      options: ["Heart", "Brain", "Liver", "Skin"],
      correct: "Skin"
    },
    {
      question: "Which planet is closest to the Sun?",
      options: ["Venus", "Earth", "Mercury", "Mars"],
      correct: "Mercury"
    },
    {
      question: "What is the main ingredient in bread?",
      options: ["Sugar", "Flour", "Salt", "Butter"],
      correct: "Flour"
    },
    {
      question: "How many sides does a hexagon have?",
      options: ["5", "6", "7", "8"],
      correct: "6"
    },
    {
      question: "What is the capital of Australia?",
      options: ["Sydney", "Melbourne", "Canberra", "Brisbane"],
      correct: "Canberra"
    },
    {
      question: "Which animal is known as the 'King of the Jungle'?",
      options: ["Tiger", "Lion", "Elephant", "Bear"],
      correct: "Lion"
    },
    {
      question: "What do bees produce?",
      options: ["Milk", "Honey", "Wax", "Silk"],
      correct: "Honey"
    },
  ];

  const shuffle = (array: string[]) => {
    return [...array].sort(() => Math.random() - 0.5);
  };

  const loadMatchLevel = (levelNum: number) => {
    const pairsCount = Math.min(4 + levelNum, 8);
    const pairs = allPairs.slice((levelNum - 1) * 4, (levelNum - 1) * 4 + pairsCount);
    setCurrentPairs(pairs);
    setShuffledEnglish(shuffle(pairs.map((p) => p.english)));
    setShuffledSpanish(shuffle(pairs.map((p) => p.spanish)));
    setMatchedPairs(new Set());
    setSelectedEnglish(null);
    setSelectedSpanish(null);
  };

  const loadCompleteSentence = () => {
    const randomSentence = sentenceData[Math.floor(Math.random() * sentenceData.length)];
    setCurrentSentence(randomSentence);
    setUserAnswer("");
  };

  const loadArrangeSentence = () => {
    const randomArrange = arrangeData[Math.floor(Math.random() * arrangeData.length)];
    setCurrentArrange(randomArrange);
    setArrangedWords([]);
  };

  const loadTrivia = () => {
    const randomTrivia = triviaData[Math.floor(Math.random() * triviaData.length)];
    setCurrentTrivia(randomTrivia);
    setSelectedOption(null);
  };

  useEffect(() => {
    if (gameType === "match") {
      loadMatchLevel(level);
    } else if (gameType === "complete") {
      loadCompleteSentence();
    } else if (gameType === "arrange") {
      loadArrangeSentence();
    } else if (gameType === "trivia") {
      loadTrivia();
    }
  }, [gameType, level]);

  useEffect(() => {
    if (selectedEnglish && selectedSpanish && gameType === "match") {
      const pair = currentPairs.find(
        (p) => p.english === selectedEnglish && p.spanish === selectedSpanish
      );

      if (pair) {
        setScore(score + 10);
        setMatchedPairs(new Set([...matchedPairs, pair.english]));
        toast.success("¡Correcto! 🎉");
        
        if (matchedPairs.size + 1 === currentPairs.length) {
          setTimeout(() => {
            if (level < 5) {
              toast.success(`¡Nivel ${level} completado! Avanzando al nivel ${level + 1}`);
              setLevel(level + 1);
            } else {
              toast.success("🏆 ¡Felicidades! ¡Completaste todos los niveles!");
            }
          }, 500);
        }
      } else {
        setScore(Math.max(0, score - 5));
        toast.error("¡Intenta de nuevo! ❌");
      }

      setSelectedEnglish(null);
      setSelectedSpanish(null);
    }
  }, [selectedEnglish, selectedSpanish]);

  const checkSentenceAnswer = () => {
    if (userAnswer.toLowerCase().trim() === currentSentence?.answer.toLowerCase()) {
      setScore(score + 15);
      toast.success("¡Correcto! 🎉");
      setTimeout(loadCompleteSentence, 1500);
    } else {
      setScore(Math.max(0, score - 5));
      toast.error("Incorrecto. Intenta de nuevo. ❌");
    }
  };

  const checkArrangedSentence = () => {
    const userSentence = arrangedWords.join(" ");
    if (userSentence === currentArrange?.correct) {
      setScore(score + 20);
      toast.success("¡Perfecto! 🎉");
      setTimeout(loadArrangeSentence, 1500);
    } else {
      setScore(Math.max(0, score - 5));
      toast.error("Orden incorrecto. Intenta de nuevo. ❌");
    }
  };

  const checkTriviaAnswer = (option: string) => {
    setSelectedOption(option);
    if (option === currentTrivia?.correct) {
      setScore(score + 10);
      toast.success("¡Respuesta correcta! 🎉");
      setTimeout(loadTrivia, 1500);
    } else {
      setScore(Math.max(0, score - 5));
      toast.error(`Incorrecto. La respuesta correcta es: ${currentTrivia?.correct}`);
      setTimeout(loadTrivia, 2500);
    }
  };

  const resetGame = () => {
    setLevel(1);
    setScore(0);
    setGameType(null);
  };

  if (!gameType) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-foreground mb-2">🎮 Juegos Educativos</h2>
          <p className="text-muted-foreground">Elige un juego para practicar tu inglés</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          <button
            onClick={() => setGameType("match")}
            className="learn-card flex flex-col items-center justify-center gap-4 py-12 bg-gradient-to-br from-primary to-primary/70 text-white hover:scale-105"
          >
            <span className="text-6xl">🔗</span>
            <h3 className="text-2xl font-bold">Unir Palabras</h3>
            <p className="text-sm text-white/90">Conecta palabras en inglés con español</p>
          </button>

          <button
            onClick={() => setGameType("complete")}
            className="learn-card flex flex-col items-center justify-center gap-4 py-12 bg-gradient-to-br from-secondary to-secondary/70 text-white hover:scale-105"
          >
            <span className="text-6xl">✍️</span>
            <h3 className="text-2xl font-bold">Completar Oraciones</h3>
            <p className="text-sm text-white/90">Completa la palabra faltante</p>
          </button>

          <button
            onClick={() => setGameType("arrange")}
            className="learn-card flex flex-col items-center justify-center gap-4 py-12 bg-gradient-to-br from-accent to-accent/70 text-white hover:scale-105"
          >
            <span className="text-6xl">🔤</span>
            <h3 className="text-2xl font-bold">Armar Oraciones</h3>
            <p className="text-sm text-white/90">Ordena las palabras correctamente</p>
          </button>

          <button
            onClick={() => setGameType("trivia")}
            className="learn-card flex flex-col items-center justify-center gap-4 py-12 bg-gradient-to-br from-coral to-coral/70 text-white hover:scale-105"
          >
            <span className="text-6xl">🧠</span>
            <h3 className="text-2xl font-bold">Cultura General</h3>
            <p className="text-sm text-white/90">Preguntas de conocimiento general</p>
          </button>
        </div>
      </div>
    );
  }

  if (gameType === "complete" && currentSentence) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-foreground mb-2">✍️ Completar Oraciones</h2>
          <p className="text-muted-foreground">Escribe la palabra que falta</p>
        </div>

        <div className="flex items-center justify-center gap-8 flex-wrap">
          <div className="section-badge bg-success text-success-foreground">
            <span className="text-2xl">🏆</span>
            <span>Puntos: {score}</span>
          </div>
          <Button onClick={resetGame} variant="outline" className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Cambiar Juego
          </Button>
        </div>

        <div className="max-w-2xl mx-auto space-y-6">
          <div className="learn-card p-8">
            <p className="text-2xl font-semibold text-center mb-6">
              {currentSentence.sentence.replace("___", "_____")}
            </p>
            <div className="space-y-4">
              <Input
                type="text"
                placeholder="Escribe tu respuesta aquí..."
                value={userAnswer}
                onChange={(e) => setUserAnswer(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && checkSentenceAnswer()}
                className="text-lg text-center"
              />
              <Button onClick={checkSentenceAnswer} className="w-full" size="lg">
                Verificar Respuesta
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (gameType === "arrange" && currentArrange) {
    const availableWords = currentArrange.words.filter(w => !arrangedWords.includes(w));
    
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-foreground mb-2">🔤 Armar Oraciones</h2>
          <p className="text-muted-foreground">Ordena las palabras para formar una oración correcta</p>
        </div>

        <div className="flex items-center justify-center gap-8 flex-wrap">
          <div className="section-badge bg-success text-success-foreground">
            <span className="text-2xl">🏆</span>
            <span>Puntos: {score}</span>
          </div>
          <Button onClick={resetGame} variant="outline" className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Cambiar Juego
          </Button>
        </div>

        <div className="max-w-3xl mx-auto space-y-6">
          <div className="learn-card p-6">
            <h3 className="text-lg font-semibold mb-4 text-center">Tu oración:</h3>
            <div className="min-h-[60px] border-2 border-dashed border-primary/30 rounded-lg p-4 flex flex-wrap gap-2 items-center justify-center bg-muted/20">
              {arrangedWords.length === 0 ? (
                <span className="text-muted-foreground">Selecciona las palabras en orden...</span>
              ) : (
                arrangedWords.map((word, index) => (
                  <button
                    key={index}
                    onClick={() => setArrangedWords(arrangedWords.filter((_, i) => i !== index))}
                    className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/80 transition-colors"
                  >
                    {word}
                  </button>
                ))
              )}
            </div>
          </div>

          <div className="learn-card p-6">
            <h3 className="text-lg font-semibold mb-4 text-center">Palabras disponibles:</h3>
            <div className="flex flex-wrap gap-3 justify-center">
              {availableWords.map((word, index) => (
                <button
                  key={index}
                  onClick={() => setArrangedWords([...arrangedWords, word])}
                  className="px-4 py-2 bg-secondary text-secondary-foreground rounded-lg font-semibold hover:bg-secondary/80 transition-colors"
                >
                  {word}
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-4">
            <Button 
              onClick={checkArrangedSentence} 
              className="flex-1" 
              size="lg"
              disabled={arrangedWords.length !== currentArrange.words.length}
            >
              Verificar Oración
            </Button>
            <Button 
              onClick={() => setArrangedWords([])} 
              variant="outline" 
              size="lg"
            >
              Reiniciar
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (gameType === "trivia" && currentTrivia) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-foreground mb-2">🧠 Cultura General</h2>
          <p className="text-muted-foreground">Responde preguntas de conocimiento general en inglés</p>
        </div>

        <div className="flex items-center justify-center gap-8 flex-wrap">
          <div className="section-badge bg-success text-success-foreground">
            <span className="text-2xl">🏆</span>
            <span>Puntos: {score}</span>
          </div>
          <Button onClick={resetGame} variant="outline" className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Cambiar Juego
          </Button>
        </div>

        <div className="max-w-2xl mx-auto">
          <div className="learn-card p-8 space-y-6">
            <p className="text-2xl font-semibold text-center">{currentTrivia.question}</p>
            <div className="grid grid-cols-1 gap-4">
              {currentTrivia.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => !selectedOption && checkTriviaAnswer(option)}
                  disabled={!!selectedOption}
                  className={`p-4 rounded-lg font-semibold text-lg transition-all ${
                    selectedOption === option
                      ? option === currentTrivia.correct
                        ? "bg-success text-success-foreground"
                        : "bg-destructive text-destructive-foreground"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  } ${selectedOption ? "cursor-not-allowed" : "hover:scale-105"}`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Match game (original)
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🔗 Unir Palabras</h2>
        <p className="text-muted-foreground">Conecta las palabras en inglés con su traducción en español</p>
      </div>

      <div className="flex items-center justify-center gap-8 flex-wrap">
        <div className="section-badge bg-primary text-primary-foreground">
          <Trophy className="w-5 h-5" />
          <span>Nivel: {level}/5</span>
        </div>
        <div className="section-badge bg-success text-success-foreground">
          <span className="text-2xl">🏆</span>
          <span>Puntos: {score}</span>
        </div>
        <Button onClick={resetGame} variant="outline" className="gap-2">
          <RefreshCw className="w-4 h-4" />
          Cambiar Juego
        </Button>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        <div className="space-y-3">
          <h3 className="text-xl font-bold text-center text-foreground">Inglés</h3>
          {shuffledEnglish.map((word) => (
            <button
              key={word}
              onClick={() => !matchedPairs.has(word) && setSelectedEnglish(word)}
              disabled={matchedPairs.has(word)}
              className={`game-card w-full ${
                selectedEnglish === word ? "selected" : ""
              } ${matchedPairs.has(word) ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <p className="text-lg font-semibold text-center">{word}</p>
            </button>
          ))}
        </div>

        <div className="space-y-3">
          <h3 className="text-xl font-bold text-center text-foreground">Español</h3>
          {shuffledSpanish.map((word) => {
            const matchedEnglish = currentPairs.find((p) => p.spanish === word)?.english;
            const isMatched = matchedEnglish && matchedPairs.has(matchedEnglish);
            
            return (
              <button
                key={word}
                onClick={() => !isMatched && setSelectedSpanish(word)}
                disabled={!!isMatched}
                className={`game-card w-full ${
                  selectedSpanish === word ? "selected" : ""
                } ${isMatched ? "opacity-50 cursor-not-allowed" : ""}`}
              >
                <p className="text-lg font-semibold text-center">{word}</p>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
