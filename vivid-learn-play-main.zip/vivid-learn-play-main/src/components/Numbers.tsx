import { Volume2, Search } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { useState } from "react";

export const Numbers = () => {
  const { speak } = useSpeech();
  const [searchNumber, setSearchNumber] = useState("");
  const [customNumber, setCustomNumber] = useState<number | null>(null);

  const numberToWords = (num: number): string => {
    if (num === 0) return "zero";
    
    const ones = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"];
    const teens = ["ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"];
    const tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];
    
    const convertHundreds = (n: number): string => {
      if (n === 0) return "";
      if (n < 10) return ones[n];
      if (n < 20) return teens[n - 10];
      if (n < 100) {
        const ten = Math.floor(n / 10);
        const one = n % 10;
        return tens[ten] + (one !== 0 ? "-" + ones[one] : "");
      }
      const hundred = Math.floor(n / 100);
      const remainder = n % 100;
      return ones[hundred] + " hundred" + (remainder !== 0 ? " " + convertHundreds(remainder) : "");
    };
    
    if (num < 1000) {
      return convertHundreds(num);
    }
    
    if (num < 1000000) {
      const thousands = Math.floor(num / 1000);
      const remainder = num % 1000;
      return convertHundreds(thousands) + " thousand" + (remainder !== 0 ? " " + convertHundreds(remainder) : "");
    }
    
    if (num < 1000000000) {
      const millions = Math.floor(num / 1000000);
      const remainder = num % 1000000;
      let result = convertHundreds(millions) + " million";
      if (remainder >= 1000) {
        const thousands = Math.floor(remainder / 1000);
        const lastPart = remainder % 1000;
        result += " " + convertHundreds(thousands) + " thousand";
        if (lastPart !== 0) result += " " + convertHundreds(lastPart);
      } else if (remainder !== 0) {
        result += " " + convertHundreds(remainder);
      }
      return result;
    }
    
    if (num < 1000000000000) {
      const billions = Math.floor(num / 1000000000);
      const remainder = num % 1000000000;
      let result = convertHundreds(billions) + " billion";
      if (remainder >= 1000000) {
        const millions = Math.floor(remainder / 1000000);
        const lastPart = remainder % 1000000;
        result += " " + convertHundreds(millions) + " million";
        if (lastPart >= 1000) {
          const thousands = Math.floor(lastPart / 1000);
          const finalPart = lastPart % 1000;
          result += " " + convertHundreds(thousands) + " thousand";
          if (finalPart !== 0) result += " " + convertHundreds(finalPart);
        } else if (lastPart !== 0) {
          result += " " + convertHundreds(lastPart);
        }
      } else if (remainder >= 1000) {
        const thousands = Math.floor(remainder / 1000);
        const lastPart = remainder % 1000;
        result += " " + convertHundreds(thousands) + " thousand";
        if (lastPart !== 0) result += " " + convertHundreds(lastPart);
      } else if (remainder !== 0) {
        result += " " + convertHundreds(remainder);
      }
      return result;
    }
    
    return "Number too large";
  };

  const handleSearch = () => {
    const num = parseInt(searchNumber);
    if (!isNaN(num) && num >= 0) {
      setCustomNumber(num);
    }
  };

  const commonNumbers = [
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
    11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 30, 35, 40, 45, 50,
    55, 60, 65, 70, 75, 80, 85, 90, 95, 100,
    200, 250, 300, 400, 500, 600, 700, 800, 900, 1000,
    1500, 2000, 2500, 3000, 5000, 10000, 15000, 20000, 50000, 100000,
    500000, 1000000
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🔢 Números en Inglés</h2>
        <p className="text-muted-foreground">Aprende cómo decir cualquier número en inglés</p>
      </div>

      <div className="max-w-md mx-auto space-y-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="number"
              placeholder="Ingresa cualquier número..."
              value={searchNumber}
              onChange={(e) => setSearchNumber(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              min="0"
              className="pl-10"
            />
          </div>
          <Button onClick={handleSearch} className="bg-primary">
            Buscar
          </Button>
        </div>

        {customNumber !== null && (
          <div className="learn-card bg-primary text-center">
            <p className="text-5xl font-bold mb-2 text-white">{customNumber}</p>
            <p className="text-2xl mb-4 capitalize text-foreground">{numberToWords(customNumber)}</p>
            <button
              onClick={() => speak(numberToWords(customNumber))}
              className="pronunciation-btn bg-white text-primary mx-auto"
              aria-label={`Pronounce ${customNumber}`}
            >
              <Volume2 className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>

      <div>
        <h3 className="text-2xl font-bold text-foreground mb-4 text-center">Números Comunes</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {commonNumbers.map((num) => (
            <div
              key={num}
              className="learn-card flex flex-col items-center justify-center gap-2 py-6 bg-gradient-to-br from-primary to-primary/70 text-primary-foreground"
            >
              <span className="text-4xl font-bold">{num}</span>
              <span className="text-sm capitalize">{numberToWords(num)}</span>
              <button
                onClick={() => speak(numberToWords(num))}
                className="pronunciation-btn bg-white text-primary"
                aria-label={`Pronounce ${num}`}
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
