import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const DaysMonths = () => {
  const { speak } = useSpeech();

  const daysOfWeek = [
    { english: "Monday", spanish: "Lunes", abbreviation: "Mon" },
    { english: "Tuesday", spanish: "Martes", abbreviation: "Tue" },
    { english: "Wednesday", spanish: "Miércoles", abbreviation: "Wed" },
    { english: "Thursday", spanish: "Jueves", abbreviation: "Thu" },
    { english: "Friday", spanish: "Viernes", abbreviation: "Fri" },
    { english: "Saturday", spanish: "Sábado", abbreviation: "Sat" },
    { english: "Sunday", spanish: "Domingo", abbreviation: "Sun" },
  ];

  const months = [
    { english: "January", spanish: "Enero", abbreviation: "Jan", days: 31 },
    { english: "February", spanish: "Febrero", abbreviation: "Feb", days: 28 },
    { english: "March", spanish: "Marzo", abbreviation: "Mar", days: 31 },
    { english: "April", spanish: "Abril", abbreviation: "Apr", days: 30 },
    { english: "May", spanish: "Mayo", abbreviation: "May", days: 31 },
    { english: "June", spanish: "Junio", abbreviation: "Jun", days: 30 },
    { english: "July", spanish: "Julio", abbreviation: "Jul", days: 31 },
    { english: "August", spanish: "Agosto", abbreviation: "Aug", days: 31 },
    { english: "September", spanish: "Septiembre", abbreviation: "Sep", days: 30 },
    { english: "October", spanish: "Octubre", abbreviation: "Oct", days: 31 },
    { english: "November", spanish: "Noviembre", abbreviation: "Nov", days: 30 },
    { english: "December", spanish: "Diciembre", abbreviation: "Dec", days: 31 },
  ];

  const seasons = [
    { english: "Spring", spanish: "Primavera", emoji: "🌸", months: "March - May" },
    { english: "Summer", spanish: "Verano", emoji: "☀️", months: "June - August" },
    { english: "Autumn/Fall", spanish: "Otoño", emoji: "🍂", months: "September - November" },
    { english: "Winter", spanish: "Invierno", emoji: "❄️", months: "December - February" },
  ];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">📅 Days & Months</h2>
        <p className="text-muted-foreground">Aprende los días y meses en inglés</p>
      </div>

      {/* Days of the Week */}
      <div className="space-y-4">
        <h3 className="text-2xl font-bold text-primary text-center">Days of the Week</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-4">
          {daysOfWeek.map((day, index) => (
            <div
              key={day.english}
              className="learn-card bg-gradient-to-br from-primary to-primary/70 p-6 text-center space-y-2"
            >
              <div className="text-4xl font-bold text-white">{index + 1}</div>
              <h4 className="text-xl font-bold text-white">{day.english}</h4>
              <p className="text-sm text-white/80">{day.abbreviation}</p>
              <p className="text-sm text-white/90 italic">{day.spanish}</p>
              <button
                onClick={() => speak(day.english)}
                className="pronunciation-btn mx-auto bg-white text-primary"
                aria-label={`Pronounce ${day.english}`}
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Months */}
      <div className="space-y-4">
        <h3 className="text-2xl font-bold text-primary text-center">Months of the Year</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {months.map((month, index) => (
            <div
              key={month.english}
              className="learn-card bg-gradient-to-br from-secondary to-secondary/70 p-6 text-center space-y-2"
            >
              <div className="text-3xl font-bold text-white">{index + 1}</div>
              <h4 className="text-lg font-bold text-white">{month.english}</h4>
              <p className="text-xs text-white/80">{month.abbreviation}</p>
              <p className="text-xs text-white/90 italic">{month.spanish}</p>
              <p className="text-xs text-white/70">{month.days} days</p>
              <button
                onClick={() => speak(month.english)}
                className="pronunciation-btn mx-auto bg-white text-secondary"
                aria-label={`Pronounce ${month.english}`}
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Seasons */}
      <div className="space-y-4">
        <h3 className="text-2xl font-bold text-primary text-center">Seasons</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {seasons.map((season) => (
            <div
              key={season.english}
              className="learn-card bg-gradient-to-br from-accent to-accent/70 p-8 text-center space-y-3"
            >
              <div className="text-6xl">{season.emoji}</div>
              <h4 className="text-xl font-bold text-white">{season.english}</h4>
              <p className="text-sm text-white/90 italic">{season.spanish}</p>
              <p className="text-xs text-white/70">{season.months}</p>
              <button
                onClick={() => speak(season.english)}
                className="pronunciation-btn mx-auto bg-white text-accent"
                aria-label={`Pronounce ${season.english}`}
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
