import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const Places = () => {
  const { speak } = useSpeech();

  const places = [
    // Public Places
    { english: "Hospital", spanish: "Hospital", emoji: "🏥", category: "Lugares Públicos" },
    { english: "School", spanish: "Escuela", emoji: "🏫", category: "Lugares Públicos" },
    { english: "University", spanish: "Universidad", emoji: "🎓", category: "Lugares Públicos" },
    { english: "Library", spanish: "Biblioteca", emoji: "📚", category: "Lugares Públicos" },
    { english: "Museum", spanish: "Museo", emoji: "🏛️", category: "Lugares Públicos" },
    { english: "Church", spanish: "Iglesia", emoji: "⛪", category: "Lugares Públicos" },
    { english: "Mosque", spanish: "Mezquita", emoji: "🕌", category: "Lugares Públicos" },
    { english: "Temple", spanish: "Templo", emoji: "🛕", category: "Lugares Públicos" },
    { english: "Synagogue", spanish: "Sinagoga", emoji: "🕍", category: "Lugares Públicos" },
    { english: "Police station", spanish: "Estación de policía", emoji: "🚓", category: "Lugares Públicos" },
    { english: "Fire station", spanish: "Estación de bomberos", emoji: "🚒", category: "Lugares Públicos" },
    { english: "Post office", spanish: "Oficina de correos", emoji: "📮", category: "Lugares Públicos" },
    { english: "City hall", spanish: "Ayuntamiento", emoji: "🏛️", category: "Lugares Públicos" },
    { english: "Court", spanish: "Tribunal", emoji: "⚖️", category: "Lugares Públicos" },
    { english: "Embassy", spanish: "Embajada", emoji: "🏛️", category: "Lugares Públicos" },
    { english: "Town square", spanish: "Plaza del pueblo", emoji: "🏛️", category: "Lugares Públicos" },

    // Shopping
    { english: "Store", spanish: "Tienda", emoji: "🏪", category: "Compras" },
    { english: "Shop", spanish: "Tienda", emoji: "🛍️", category: "Compras" },
    { english: "Supermarket", spanish: "Supermercado", emoji: "🏬", category: "Compras" },
    { english: "Mall", spanish: "Centro comercial", emoji: "🏬", category: "Compras" },
    { english: "Shopping center", spanish: "Centro de compras", emoji: "🏬", category: "Compras" },
    { english: "Market", spanish: "Mercado", emoji: "🏪", category: "Compras" },
    { english: "Bakery", spanish: "Panadería", emoji: "🥖", category: "Compras" },
    { english: "Butcher shop", spanish: "Carnicería", emoji: "🥩", category: "Compras" },
    { english: "Pharmacy", spanish: "Farmacia", emoji: "💊", category: "Compras" },
    { english: "Bookstore", spanish: "Librería", emoji: "📚", category: "Compras" },
    { english: "Flower shop", spanish: "Floristería", emoji: "💐", category: "Compras" },
    { english: "Jewelry store", spanish: "Joyería", emoji: "💎", category: "Compras" },
    { english: "Clothing store", spanish: "Tienda de ropa", emoji: "👕", category: "Compras" },
    { english: "Shoe store", spanish: "Zapatería", emoji: "👟", category: "Compras" },
    { english: "Electronics store", spanish: "Tienda de electrónica", emoji: "📱", category: "Compras" },
    { english: "Hardware store", spanish: "Ferretería", emoji: "🔨", category: "Compras" },
    { english: "Pet shop", spanish: "Tienda de mascotas", emoji: "🐕", category: "Compras" },
    { english: "Toy store", spanish: "Juguetería", emoji: "🧸", category: "Compras" },
    { english: "Convenience store", spanish: "Tienda de conveniencia", emoji: "🏪", category: "Compras" },

    // Food & Drink
    { english: "Restaurant", spanish: "Restaurante", emoji: "🍽️", category: "Comida y Bebida" },
    { english: "Café", spanish: "Cafetería", emoji: "☕", category: "Comida y Bebida" },
    { english: "Coffee shop", spanish: "Cafetería", emoji: "☕", category: "Comida y Bebida" },
    { english: "Bar", spanish: "Bar", emoji: "🍺", category: "Comida y Bebida" },
    { english: "Pub", spanish: "Pub", emoji: "🍻", category: "Comida y Bebida" },
    { english: "Fast food restaurant", spanish: "Restaurante de comida rápida", emoji: "🍔", category: "Comida y Bebida" },
    { english: "Pizza place", spanish: "Pizzería", emoji: "🍕", category: "Comida y Bebida" },
    { english: "Ice cream shop", spanish: "Heladería", emoji: "🍦", category: "Comida y Bebida" },
    { english: "Diner", spanish: "Restaurante informal", emoji: "🍽️", category: "Comida y Bebida" },
    { english: "Food court", spanish: "Patio de comidas", emoji: "🍱", category: "Comida y Bebida" },
    { english: "Buffet", spanish: "Bufé", emoji: "🍱", category: "Comida y Bebida" },
    { english: "Bistro", spanish: "Bistró", emoji: "🍽️", category: "Comida y Bebida" },

    // Transportation
    { english: "Airport", spanish: "Aeropuerto", emoji: "✈️", category: "Transporte" },
    { english: "Train station", spanish: "Estación de tren", emoji: "🚉", category: "Transporte" },
    { english: "Bus station", spanish: "Estación de autobuses", emoji: "🚌", category: "Transporte" },
    { english: "Subway station", spanish: "Estación de metro", emoji: "🚇", category: "Transporte" },
    { english: "Taxi stand", spanish: "Parada de taxis", emoji: "🚕", category: "Transporte" },
    { english: "Bus stop", spanish: "Parada de autobús", emoji: "🚏", category: "Transporte" },
    { english: "Parking lot", spanish: "Estacionamiento", emoji: "🅿️", category: "Transporte" },
    { english: "Garage", spanish: "Garaje", emoji: "🏠", category: "Transporte" },
    { english: "Gas station", spanish: "Gasolinera", emoji: "⛽", category: "Transporte" },
    { english: "Port", spanish: "Puerto", emoji: "⚓", category: "Transporte" },
    { english: "Harbor", spanish: "Puerto", emoji: "⛵", category: "Transporte" },

    // Entertainment
    { english: "Cinema", spanish: "Cine", emoji: "🎬", category: "Entretenimiento" },
    { english: "Movie theater", spanish: "Cine", emoji: "🎥", category: "Entretenimiento" },
    { english: "Theater", spanish: "Teatro", emoji: "🎭", category: "Entretenimiento" },
    { english: "Concert hall", spanish: "Sala de conciertos", emoji: "🎵", category: "Entretenimiento" },
    { english: "Stadium", spanish: "Estadio", emoji: "🏟️", category: "Entretenimiento" },
    { english: "Arena", spanish: "Arena", emoji: "🏟️", category: "Entretenimiento" },
    { english: "Amusement park", spanish: "Parque de diversiones", emoji: "🎡", category: "Entretenimiento" },
    { english: "Zoo", spanish: "Zoológico", emoji: "🦁", category: "Entretenimiento" },
    { english: "Aquarium", spanish: "Acuario", emoji: "🐠", category: "Entretenimiento" },
    { english: "Circus", spanish: "Circo", emoji: "🎪", category: "Entretenimiento" },
    { english: "Casino", spanish: "Casino", emoji: "🎰", category: "Entretenimiento" },
    { english: "Nightclub", spanish: "Discoteca", emoji: "💃", category: "Entretenimiento" },
    { english: "Bowling alley", spanish: "Bolera", emoji: "🎳", category: "Entretenimiento" },
    { english: "Arcade", spanish: "Sala de juegos", emoji: "🎮", category: "Entretenimiento" },

    // Sports & Recreation
    { english: "Gym", spanish: "Gimnasio", emoji: "💪", category: "Deportes y Recreación" },
    { english: "Fitness center", spanish: "Centro de fitness", emoji: "🏋️", category: "Deportes y Recreación" },
    { english: "Swimming pool", spanish: "Piscina", emoji: "🏊", category: "Deportes y Recreación" },
    { english: "Sports center", spanish: "Centro deportivo", emoji: "⚽", category: "Deportes y Recreación" },
    { english: "Tennis court", spanish: "Cancha de tenis", emoji: "🎾", category: "Deportes y Recreación" },
    { english: "Basketball court", spanish: "Cancha de baloncesto", emoji: "🏀", category: "Deportes y Recreación" },
    { english: "Soccer field", spanish: "Campo de fútbol", emoji: "⚽", category: "Deportes y Recreación" },
    { english: "Baseball field", spanish: "Campo de béisbol", emoji: "⚾", category: "Deportes y Recreación" },
    { english: "Golf course", spanish: "Campo de golf", emoji: "⛳", category: "Deportes y Recreación" },
    { english: "Skate park", spanish: "Parque de patinaje", emoji: "🛹", category: "Deportes y Recreación" },
    { english: "Playground", spanish: "Parque infantil", emoji: "🎠", category: "Deportes y Recreación" },
    { english: "Park", spanish: "Parque", emoji: "🌳", category: "Deportes y Recreación" },

    // Accommodation
    { english: "Hotel", spanish: "Hotel", emoji: "🏨", category: "Alojamiento" },
    { english: "Motel", spanish: "Motel", emoji: "🏨", category: "Alojamiento" },
    { english: "Hostel", spanish: "Albergue", emoji: "🏨", category: "Alojamiento" },
    { english: "Inn", spanish: "Posada", emoji: "🏨", category: "Alojamiento" },
    { english: "Resort", spanish: "Resort", emoji: "🏖️", category: "Alojamiento" },
    { english: "Bed and breakfast", spanish: "Casa de huéspedes", emoji: "🏠", category: "Alojamiento" },
    { english: "Campground", spanish: "Camping", emoji: "🏕️", category: "Alojamiento" },

    // Financial
    { english: "Bank", spanish: "Banco", emoji: "🏦", category: "Finanzas" },
    { english: "ATM", spanish: "Cajero automático", emoji: "🏧", category: "Finanzas" },
    { english: "Currency exchange", spanish: "Casa de cambio", emoji: "💱", category: "Finanzas" },
    { english: "Stock exchange", spanish: "Bolsa de valores", emoji: "📈", category: "Finanzas" },

    // Health & Beauty
    { english: "Clinic", spanish: "Clínica", emoji: "🏥", category: "Salud y Belleza" },
    { english: "Dental clinic", spanish: "Clínica dental", emoji: "🦷", category: "Salud y Belleza" },
    { english: "Veterinary clinic", spanish: "Clínica veterinaria", emoji: "🐕", category: "Salud y Belleza" },
    { english: "Spa", spanish: "Spa", emoji: "💆", category: "Salud y Belleza" },
    { english: "Salon", spanish: "Salón", emoji: "💇", category: "Salud y Belleza" },
    { english: "Barbershop", spanish: "Barbería", emoji: "💈", category: "Salud y Belleza" },
    { english: "Nail salon", spanish: "Salón de uñas", emoji: "💅", category: "Salud y Belleza" },

    // Other
    { english: "Office", spanish: "Oficina", emoji: "🏢", category: "Otros" },
    { english: "Office building", spanish: "Edificio de oficinas", emoji: "🏢", category: "Otros" },
    { english: "Factory", spanish: "Fábrica", emoji: "🏭", category: "Otros" },
    { english: "Warehouse", spanish: "Almacén", emoji: "🏭", category: "Otros" },
    { english: "Construction site", spanish: "Obra en construcción", emoji: "🏗️", category: "Otros" },
    { english: "Laundromat", spanish: "Lavandería", emoji: "🧺", category: "Otros" },
    { english: "Dry cleaner", spanish: "Tintorería", emoji: "👔", category: "Otros" },
    { english: "Tailor shop", spanish: "Sastrería", emoji: "🧵", category: "Otros" },
    { english: "Recycling center", spanish: "Centro de reciclaje", emoji: "♻️", category: "Otros" },
    { english: "Landfill", spanish: "Vertedero", emoji: "🗑️", category: "Otros" },
  ];

  const groupedPlaces = places.reduce((acc, place) => {
    if (!acc[place.category]) {
      acc[place.category] = [];
    }
    acc[place.category].push(place);
    return acc;
  }, {} as Record<string, typeof places>);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">🏙️ Places in the City</h2>
        <p className="text-muted-foreground">Aprende los nombres de lugares en la ciudad en inglés</p>
      </div>

      {Object.entries(groupedPlaces).map(([category, items]) => (
        <div key={category}>
          <h3 className="text-2xl font-bold text-primary mb-4">{category}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {items.map((place) => (
              <div
                key={place.english}
                className="learn-card bg-gradient-to-br from-success to-success/70 flex items-center justify-between p-4"
              >
                <div className="flex items-center gap-3">
                  <span className="text-4xl">{place.emoji}</span>
                  <div>
                    <p className="font-bold text-white text-lg">{place.english}</p>
                    <p className="text-sm text-white/80">{place.spanish}</p>
                  </div>
                </div>
                <button
                  onClick={() => speak(place.english)}
                  className="pronunciation-btn bg-white text-success"
                  aria-label={`Pronounce ${place.english}`}
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};
