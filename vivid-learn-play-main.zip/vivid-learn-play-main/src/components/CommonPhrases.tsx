import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const CommonPhrases = () => {
  const { speak } = useSpeech();

  const phraseCategories = {
    greetings: {
      title: "Greetings",
      spanish: "Saludos",
      emoji: "👋",
      phrases: [
        { english: "Hello", spanish: "Hola" },
        { english: "Good morning", spanish: "Buenos días" },
        { english: "Good afternoon", spanish: "Buenas tardes" },
        { english: "Good evening", spanish: "Buenas noches" },
        { english: "How are you?", spanish: "¿Cómo estás?" },
        { english: "Nice to meet you", spanish: "Mucho gusto" },
        { english: "What's up?", spanish: "¿Qué tal?" },
        { english: "Long time no see", spanish: "Cuánto tiempo sin verte" },
      ],
    },
    farewell: {
      title: "Farewell",
      spanish: "Despedidas",
      emoji: "👋",
      phrases: [
        { english: "Goodbye", spanish: "Adiós" },
        { english: "See you later", spanish: "Hasta luego" },
        { english: "See you soon", spanish: "Hasta pronto" },
        { english: "See you tomorrow", spanish: "Hasta mañana" },
        { english: "Take care", spanish: "Cuídate" },
        { english: "Have a nice day", spanish: "Que tengas un buen día" },
        { english: "Good night", spanish: "Buenas noches" },
        { english: "Catch you later", spanish: "Nos vemos" },
      ],
    },
    courtesy: {
      title: "Courtesy",
      spanish: "Cortesía",
      emoji: "🙏",
      phrases: [
        { english: "Please", spanish: "Por favor" },
        { english: "Thank you", spanish: "Gracias" },
        { english: "You're welcome", spanish: "De nada" },
        { english: "Excuse me", spanish: "Disculpe" },
        { english: "I'm sorry", spanish: "Lo siento" },
        { english: "Pardon me", spanish: "Perdón" },
        { english: "No problem", spanish: "No hay problema" },
        { english: "My pleasure", spanish: "Es un placer" },
      ],
    },
    questions: {
      title: "Common Questions",
      spanish: "Preguntas Comunes",
      emoji: "❓",
      phrases: [
        { english: "What's your name?", spanish: "¿Cómo te llamas?" },
        { english: "Where are you from?", spanish: "¿De dónde eres?" },
        { english: "How old are you?", spanish: "¿Cuántos años tienes?" },
        { english: "What time is it?", spanish: "¿Qué hora es?" },
        { english: "Where is the bathroom?", spanish: "¿Dónde está el baño?" },
        { english: "How much does it cost?", spanish: "¿Cuánto cuesta?" },
        { english: "Do you speak English?", spanish: "¿Hablas inglés?" },
        { english: "Can you help me?", spanish: "¿Puedes ayudarme?" },
      ],
    },
    responses: {
      title: "Common Responses",
      spanish: "Respuestas Comunes",
      emoji: "💬",
      phrases: [
        { english: "Yes", spanish: "Sí" },
        { english: "No", spanish: "No" },
        { english: "Maybe", spanish: "Quizás" },
        { english: "I don't know", spanish: "No sé" },
        { english: "I understand", spanish: "Entiendo" },
        { english: "I don't understand", spanish: "No entiendo" },
        { english: "I agree", spanish: "Estoy de acuerdo" },
        { english: "I disagree", spanish: "No estoy de acuerdo" },
      ],
    },
    emergency: {
      title: "Emergency Phrases",
      spanish: "Frases de Emergencia",
      emoji: "🚨",
      phrases: [
        { english: "Help!", spanish: "¡Ayuda!" },
        { english: "Call the police", spanish: "Llama a la policía" },
        { english: "I need a doctor", spanish: "Necesito un doctor" },
        { english: "It's an emergency", spanish: "Es una emergencia" },
        { english: "I'm lost", spanish: "Estoy perdido" },
        { english: "Fire!", spanish: "¡Fuego!" },
        { english: "Stop!", spanish: "¡Alto!" },
        { english: "Call an ambulance", spanish: "Llama una ambulancia" },
      ],
    },
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">💭 Common Phrases</h2>
        <p className="text-muted-foreground">Aprende frases comunes en inglés</p>
      </div>

      <div className="space-y-8">
        {Object.entries(phraseCategories).map(([key, category]) => (
          <div key={key} className="space-y-4">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-primary inline-flex items-center gap-2">
                <span>{category.emoji}</span>
                <span>{category.title}</span>
              </h3>
              <p className="text-muted-foreground italic">{category.spanish}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {category.phrases.map((phrase, index) => (
                <div
                  key={index}
                  className="learn-card bg-gradient-to-br from-primary to-primary/70 p-4 flex items-center gap-4"
                >
                  <button
                    onClick={() => speak(phrase.english)}
                    className="pronunciation-btn shrink-0 bg-white text-primary"
                    aria-label={`Pronounce ${phrase.english}`}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                  <div className="flex-1">
                    <p className="text-lg font-bold text-white mb-1">{phrase.english}</p>
                    <p className="text-sm text-white/90 italic">{phrase.spanish}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
