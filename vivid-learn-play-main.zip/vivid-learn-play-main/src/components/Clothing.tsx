import { Volume2 } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

export const Clothing = () => {
  const { speak } = useSpeech();

  const clothing = [
    // Upper Body
    { english: "T-shirt", spanish: "Camiseta", emoji: "👕", category: "Parte Superior" },
    { english: "Shirt", spanish: "Camisa", emoji: "👔", category: "Parte Superior" },
    { english: "Blouse", spanish: "Blusa", emoji: "👚", category: "Parte Superior" },
    { english: "Sweater", spanish: "Suéter", emoji: "🧥", category: "Parte Superior" },
    { english: "Cardigan", spanish: "Cárdigan", emoji: "🧥", category: "Parte Superior" },
    { english: "Hoodie", spanish: "Sudadera con capucha", emoji: "🧥", category: "Parte Superior" },
    { english: "Sweatshirt", spanish: "Sudadera", emoji: "👕", category: "Parte Superior" },
    { english: "Tank top", spanish: "Camiseta sin mangas", emoji: "🎽", category: "Parte Superior" },
    { english: "Polo shirt", spanish: "Polo", emoji: "👕", category: "Parte Superior" },
    { english: "Jersey", spanish: "Jersey", emoji: "🧥", category: "Parte Superior" },
    { english: "Turtleneck", spanish: "Cuello de tortuga", emoji: "👔", category: "Parte Superior" },
    { english: "Vest", spanish: "Chaleco", emoji: "🦺", category: "Parte Superior" },

    // Lower Body
    { english: "Pants", spanish: "Pantalones", emoji: "👖", category: "Parte Inferior" },
    { english: "Jeans", spanish: "Vaqueros", emoji: "👖", category: "Parte Inferior" },
    { english: "Shorts", spanish: "Pantalones cortos", emoji: "🩳", category: "Parte Inferior" },
    { english: "Skirt", spanish: "Falda", emoji: "👗", category: "Parte Inferior" },
    { english: "Leggings", spanish: "Mallas", emoji: "👖", category: "Parte Inferior" },
    { english: "Sweatpants", spanish: "Pantalones deportivos", emoji: "👖", category: "Parte Inferior" },
    { english: "Cargo pants", spanish: "Pantalones cargo", emoji: "👖", category: "Parte Inferior" },
    { english: "Capris", spanish: "Piratas", emoji: "👖", category: "Parte Inferior" },
    { english: "Mini skirt", spanish: "Minifalda", emoji: "👗", category: "Parte Inferior" },
    { english: "Maxi skirt", spanish: "Falda larga", emoji: "👗", category: "Parte Inferior" },

    // Dresses & Full Body
    { english: "Dress", spanish: "Vestido", emoji: "👗", category: "Vestidos" },
    { english: "Evening dress", spanish: "Vestido de noche", emoji: "👗", category: "Vestidos" },
    { english: "Cocktail dress", spanish: "Vestido de cóctel", emoji: "👗", category: "Vestidos" },
    { english: "Sundress", spanish: "Vestido de verano", emoji: "👗", category: "Vestidos" },
    { english: "Maxi dress", spanish: "Vestido largo", emoji: "👗", category: "Vestidos" },
    { english: "Jumpsuit", spanish: "Mono", emoji: "🩱", category: "Vestidos" },
    { english: "Romper", spanish: "Pelele", emoji: "🩱", category: "Vestidos" },
    { english: "Overalls", spanish: "Peto", emoji: "👖", category: "Vestidos" },

    // Outerwear
    { english: "Jacket", spanish: "Chaqueta", emoji: "🧥", category: "Abrigos" },
    { english: "Coat", spanish: "Abrigo", emoji: "🧥", category: "Abrigos" },
    { english: "Raincoat", spanish: "Impermeable", emoji: "🧥", category: "Abrigos" },
    { english: "Winter coat", spanish: "Abrigo de invierno", emoji: "🧥", category: "Abrigos" },
    { english: "Parka", spanish: "Parka", emoji: "🧥", category: "Abrigos" },
    { english: "Windbreaker", spanish: "Cortavientos", emoji: "🧥", category: "Abrigos" },
    { english: "Trench coat", spanish: "Gabardina", emoji: "🧥", category: "Abrigos" },
    { english: "Leather jacket", spanish: "Chaqueta de cuero", emoji: "🧥", category: "Abrigos" },
    { english: "Denim jacket", spanish: "Chaqueta vaquera", emoji: "🧥", category: "Abrigos" },
    { english: "Bomber jacket", spanish: "Chaqueta bomber", emoji: "🧥", category: "Abrigos" },
    { english: "Blazer", spanish: "Blazer", emoji: "🧥", category: "Abrigos" },
    { english: "Poncho", spanish: "Poncho", emoji: "🧥", category: "Abrigos" },
    { english: "Cape", spanish: "Capa", emoji: "🧥", category: "Abrigos" },

    // Footwear
    { english: "Shoes", spanish: "Zapatos", emoji: "👞", category: "Calzado" },
    { english: "Sneakers", spanish: "Zapatillas deportivas", emoji: "👟", category: "Calzado" },
    { english: "Boots", spanish: "Botas", emoji: "👢", category: "Calzado" },
    { english: "Sandals", spanish: "Sandalias", emoji: "👡", category: "Calzado" },
    { english: "Flip-flops", spanish: "Chanclas", emoji: "🩴", category: "Calzado" },
    { english: "Slippers", spanish: "Zapatillas de casa", emoji: "🥿", category: "Calzado" },
    { english: "High heels", spanish: "Tacones", emoji: "👠", category: "Calzado" },
    { english: "Flats", spanish: "Bailarinas", emoji: "🥿", category: "Calzado" },
    { english: "Loafers", spanish: "Mocasines", emoji: "👞", category: "Calzado" },
    { english: "Oxford shoes", spanish: "Zapatos Oxford", emoji: "👞", category: "Calzado" },
    { english: "Running shoes", spanish: "Zapatillas para correr", emoji: "👟", category: "Calzado" },
    { english: "Hiking boots", spanish: "Botas de montaña", emoji: "🥾", category: "Calzado" },
    { english: "Rain boots", spanish: "Botas de lluvia", emoji: "👢", category: "Calzado" },
    { english: "Ankle boots", spanish: "Botines", emoji: "👢", category: "Calzado" },
    { english: "Wedges", spanish: "Cuñas", emoji: "👡", category: "Calzado" },

    // Accessories
    { english: "Hat", spanish: "Sombrero", emoji: "🎩", category: "Accesorios" },
    { english: "Cap", spanish: "Gorra", emoji: "🧢", category: "Accesorios" },
    { english: "Beanie", spanish: "Gorro de lana", emoji: "🎩", category: "Accesorios" },
    { english: "Scarf", spanish: "Bufanda", emoji: "🧣", category: "Accesorios" },
    { english: "Gloves", spanish: "Guantes", emoji: "🧤", category: "Accesorios" },
    { english: "Belt", spanish: "Cinturón", emoji: "👔", category: "Accesorios" },
    { english: "Tie", spanish: "Corbata", emoji: "👔", category: "Accesorios" },
    { english: "Bow tie", spanish: "Pajarita", emoji: "🎀", category: "Accesorios" },
    { english: "Socks", spanish: "Calcetines", emoji: "🧦", category: "Accesorios" },
    { english: "Stockings", spanish: "Medias", emoji: "🧦", category: "Accesorios" },
    { english: "Tights", spanish: "Pantimedias", emoji: "🧦", category: "Accesorios" },
    { english: "Sunglasses", spanish: "Gafas de sol", emoji: "🕶️", category: "Accesorios" },
    { english: "Glasses", spanish: "Gafas", emoji: "👓", category: "Accesorios" },
    { english: "Watch", spanish: "Reloj", emoji: "⌚", category: "Accesorios" },
    { english: "Bracelet", spanish: "Pulsera", emoji: "📿", category: "Accesorios" },
    { english: "Necklace", spanish: "Collar", emoji: "📿", category: "Accesorios" },
    { english: "Earrings", spanish: "Pendientes", emoji: "💎", category: "Accesorios" },
    { english: "Ring", spanish: "Anillo", emoji: "💍", category: "Accesorios" },
    { english: "Purse", spanish: "Bolso", emoji: "👛", category: "Accesorios" },
    { english: "Handbag", spanish: "Bolso de mano", emoji: "👜", category: "Accesorios" },
    { english: "Backpack", spanish: "Mochila", emoji: "🎒", category: "Accesorios" },
    { english: "Wallet", spanish: "Cartera", emoji: "👛", category: "Accesorios" },
    { english: "Umbrella", spanish: "Paraguas", emoji: "☂️", category: "Accesorios" },

    // Underwear & Sleepwear
    { english: "Underwear", spanish: "Ropa interior", emoji: "🩲", category: "Ropa Interior" },
    { english: "Bra", spanish: "Sujetador", emoji: "👙", category: "Ropa Interior" },
    { english: "Boxers", spanish: "Bóxers", emoji: "🩲", category: "Ropa Interior" },
    { english: "Briefs", spanish: "Calzoncillos", emoji: "🩲", category: "Ropa Interior" },
    { english: "Panties", spanish: "Bragas", emoji: "👙", category: "Ropa Interior" },
    { english: "Undershirt", spanish: "Camiseta interior", emoji: "👕", category: "Ropa Interior" },
    { english: "Pajamas", spanish: "Pijama", emoji: "👔", category: "Ropa Interior" },
    { english: "Nightgown", spanish: "Camisón", emoji: "👗", category: "Ropa Interior" },
    { english: "Robe", spanish: "Bata", emoji: "🥋", category: "Ropa Interior" },
    { english: "Bathrobe", spanish: "Albornoz", emoji: "🥋", category: "Ropa Interior" },

    // Sportswear
    { english: "Tracksuit", spanish: "Chándal", emoji: "🏃", category: "Ropa Deportiva" },
    { english: "Sports bra", spanish: "Sujetador deportivo", emoji: "👙", category: "Ropa Deportiva" },
    { english: "Gym shorts", spanish: "Pantalones cortos de gimnasio", emoji: "🩳", category: "Ropa Deportiva" },
    { english: "Yoga pants", spanish: "Pantalones de yoga", emoji: "👖", category: "Ropa Deportiva" },
    { english: "Cycling shorts", spanish: "Pantalones de ciclismo", emoji: "🩳", category: "Ropa Deportiva" },
    { english: "Running tights", spanish: "Mallas para correr", emoji: "👖", category: "Ropa Deportiva" },
    { english: "Jersey", spanish: "Camiseta deportiva", emoji: "👕", category: "Ropa Deportiva" },
    { english: "Swimsuit", spanish: "Traje de baño", emoji: "👙", category: "Ropa Deportiva" },
    { english: "Bikini", spanish: "Bikini", emoji: "👙", category: "Ropa Deportiva" },
    { english: "Swimming trunks", spanish: "Bañador", emoji: "🩳", category: "Ropa Deportiva" },

    // Formal Wear
    { english: "Suit", spanish: "Traje", emoji: "🤵", category: "Ropa Formal" },
    { english: "Tuxedo", spanish: "Esmoquin", emoji: "🤵", category: "Ropa Formal" },
    { english: "Wedding dress", spanish: "Vestido de novia", emoji: "👰", category: "Ropa Formal" },
    { english: "Ball gown", spanish: "Vestido de gala", emoji: "👗", category: "Ropa Formal" },
    { english: "Dress shirt", spanish: "Camisa de vestir", emoji: "👔", category: "Ropa Formal" },
    { english: "Dress pants", spanish: "Pantalones de vestir", emoji: "👖", category: "Ropa Formal" },
  ];

  const groupedClothing = clothing.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, typeof clothing>);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-foreground mb-2">👕 Clothing & Accessories</h2>
        <p className="text-muted-foreground">Aprende vocabulario de ropa y accesorios en inglés</p>
      </div>

      {Object.entries(groupedClothing).map(([category, items]) => (
        <div key={category}>
          <h3 className="text-2xl font-bold text-primary mb-4">{category}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {items.map((item) => (
              <div
                key={item.english}
                className="learn-card bg-gradient-to-br from-coral to-coral/70 flex items-center justify-between p-4"
              >
                <div className="flex items-center gap-3">
                  <span className="text-4xl">{item.emoji}</span>
                  <div>
                    <p className="font-bold text-white text-lg">{item.english}</p>
                    <p className="text-sm text-white/80">{item.spanish}</p>
                  </div>
                </div>
                <button
                  onClick={() => speak(item.english)}
                  className="pronunciation-btn bg-white text-coral"
                  aria-label={`Pronounce ${item.english}`}
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};
